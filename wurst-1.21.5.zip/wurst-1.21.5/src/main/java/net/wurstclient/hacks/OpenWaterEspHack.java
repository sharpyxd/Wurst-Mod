/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_1536;
import net.minecraft.class_238;
import net.minecraft.class_4587;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.RenderListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.util.RenderUtils;

@SearchTags({"open water esp", "AutoFishESP", "auto fish esp"})
public final class OpenWaterEspHack extends Hack implements RenderListener
{
	public OpenWaterEspHack()
	{
		super("OpenWaterESP");
		setCategory(Category.RENDER);
	}
	
	@Override
	public String getRenderName()
	{
		class_1536 bobber = MC.field_1724.field_7513;
		if(bobber == null)
			return getName();
		
		return getName() + (isInOpenWater(bobber) ? " [open]" : " [shallow]");
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(RenderListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(RenderListener.class, this);
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		class_1536 bobber = MC.field_1724.field_7513;
		if(bobber == null)
			return;
		
		class_238 box = new class_238(-2, -1, -2, 3, 2, 3).method_996(bobber.method_24515());
		boolean inOpenWater = isInOpenWater(bobber);
		int color = inOpenWater ? 0x8000FF00 : 0x80FF0000;
		
		if(!inOpenWater)
			RenderUtils.drawCrossBox(matrixStack, box, color, false);
		
		RenderUtils.drawOutlinedBox(matrixStack, box, color, false);
	}
	
	private boolean isInOpenWater(class_1536 bobber)
	{
		return bobber.method_26086(bobber.method_24515());
	}
}
