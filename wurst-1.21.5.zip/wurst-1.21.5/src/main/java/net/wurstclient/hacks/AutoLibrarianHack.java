/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1646;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1914;
import net.minecraft.class_1916;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2863;
import net.minecraft.class_3852;
import net.minecraft.class_3966;
import net.minecraft.class_4587;
import net.minecraft.class_492;
import net.minecraft.class_636;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.RenderListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.hacks.autolibrarian.BookOffer;
import net.wurstclient.hacks.autolibrarian.UpdateBooksSetting;
import net.wurstclient.mixinterface.IKeyBinding;
import net.wurstclient.settings.BookOffersSetting;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.FacingSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.settings.SwingHandSetting;
import net.wurstclient.settings.SwingHandSetting.SwingHand;
import net.wurstclient.util.*;
import net.wurstclient.util.BlockBreaker.BlockBreakingParams;
import net.wurstclient.util.BlockPlacer.BlockPlacingParams;

@SearchTags({"auto librarian", "AutoVillager", "auto villager",
	"VillagerTrainer", "villager trainer", "LibrarianTrainer",
	"librarian trainer", "AutoHmmm", "auto hmmm"})
public final class AutoLibrarianHack extends Hack
	implements UpdateListener, RenderListener
{
	private final BookOffersSetting wantedBooks = new BookOffersSetting(
		"Wanted books",
		"A list of enchanted books that you want your villagers to sell.\n\n"
			+ "AutoLibrarian will stop training the current villager"
			+ " once it has learned to sell one of these books.\n\n"
			+ "You can also set a maximum price for each book, in case you"
			+ " already have a villager selling it but you want it for a"
			+ " cheaper price.",
		"minecraft:depth_strider;3", "minecraft:efficiency;5",
		"minecraft:feather_falling;4", "minecraft:fortune;3",
		"minecraft:looting;3", "minecraft:mending;1", "minecraft:protection;4",
		"minecraft:respiration;3", "minecraft:sharpness;5",
		"minecraft:silk_touch;1", "minecraft:unbreaking;3");
	
	private final CheckboxSetting lockInTrade = new CheckboxSetting(
		"Lock in trade",
		"Automatically buys something from the villager once it has learned to"
			+ " sell the book you want. This prevents the villager from"
			+ " changing its trade offers later.\n\n"
			+ "Make sure you have at least 24 paper and 9 emeralds in your"
			+ " inventory when using this feature. Alternatively, 1 book and"
			+ " 64 emeralds will also work.",
		false);
	
	private final UpdateBooksSetting updateBooks = new UpdateBooksSetting();
	
	private final SliderSetting range =
		new SliderSetting("Range", 5, 1, 6, 0.05, ValueDisplay.DECIMAL);
	
	private final FacingSetting facing = FacingSetting.withoutPacketSpam(
		"How AutoLibrarian should face the villager and job site.\n\n"
			+ "\u00a7lOff\u00a7r - Don't face the villager at all. Will be"
			+ " detected by anti-cheat plugins.\n\n"
			+ "\u00a7lServer-side\u00a7r - Face the villager on the"
			+ " server-side, while still letting you move the camera freely on"
			+ " the client-side.\n\n"
			+ "\u00a7lClient-side\u00a7r - Face the villager by moving your"
			+ " camera on the client-side. This is the most legit option, but"
			+ " can be disorienting to look at.");
	
	private final SwingHandSetting swingHand =
		new SwingHandSetting(this, SwingHand.SERVER);
	
	private final SliderSetting repairMode = new SliderSetting("Repair mode",
		"Prevents AutoLibrarian from using your axe when its durability reaches"
			+ " the given threshold, so you can repair it before it breaks.\n"
			+ "Can be adjusted from 0 (off) to 100 remaining uses.",
		1, 0, 100, 1, ValueDisplay.INTEGER.withLabel(0, "off"));
	
	private final OverlayRenderer overlay = new OverlayRenderer();
	private final HashSet<class_1646> experiencedVillagers =
		new HashSet<>();
	
	private class_1646 villager;
	private class_2338 jobSite;
	
	private boolean placingJobSite;
	private boolean breakingJobSite;
	
	public AutoLibrarianHack()
	{
		super("AutoLibrarian");
		setCategory(Category.OTHER);
		addSetting(wantedBooks);
		addSetting(lockInTrade);
		addSetting(updateBooks);
		addSetting(range);
		addSetting(facing);
		addSetting(swingHand);
		addSetting(repairMode);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(RenderListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		
		if(breakingJobSite)
		{
			MC.field_1761.field_3717 = true;
			MC.field_1761.method_2925();
			breakingJobSite = false;
		}
		
		overlay.resetProgress();
		villager = null;
		jobSite = null;
		placingJobSite = false;
		breakingJobSite = false;
		experiencedVillagers.clear();
	}
	
	@Override
	public void onUpdate()
	{
		if(villager == null)
		{
			setTargetVillager();
			return;
		}
		
		if(jobSite == null)
		{
			setTargetJobSite();
			return;
		}
		
		if(placingJobSite && breakingJobSite)
			throw new IllegalStateException(
				"Trying to place and break job site at the same time. Something is wrong.");
		
		if(placingJobSite)
		{
			placeJobSite();
			return;
		}
		
		if(breakingJobSite)
		{
			breakJobSite();
			return;
		}
		
		if(!(MC.field_1755 instanceof class_492 tradeScreen))
		{
			openTradeScreen();
			return;
		}
		
		// Can't see experience until the trade screen is open, so we have to
		// check it here and start over if the villager is already experienced.
		int experience = tradeScreen.method_17577().method_19254();
		if(experience > 0)
		{
			ChatUtils.warning("Villager at "
				+ villager.method_24515().method_23854()
				+ " is already experienced, meaning it can't be trained anymore.");
			ChatUtils.message("Looking for another villager...");
			experiencedVillagers.add(villager);
			villager = null;
			jobSite = null;
			closeTradeScreen();
			return;
		}
		
		// check which book the villager is selling
		BookOffer bookOffer =
			findEnchantedBookOffer(tradeScreen.method_17577().method_17438());
		
		if(bookOffer == null)
		{
			ChatUtils.message("Villager is not selling an enchanted book.");
			closeTradeScreen();
			breakingJobSite = true;
			System.out.println("Breaking job site...");
			return;
		}
		
		ChatUtils.message(
			"Villager is selling " + bookOffer.getEnchantmentNameWithLevel()
				+ " for " + bookOffer.getFormattedPrice() + ".");
		
		// if wrong enchantment, break job site and start over
		if(!wantedBooks.isWanted(bookOffer))
		{
			breakingJobSite = true;
			System.out.println("Breaking job site...");
			closeTradeScreen();
			return;
		}
		
		// lock in the trade, if enabled
		if(lockInTrade.isChecked())
		{
			// select the first valid trade
			tradeScreen.method_17577().method_7650(0);
			tradeScreen.method_17577().method_20215(0);
			MC.method_1562()
				.method_52787(new class_2863(0));
			
			// buy whatever the villager is selling
			MC.field_1761.method_2906(
				tradeScreen.method_17577().field_7763, 2, 0,
				class_1713.field_7790, MC.field_1724);
			
			// close the trade screen
			closeTradeScreen();
		}
		
		// update wanted books based on the user's settings
		updateBooks.getSelected().update(wantedBooks, bookOffer);
		
		ChatUtils.message("Done!");
		setEnabled(false);
	}
	
	private void breakJobSite()
	{
		if(jobSite == null)
			throw new IllegalStateException("Job site is null.");
		
		BlockBreakingParams params =
			BlockBreaker.getBlockBreakingParams(jobSite);
		
		if(params == null || BlockUtils.getState(jobSite).method_45474())
		{
			System.out.println("Job site has been broken. Replacing...");
			breakingJobSite = false;
			placingJobSite = true;
			return;
		}
		
		// equip tool
		WURST.getHax().autoToolHack.equipBestTool(jobSite, false, true,
			repairMode.getValueI());
		
		// face block
		facing.getSelected().face(params.hitVec());
		
		// damage block and swing hand
		if(MC.field_1761.method_2902(jobSite,
			params.side()))
			swingHand.swing(class_1268.field_5808);
		
		// update progress
		overlay.updateProgress();
	}
	
	private void placeJobSite()
	{
		if(jobSite == null)
			throw new IllegalStateException("Job site is null.");
		
		if(!BlockUtils.getState(jobSite).method_45474())
		{
			if(BlockUtils.getBlock(jobSite) == class_2246.field_16330)
			{
				System.out.println("Job site has been placed.");
				placingJobSite = false;
				
			}else
			{
				System.out
					.println("Found wrong block at job site. Breaking...");
				breakingJobSite = true;
				placingJobSite = false;
			}
			
			return;
		}
		
		// check if holding a lectern
		if(!MC.field_1724.method_24518(class_1802.field_16312))
		{
			InventoryUtils.selectItem(class_1802.field_16312, 36);
			return;
		}
		
		// get the hand that is holding the lectern
		class_1268 hand = MC.field_1724.method_6047().method_31574(class_1802.field_16312)
			? class_1268.field_5808 : class_1268.field_5810;
		
		// sneak-place to avoid activating trapdoors/chests/etc.
		IKeyBinding sneakKey = IKeyBinding.get(MC.field_1690.field_1832);
		sneakKey.setPressed(true);
		if(!MC.field_1724.method_5715())
			return;
		
		// get block placing params
		BlockPlacingParams params = BlockPlacer.getBlockPlacingParams(jobSite);
		if(params == null)
		{
			sneakKey.resetPressedState();
			return;
		}
		
		// face block
		facing.getSelected().face(params.hitVec());
		
		// place block
		class_1269 result = MC.field_1761.method_2896(MC.field_1724,
			hand, params.toHitResult());
		
		// swing hand
		if(result instanceof class_1269.class_9860 success
			&& success.comp_2909() == class_1269.class_9861.field_52427)
			swingHand.swing(hand);
		
		// reset sneak
		sneakKey.resetPressedState();
	}
	
	private void openTradeScreen()
	{
		if(MC.field_1752 > 0)
			return;
		
		class_636 im = MC.field_1761;
		class_746 player = MC.field_1724;
		
		if(player.method_5858(villager) > range.getValueSq())
		{
			ChatUtils.error("Villager is out of range. Consider trapping"
				+ " the villager so it doesn't wander away.");
			setEnabled(false);
			return;
		}
		
		// create realistic hit result
		class_238 box = villager.method_5829();
		class_243 start = RotationUtils.getEyesPos();
		class_243 end = box.method_1005();
		class_243 hitVec = box.method_992(start, end).orElse(start);
		class_3966 hitResult = new class_3966(villager, hitVec);
		
		// face end vector
		facing.getSelected().face(end);
		
		// click on villager
		class_1268 hand = class_1268.field_5808;
		class_1269 actionResult =
			im.method_2917(player, villager, hitResult, hand);
		
		if(!actionResult.method_23665())
			im.method_2905(player, villager, hand);
		
		// swing hand
		if(actionResult instanceof class_1269.class_9860 success
			&& success.comp_2909() == class_1269.class_9861.field_52427)
			swingHand.swing(hand);
		
		// set cooldown
		MC.field_1752 = 4;
	}
	
	private void closeTradeScreen()
	{
		MC.field_1724.method_7346();
		MC.field_1752 = 4;
	}
	
	private BookOffer findEnchantedBookOffer(class_1916 tradeOffers)
	{
		for(class_1914 tradeOffer : tradeOffers)
		{
			class_1799 stack = tradeOffer.method_8250();
			if(stack.method_7909() != class_1802.field_8598)
				continue;
			
			Set<Entry<class_6880<class_1887>>> enchantmentLevelMap =
				class_1890.method_57532(stack)
					.method_57539();
			if(enchantmentLevelMap.isEmpty())
				continue;
			
			Object2IntMap.Entry<class_6880<class_1887>> firstEntry =
				enchantmentLevelMap.stream().findFirst().orElseThrow();
			
			String enchantment = firstEntry.getKey().method_55840();
			int level = firstEntry.getIntValue();
			int price = tradeOffer.method_19272().method_7947();
			BookOffer bookOffer = new BookOffer(enchantment, level, price);
			
			if(!bookOffer.isFullyValid())
			{
				System.out.println("Found invalid enchanted book offer.\n"
					+ "Component data: " + enchantmentLevelMap);
				continue;
			}
			
			return bookOffer;
		}
		
		return null;
	}
	
	private void setTargetVillager()
	{
		class_746 player = MC.field_1724;
		double rangeSq = range.getValueSq();
		
		Stream<class_1646> stream =
			StreamSupport.stream(MC.field_1687.method_18112().spliterator(), true)
				.filter(e -> !e.method_31481())
				.filter(class_1646.class::isInstance)
				.map(e -> (class_1646)e).filter(e -> e.method_6032() > 0)
				.filter(e -> player.method_5858(e) <= rangeSq)
				.filter(e -> e.method_7231().comp_3521().method_40230()
					.orElse(null) == class_3852.field_17060)
				.filter(e -> e.method_7231().comp_3522() == 1)
				.filter(e -> !experiencedVillagers.contains(e));
		
		villager = stream
			.min(Comparator.comparingDouble(e -> player.method_5858(e)))
			.orElse(null);
		
		if(villager == null)
		{
			String errorMsg = "Couldn't find a nearby librarian.";
			int numExperienced = experiencedVillagers.size();
			if(numExperienced > 0)
				errorMsg += " (Except for " + numExperienced + " that "
					+ (numExperienced == 1 ? "is" : "are")
					+ " already experienced.)";
			
			ChatUtils.error(errorMsg);
			ChatUtils.message("Make sure both the librarian and the lectern"
				+ " are reachable from where you are standing.");
			setEnabled(false);
			return;
		}
		
		System.out.println("Found villager at " + villager.method_24515());
	}
	
	private void setTargetJobSite()
	{
		class_243 eyesVec = RotationUtils.getEyesPos();
		double rangeSq = range.getValueSq();
		
		Stream<class_2338> stream = BlockUtils
			.getAllInBoxStream(class_2338.method_49638(eyesVec),
				range.getValueCeil())
			.filter(pos -> eyesVec
				.method_1025(class_243.method_24953(pos)) <= rangeSq)
			.filter(pos -> BlockUtils.getBlock(pos) == class_2246.field_16330);
		
		jobSite = stream
			.min(Comparator.comparingDouble(
				pos -> villager.method_5707(class_243.method_24953(pos))))
			.orElse(null);
		
		if(jobSite == null)
		{
			ChatUtils.error("Couldn't find the librarian's lectern.");
			ChatUtils.message("Make sure both the librarian and the lectern"
				+ " are reachable from where you are standing.");
			setEnabled(false);
			return;
		}
		
		System.out.println("Found lectern at " + jobSite);
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		int green = 0xC000FF00;
		int red = 0xC0FF0000;
		
		if(villager != null)
			RenderUtils.drawOutlinedBox(matrixStack, villager.method_5829(),
				green, false);
		
		if(jobSite != null)
			RenderUtils.drawOutlinedBox(matrixStack, new class_238(jobSite), green,
				false);
		
		List<class_238> expVilBoxes = experiencedVillagers.stream()
			.map(class_1646::method_5829).toList();
		RenderUtils.drawOutlinedBoxes(matrixStack, expVilBoxes, red, false);
		RenderUtils.drawCrossBoxes(matrixStack, expVilBoxes, red, false);
		
		if(breakingJobSite)
			overlay.render(matrixStack, partialTicks, jobSite);
	}
}
