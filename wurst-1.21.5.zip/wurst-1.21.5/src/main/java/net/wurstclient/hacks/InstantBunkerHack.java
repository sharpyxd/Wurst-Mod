/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.SwingHandSetting.SwingHand;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.RotationUtils;

@SearchTags({"instant bunker"})
public final class InstantBunkerHack extends Hack implements UpdateListener
{
	private final int[][] template = {{2, 0, 2}, {-2, 0, 2}, {2, 0, -2},
		{-2, 0, -2}, {2, 1, 2}, {-2, 1, 2}, {2, 1, -2}, {-2, 1, -2}, {2, 2, 2},
		{-2, 2, 2}, {2, 2, -2}, {-2, 2, -2}, {1, 2, 2}, {0, 2, 2}, {-1, 2, 2},
		{2, 2, 1}, {2, 2, 0}, {2, 2, -1}, {-2, 2, 1}, {-2, 2, 0}, {-2, 2, -1},
		{1, 2, -2}, {0, 2, -2}, {-1, 2, -2}, {1, 0, 2}, {0, 0, 2}, {-1, 0, 2},
		{2, 0, 1}, {2, 0, 0}, {2, 0, -1}, {-2, 0, 1}, {-2, 0, 0}, {-2, 0, -1},
		{1, 0, -2}, {0, 0, -2}, {-1, 0, -2}, {1, 1, 2}, {0, 1, 2}, {-1, 1, 2},
		{2, 1, 1}, {2, 1, 0}, {2, 1, -1}, {-2, 1, 1}, {-2, 1, 0}, {-2, 1, -1},
		{1, 1, -2}, {0, 1, -2}, {-1, 1, -2}, {1, 2, 1}, {-1, 2, 1}, {1, 2, -1},
		{-1, 2, -1}, {0, 2, 1}, {1, 2, 0}, {-1, 2, 0}, {0, 2, -1}, {0, 2, 0}};
	private final ArrayList<class_2338> positions = new ArrayList<>();
	
	private int startTimer;
	
	public InstantBunkerHack()
	{
		super("InstantBunker");
		setCategory(Category.BLOCKS);
	}
	
	@Override
	protected void onEnable()
	{
		WURST.getHax().tunnellerHack.setEnabled(false);
		
		if(!MC.field_1724.method_24828())
		{
			ChatUtils.error("Can't build this in mid-air.");
			setEnabled(false);
			return;
		}
		
		class_1799 stack = MC.field_1724.method_31548().method_7391();
		
		if(!(stack.method_7909() instanceof class_1747))
		{
			ChatUtils.error("You must have blocks in the main hand.");
			setEnabled(false);
			return;
		}
		
		if(stack.method_7947() < 57 && !MC.field_1724.method_31549().field_7477)
			ChatUtils.warning("Not enough blocks. Bunker may be incomplete.");
		
		// get start pos and facings
		class_2338 startPos = class_2338.method_49638(MC.field_1724.method_19538());
		class_2350 facing = MC.field_1724.method_5735();
		class_2350 facing2 = facing.method_10160();
		
		// set positions
		positions.clear();
		for(int[] pos : template)
			positions.add(startPos.method_10086(pos[1]).method_10079(facing, pos[2])
				.method_10079(facing2, pos[0]));
		
		startTimer = 2;
		MC.field_1724.method_6043();
		
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(startTimer > 0)
		{
			startTimer--;
			return;
		}
		
		// build instantly
		if(startTimer <= 0)
		{
			for(class_2338 pos : positions)
				if(BlockUtils.getState(pos).method_45474()
					&& !MC.field_1724.method_5829().method_994(new class_238(pos)))
					placeBlockSimple(pos);
			MC.field_1724.method_6104(class_1268.field_5808);
			
			if(MC.field_1724.method_24828())
				setEnabled(false);
		}
	}
	
	private void placeBlockSimple(class_2338 pos)
	{
		class_2350 side = null;
		class_2350[] sides = class_2350.values();
		
		class_243 eyesPos = RotationUtils.getEyesPos();
		class_243 posVec = class_243.method_24953(pos);
		double distanceSqPosVec = eyesPos.method_1025(posVec);
		
		class_243[] hitVecs = new class_243[sides.length];
		for(int i = 0; i < sides.length; i++)
			hitVecs[i] =
				posVec.method_1019(class_243.method_24954(sides[i].method_62675()).method_1021(0.5));
		
		for(int i = 0; i < sides.length; i++)
		{
			// check if neighbor can be right clicked
			class_2338 neighbor = pos.method_10093(sides[i]);
			if(!BlockUtils.canBeClicked(neighbor))
				continue;
			
			// check line of sight
			class_2680 neighborState = BlockUtils.getState(neighbor);
			class_265 neighborShape =
				neighborState.method_26218(MC.field_1687, neighbor);
			if(MC.field_1687.method_17745(eyesPos, hitVecs[i], neighbor,
				neighborShape, neighborState) != null)
				continue;
			
			side = sides[i];
			break;
		}
		
		if(side == null)
			for(int i = 0; i < sides.length; i++)
			{
				// check if neighbor can be right clicked
				if(!BlockUtils.canBeClicked(pos.method_10093(sides[i])))
					continue;
				
				// check if side is facing away from player
				if(distanceSqPosVec > eyesPos.method_1025(hitVecs[i]))
					continue;
				
				side = sides[i];
				break;
			}
		
		if(side == null)
			return;
		
		class_243 hitVec = hitVecs[side.ordinal()];
		
		// face block
		// WURST.getRotationFaker().faceVectorPacket(hitVec);
		// if(RotationUtils.getAngleToLastReportedLookVec(hitVec) > 1)
		// return;
		
		// check timer
		// if(IMC.getItemUseCooldown() > 0)
		// return;
		
		// place block
		IMC.getInteractionManager().rightClickBlock(pos.method_10093(side),
			side.method_10153(), hitVec);
		
		// swing arm
		SwingHand.SERVER.swing(class_1268.field_5808);
		
		// reset timer
		MC.field_1752 = 4;
	}
}
