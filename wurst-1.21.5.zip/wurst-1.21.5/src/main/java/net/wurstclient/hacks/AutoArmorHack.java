/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Optional;
import net.minecraft.class_1304;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2378;
import net.minecraft.class_2813;
import net.minecraft.class_465;
import net.minecraft.class_490;
import net.minecraft.class_5455;
import net.minecraft.class_6880.class_6883;
import net.minecraft.class_746;
import net.minecraft.class_7924;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.WurstClient;
import net.wurstclient.events.PacketOutputListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.util.InventoryUtils;
import net.wurstclient.util.ItemUtils;

@SearchTags({"auto armor"})
public final class AutoArmorHack extends Hack
	implements UpdateListener, PacketOutputListener
{
	private final CheckboxSetting useEnchantments = new CheckboxSetting(
		"Use enchantments",
		"Whether or not to consider the Protection enchantment when calculating armor strength.",
		true);
	
	private final CheckboxSetting swapWhileMoving = new CheckboxSetting(
		"Swap while moving",
		"Whether or not to swap armor pieces while the player is moving.\n\n"
			+ "\u00a7c\u00a7lWARNING:\u00a7r This would not be possible without cheats. It may raise suspicion.",
		false);
	
	private final SliderSetting delay = new SliderSetting("Delay",
		"Amount of ticks to wait before swapping the next piece of armor.", 2,
		0, 20, 1, ValueDisplay.INTEGER);
	
	private int timer;
	
	public AutoArmorHack()
	{
		super("AutoArmor");
		setCategory(Category.COMBAT);
		addSetting(useEnchantments);
		addSetting(swapWhileMoving);
		addSetting(delay);
	}
	
	@Override
	protected void onEnable()
	{
		timer = 0;
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(PacketOutputListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(PacketOutputListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		// wait for timer
		if(timer > 0)
		{
			timer--;
			return;
		}
		
		// check screen
		if(MC.field_1755 instanceof class_465
			&& !(MC.field_1755 instanceof class_490))
			return;
		
		class_746 player = MC.field_1724;
		class_1661 inventory = player.method_31548();
		
		if(!swapWhileMoving.isChecked()
			&& player.field_3913.method_3128().method_35584() > 1e-5F)
			return;
		
		// store slots and values of best armor pieces
		EnumMap<class_1304, ArmorData> bestArmor =
			new EnumMap<>(class_1304.class);
		ArrayList<class_1304> armorTypes =
			new ArrayList<>(Arrays.asList(class_1304.field_6166,
				class_1304.field_6172, class_1304.field_6174, class_1304.field_6169));
		
		// initialize with currently equipped armor
		for(class_1304 type : armorTypes)
		{
			bestArmor.put(type, new ArmorData(-1, 0));
			
			class_1799 stack = player.method_6118(type);
			if(!MC.field_1724.method_63623(stack, type))
				continue;
			
			bestArmor.put(type, new ArmorData(-1, getArmorValue(stack)));
		}
		
		// search inventory for better armor
		for(int slot = 0; slot < 36; slot++)
		{
			class_1799 stack = inventory.method_5438(slot);
			
			class_1304 armorType = ItemUtils.getArmorSlot(stack.method_7909());
			if(armorType == null)
				continue;
			
			int armorValue = getArmorValue(stack);
			ArmorData data = bestArmor.get(armorType);
			
			if(data == null || armorValue > data.armorValue())
				bestArmor.put(armorType, new ArmorData(slot, armorValue));
		}
		
		// equip better armor in random order
		Collections.shuffle(armorTypes);
		for(class_1304 type : armorTypes)
		{
			// check if better armor was found
			ArmorData data = bestArmor.get(type);
			if(data == null || data.invSlot() == -1)
				continue;
				
			// check if armor can be swapped
			// needs 1 free slot where it can put the old armor
			class_1799 oldArmor = player.method_6118(type);
			if(!oldArmor.method_7960() && inventory.method_7376() == -1)
				continue;
			
			// swap armor
			if(!oldArmor.method_7960())
				IMC.getInteractionManager()
					.windowClick_QUICK_MOVE(8 - type.method_5927());
			IMC.getInteractionManager().windowClick_QUICK_MOVE(
				InventoryUtils.toNetworkSlot(data.invSlot()));
			
			break;
		}
	}
	
	@Override
	public void onSentPacket(PacketOutputEvent event)
	{
		if(event.getPacket() instanceof class_2813)
			timer = delay.getValueI();
	}
	
	private int getArmorValue(class_1799 stack)
	{
		class_1792 item = stack.method_7909();
		int armorPoints = (int)ItemUtils.getArmorPoints(item);
		int prtPoints = 0;
		int armorToughness = (int)ItemUtils.getToughness(item);
		
		if(useEnchantments.isChecked())
		{
			class_5455 drm =
				WurstClient.MC.field_1687.method_30349();
			class_2378<class_1887> registry =
				drm.method_30530(class_7924.field_41265);
			
			Optional<class_6883<class_1887>> protection =
				registry.method_46746(class_1893.field_9111);
			prtPoints = protection
				.map(entry -> class_1890.method_8225(entry, stack))
				.orElse(0);
		}
		
		return armorPoints * 5 + prtPoints * 3 + armorToughness;
	}
	
	private record ArmorData(int invSlot, int armorValue)
	{}
}
