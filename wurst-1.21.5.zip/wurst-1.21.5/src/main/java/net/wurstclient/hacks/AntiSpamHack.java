/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.List;
import net.minecraft.class_303;
import net.minecraft.class_338;
import net.minecraft.class_341;
import net.minecraft.class_3532;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.ChatInputListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.MathUtils;

@SearchTags({"NoSpam", "ChatFilter", "anti spam", "no spam", "chat filter"})
public final class AntiSpamHack extends Hack implements ChatInputListener
{
	public AntiSpamHack()
	{
		super("AntiSpam");
		setCategory(Category.CHAT);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(ChatInputListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(ChatInputListener.class, this);
	}
	
	@Override
	public void onReceivedMessage(ChatInputEvent event)
	{
		List<class_303.class_7590> chatLines = event.getChatLines();
		if(chatLines.isEmpty())
			return;
		
		class_338 chat = MC.field_1705.method_1743();
		int maxTextLength =
			class_3532.method_15357(chat.method_1811() / chat.method_1814());
		List<class_5481> newLines = class_341.method_1850(
			event.getComponent(), maxTextLength, MC.field_1772);
		
		int spamCounter = 1;
		int matchingLines = 0;
		
		for(int i = chatLines.size() - 1; i >= 0; i--)
		{
			String oldLine = ChatUtils.getAsString(chatLines.get(i));
			
			if(matchingLines <= newLines.size() - 1)
			{
				String newLine =
					ChatUtils.getAsString(newLines.get(matchingLines));
				
				if(matchingLines < newLines.size() - 1)
				{
					if(oldLine.equals(newLine))
						matchingLines++;
					else
						matchingLines = 0;
					
					continue;
				}
				
				if(!oldLine.startsWith(newLine))
				{
					matchingLines = 0;
					continue;
				}
				
				if(i > 0 && matchingLines == newLines.size() - 1)
				{
					String nextOldLine =
						ChatUtils.getAsString(chatLines.get(i - 1));
					
					String twoLines = oldLine + nextOldLine;
					String addedText = twoLines.substring(newLine.length());
					
					if(addedText.startsWith(" [x") && addedText.endsWith("]"))
					{
						String oldSpamCounter =
							addedText.substring(3, addedText.length() - 1);
						
						if(MathUtils.isInteger(oldSpamCounter))
						{
							spamCounter += Integer.parseInt(oldSpamCounter);
							matchingLines++;
							continue;
						}
					}
				}
				
				if(oldLine.length() == newLine.length())
					spamCounter++;
				else
				{
					String addedText = oldLine.substring(newLine.length());
					if(!addedText.startsWith(" [x") || !addedText.endsWith("]"))
					{
						matchingLines = 0;
						continue;
					}
					
					String oldSpamCounter =
						addedText.substring(3, addedText.length() - 1);
					if(!MathUtils.isInteger(oldSpamCounter))
					{
						matchingLines = 0;
						continue;
					}
					
					spamCounter += Integer.parseInt(oldSpamCounter);
				}
			}
			
			for(int i2 = i + matchingLines; i2 >= i; i2--)
				chatLines.remove(i2);
			matchingLines = 0;
		}
		
		if(spamCounter > 1)
		{
			// Someone, somewhere, is creating a MutableText object with an
			// immutable List<Text> siblings parameter, which causes the game to
			// crash when calling append(). So we always have to create a new
			// MutableText object to avoid that.
			class_5250 oldText = (class_5250)event.getComponent();
			class_5250 newText = class_5250.method_43477(oldText.method_10851());
			newText.method_10862(oldText.method_10866());
			oldText.method_10855().forEach(newText::method_10852);
			
			event.setComponent(newText.method_27693(" [x" + spamCounter + "]"));
		}
	}
}
