/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Stream;
import net.minecraft.class_10124;
import net.minecraft.class_10132;
import net.minecraft.class_10134;
import net.minecraft.class_10138;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1321;
import net.minecraft.class_1646;
import net.minecraft.class_1661;
import net.minecraft.class_1702;
import net.minecraft.class_1799;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2304;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4174;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_9334;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.EnumSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.util.InventoryUtils;

@SearchTags({"auto eat", "AutoFood", "auto food", "AutoFeeder", "auto feeder",
	"AutoFeeding", "auto feeding", "AutoSoup", "auto soup"})
public final class AutoEatHack extends Hack implements UpdateListener
{
	private final SliderSetting targetHunger = new SliderSetting(
		"Target hunger", "description.wurst.setting.autoeat.target_hunger", 10,
		0, 10, 0.5, ValueDisplay.DECIMAL);
	
	private final SliderSetting minHunger = new SliderSetting("Min hunger",
		"description.wurst.setting.autoeat.min_hunger", 6.5, 0, 10, 0.5,
		ValueDisplay.DECIMAL);
	
	private final SliderSetting injuredHunger = new SliderSetting(
		"Injured hunger", "description.wurst.setting.autoeat.injured_hunger",
		10, 0, 10, 0.5, ValueDisplay.DECIMAL);
	
	private final SliderSetting injuryThreshold =
		new SliderSetting("Injury threshold",
			"description.wurst.setting.autoeat.injury_threshold", 1.5, 0.5, 10,
			0.5, ValueDisplay.DECIMAL);
	
	private final EnumSetting<TakeItemsFrom> takeItemsFrom = new EnumSetting<>(
		"Take items from", "description.wurst.setting.autoeat.take_items_from",
		TakeItemsFrom.values(), TakeItemsFrom.HOTBAR);
	
	private final CheckboxSetting allowOffhand =
		new CheckboxSetting("Allow offhand", true);
	
	private final CheckboxSetting eatWhileWalking =
		new CheckboxSetting("Eat while walking",
			"description.wurst.setting.autoeat.eat_while_walking", false);
	
	private final CheckboxSetting allowHunger =
		new CheckboxSetting("Allow hunger effect",
			"description.wurst.setting.autoeat.allow_hunger", true);
	
	private final CheckboxSetting allowPoison =
		new CheckboxSetting("Allow poison effect",
			"description.wurst.setting.autoeat.allow_poison", false);
	
	private final CheckboxSetting allowChorus =
		new CheckboxSetting("Allow chorus fruit",
			"description.wurst.setting.autoeat.allow_chorus", false);
	
	private int oldSlot = -1;
	
	public AutoEatHack()
	{
		super("AutoEat");
		setCategory(Category.ITEMS);
		
		addSetting(targetHunger);
		addSetting(minHunger);
		addSetting(injuredHunger);
		addSetting(injuryThreshold);
		
		addSetting(takeItemsFrom);
		addSetting(allowOffhand);
		
		addSetting(eatWhileWalking);
		addSetting(allowHunger);
		addSetting(allowPoison);
		addSetting(allowChorus);
	}
	
	@Override
	protected void onEnable()
	{
		WURST.getHax().autoSoupHack.setEnabled(false);
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		
		if(isEating())
			stopEating();
	}
	
	@Override
	public void onUpdate()
	{
		class_746 player = MC.field_1724;
		
		if(!shouldEat())
		{
			if(isEating())
				stopEating();
			
			return;
		}
		
		class_1702 hungerManager = player.method_7344();
		int foodLevel = hungerManager.method_7586();
		int targetHungerI = (int)(targetHunger.getValue() * 2);
		int minHungerI = (int)(minHunger.getValue() * 2);
		int injuredHungerI = (int)(injuredHunger.getValue() * 2);
		
		if(isInjured(player) && foodLevel < injuredHungerI)
		{
			eat(-1);
			return;
		}
		
		if(foodLevel < minHungerI)
		{
			eat(-1);
			return;
		}
		
		if(foodLevel < targetHungerI)
		{
			int maxPoints = targetHungerI - foodLevel;
			eat(maxPoints);
		}
	}
	
	private void eat(int maxPoints)
	{
		class_1661 inventory = MC.field_1724.method_31548();
		int foodSlot = findBestFoodSlot(maxPoints);
		
		if(foodSlot == -1)
		{
			if(isEating())
				stopEating();
			
			return;
		}
		
		// select food
		if(foodSlot < 9)
		{
			if(!isEating())
				oldSlot = inventory.method_67532();
			
			inventory.method_61496(foodSlot);
			
		}else if(foodSlot == 40)
		{
			if(!isEating())
				oldSlot = inventory.method_67532();
			
			// off-hand slot, no need to select anything
			
		}else
		{
			InventoryUtils.selectItem(foodSlot);
			return;
		}
		
		// eat food
		MC.field_1690.field_1904.method_23481(true);
		IMC.getInteractionManager().rightClickItem();
	}
	
	private int findBestFoodSlot(int maxPoints)
	{
		class_1661 inventory = MC.field_1724.method_31548();
		class_4174 bestFood = null;
		int bestSlot = -1;
		
		int maxInvSlot = takeItemsFrom.getSelected().maxInvSlot;
		
		ArrayList<Integer> slots = new ArrayList<>();
		if(maxInvSlot == 0)
			slots.add(inventory.method_67532());
		if(allowOffhand.isChecked())
			slots.add(40);
		Stream.iterate(0, i -> i < maxInvSlot, i -> i + 1)
			.forEach(i -> slots.add(i));
		
		Comparator<class_4174> comparator =
			Comparator.comparingDouble(class_4174::comp_2492);
		
		for(int slot : slots)
		{
			class_1799 stack = inventory.method_5438(slot);
			
			// filter out non-food items
			if(!stack.method_57826(class_9334.field_50075))
				continue;
			
			if(!isAllowedFood(stack.method_58694(class_9334.field_53964)))
				continue;
			
			class_4174 food = stack.method_58694(class_9334.field_50075);
			if(maxPoints >= 0 && food.comp_2491() > maxPoints)
				continue;
			
			// compare to previously found food
			if(bestFood == null || comparator.compare(food, bestFood) > 0)
			{
				bestFood = food;
				bestSlot = slot;
			}
		}
		
		return bestSlot;
	}
	
	private boolean shouldEat()
	{
		if(MC.field_1724.method_31549().field_7477)
			return false;
		
		if(!MC.field_1724.method_7332(false))
			return false;
		
		if(!eatWhileWalking.isChecked()
			&& (MC.field_1724.field_6250 != 0 || MC.field_1724.field_6212 != 0))
			return false;
		
		if(isClickable(MC.field_1765))
			return false;
		
		return true;
	}
	
	private void stopEating()
	{
		MC.field_1690.field_1904.method_23481(false);
		MC.field_1724.method_31548().method_61496(oldSlot);
		oldSlot = -1;
	}
	
	private boolean isAllowedFood(class_10124 consumable)
	{
		for(class_10134 consumeEffect : consumable.comp_3089())
		{
			if(!allowChorus.isChecked()
				&& consumeEffect instanceof class_10138)
				return false;
			
			if(!(consumeEffect instanceof class_10132 applyEffectsConsumeEffect))
				continue;
			
			for(class_1293 effect : applyEffectsConsumeEffect
				.comp_3094())
			{
				class_6880<class_1291> entry = effect.method_5579();
				
				if(!allowHunger.isChecked() && entry == class_1294.field_5903)
					return false;
				
				if(!allowPoison.isChecked() && entry == class_1294.field_5899)
					return false;
			}
		}
		
		return true;
	}
	
	public boolean isEating()
	{
		return oldSlot != -1;
	}
	
	private boolean isClickable(class_239 hitResult)
	{
		if(hitResult == null)
			return false;
		
		if(hitResult instanceof class_3966)
		{
			class_1297 entity = ((class_3966)hitResult).method_17782();
			return entity instanceof class_1646
				|| entity instanceof class_1321;
		}
		
		if(hitResult instanceof class_3965)
		{
			class_2338 pos = ((class_3965)hitResult).method_17777();
			if(pos == null)
				return false;
			
			class_2248 block = MC.field_1687.method_8320(pos).method_26204();
			return block instanceof class_2237
				|| block instanceof class_2304;
		}
		
		return false;
	}
	
	private boolean isInjured(class_746 player)
	{
		int injuryThresholdI = (int)(injuryThreshold.getValue() * 2);
		return player.method_6032() < player.method_6063() - injuryThresholdI;
	}
	
	private enum TakeItemsFrom
	{
		HANDS("Hands", 0),
		
		HOTBAR("Hotbar", 9),
		
		INVENTORY("Inventory", 36);
		
		private final String name;
		private final int maxInvSlot;
		
		private TakeItemsFrom(String name, int maxInvSlot)
		{
			this.name = name;
			this.maxInvSlot = maxInvSlot;
		}
		
		@Override
		public String toString()
		{
			return name;
		}
	}
}
