/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import java.util.Optional;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_2873;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.EnumSetting;
import net.wurstclient.util.ChatUtils;

@SearchTags({"troll potion", "TrollingPotion", "trolling potion"})
public final class TrollPotionHack extends Hack
{
	private final EnumSetting<PotionType> potionType =
		new EnumSetting<>("Potion type", "The type of potion to generate.",
			PotionType.values(), PotionType.SPLASH);
	
	public TrollPotionHack()
	{
		super("TrollPotion");
		setCategory(Category.ITEMS);
		addSetting(potionType);
	}
	
	@Override
	protected void onEnable()
	{
		// check gamemode
		if(!MC.field_1724.method_31549().field_7477)
		{
			ChatUtils.error("Creative mode only.");
			setEnabled(false);
			return;
		}
		
		// generate potion
		class_1799 stack = potionType.getSelected().createPotionStack();
		
		// give potion
		if(placeStackInHotbar(stack))
			ChatUtils.message("Potion created.");
		else
			ChatUtils.error("Please clear a slot in your hotbar.");
		
		setEnabled(false);
	}
	
	private boolean placeStackInHotbar(class_1799 stack)
	{
		for(int i = 0; i < 9; i++)
		{
			if(!MC.field_1724.method_31548().method_5438(i).method_7960())
				continue;
			
			MC.field_1724.field_3944.method_52787(
				new class_2873(36 + i, stack));
			return true;
		}
		
		return false;
	}
	
	private enum PotionType
	{
		NORMAL("Normal", "Potion", class_1802.field_8574),
		
		SPLASH("Splash", "Splash Potion", class_1802.field_8436),
		
		LINGERING("Lingering", "Lingering Potion", class_1802.field_8150),
		
		ARROW("Arrow", "Arrow", class_1802.field_8087);
		
		private final String name;
		private final String itemName;
		private final class_1792 item;
		
		private PotionType(String name, String itemName, class_1792 item)
		{
			this.name = name;
			this.itemName = itemName;
			this.item = item;
		}
		
		@Override
		public String toString()
		{
			return name;
		}
		
		public class_1799 createPotionStack()
		{
			class_1799 stack = new class_1799(item);
			
			ArrayList<class_1293> effects = new ArrayList<>();
			for(int i = 1; i <= 23; i++)
			{
				class_1291 effect =
					class_7923.field_41174.method_40265(i).get().comp_349();
				class_6880<class_1291> entry =
					class_7923.field_41174.method_47983(effect);
				
				effects.add(new class_1293(entry, Integer.MAX_VALUE,
					Integer.MAX_VALUE));
			}
			
			stack.method_57379(class_9334.field_49651,
				new class_1844(Optional.empty(), Optional.empty(),
					effects, Optional.empty()));
			
			String name = "\u00a7f" + itemName + " of Trolling";
			stack.method_57379(class_9334.field_49631, class_2561.method_43470(name));
			
			return stack;
		}
	}
}
