/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient;

import java.util.OptionalDouble;
import net.minecraft.class_10799;
import net.minecraft.class_1921;
import net.minecraft.class_4668;

public enum WurstRenderLayers
{
	;
	
	/**
	 * Similar to {@link class_1921#method_49043(double)}, but as a
	 * non-srip version with support for transparency.
	 *
	 * @implNote Just like {@link class_1921#method_49043(double)}, this
	 *           layer doesn't support any other line width than 1px. Changing
	 *           the line width number does nothing.
	 */
	public static final class_1921.class_4687 ONE_PIXEL_LINES = class_1921.method_24048(
		"wurst:1px_lines", 1536, WurstShaderPipelines.ONE_PIXEL_LINES,
		class_1921.class_4688.method_23598()
			.method_23609(new class_4668.class_4677(OptionalDouble.of(1)))
			.method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_49043(double)}, but with
	 * support for transparency.
	 *
	 * @implNote Just like {@link class_1921#method_49043(double)}, this
	 *           layer doesn't support any other line width than 1px. Changing
	 *           the line width number does nothing.
	 */
	public static final class_1921.class_4687 ONE_PIXEL_LINE_STRIP =
		class_1921.method_24048("wurst:1px_line_strip", 1536,
			WurstShaderPipelines.ONE_PIXEL_LINE_STRIP,
			class_1921.class_4688.method_23598()
				.method_23609(new class_4668.class_4677(OptionalDouble.of(1)))
				.method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_23594()}, but with line width 2.
	 */
	public static final class_1921.class_4687 LINES =
		class_1921.method_24048("wurst:lines", 1536, class_10799.field_56833,
			class_1921.class_4688.method_23598()
				.method_23609(new class_4668.class_4677(OptionalDouble.of(2)))
				.method_23607(class_1921.field_22241)
				.method_23610(class_1921.field_25643).method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_23594()}, but with line width 2 and no
	 * depth test.
	 */
	public static final class_1921.class_4687 ESP_LINES =
		class_1921.method_24048("wurst:esp_lines", 1536, WurstShaderPipelines.ESP_LINES,
			class_1921.class_4688.method_23598()
				.method_23609(new class_4668.class_4677(OptionalDouble.of(2)))
				.method_23607(class_1921.field_22241)
				.method_23610(class_1921.field_25643).method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_34572()}, but with line width 2.
	 */
	public static final class_1921.class_4687 LINE_STRIP = class_1921.method_24049(
		"wurst:line_strip", 1536, false, true, class_10799.field_56835,
		class_1921.class_4688.method_23598()
			.method_23609(new class_4668.class_4677(OptionalDouble.of(2)))
			.method_23607(class_1921.field_22241)
			.method_23610(class_1921.field_25643).method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_34572()}, but with line width 2 and
	 * no depth test.
	 */
	public static final class_1921.class_4687 ESP_LINE_STRIP =
		class_1921.method_24049("wurst:esp_line_strip", 1536, false, true,
			WurstShaderPipelines.ESP_LINE_STRIP,
			class_1921.class_4688.method_23598()
				.method_23609(new class_4668.class_4677(OptionalDouble.of(2)))
				.method_23607(class_1921.field_22241)
				.method_23610(class_1921.field_25643).method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_49042()}, but with culling enabled.
	 */
	public static final class_1921.class_4687 QUADS = class_1921.method_24049(
		"wurst:quads", 1536, false, true, WurstShaderPipelines.QUADS,
		class_1921.class_4688.method_23598().method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_49042()}, but with culling enabled
	 * and no depth test.
	 */
	public static final class_1921.class_4687 ESP_QUADS = class_1921.method_24049(
		"wurst:esp_quads", 1536, false, true, WurstShaderPipelines.ESP_QUADS,
		class_1921.class_4688.method_23598().method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_49042()}, but with no depth test.
	 */
	public static final class_1921.class_4687 ESP_QUADS_NO_CULLING =
		class_1921.method_24049("wurst:esp_quads_no_culling", 1536, false, true,
			WurstShaderPipelines.ESP_QUADS_NO_CULLING,
			class_1921.class_4688.method_23598().method_23617(false));
	
	/**
	 * Returns either {@link #QUADS} or {@link #ESP_QUADS} depending on the
	 * value of {@code depthTest}.
	 */
	public static class_1921 getQuads(boolean depthTest)
	{
		return depthTest ? QUADS : ESP_QUADS;
	}
	
	/**
	 * Returns either {@link #LINES} or {@link #ESP_LINES} depending on the
	 * value of {@code depthTest}.
	 */
	public static class_1921 getLines(boolean depthTest)
	{
		return depthTest ? LINES : ESP_LINES;
	}
	
	/**
	 * Returns either {@link #LINE_STRIP} or {@link #ESP_LINE_STRIP} depending
	 * on the value of {@code depthTest}.
	 */
	public static class_1921 getLineStrip(boolean depthTest)
	{
		return depthTest ? LINE_STRIP : ESP_LINE_STRIP;
	}
}
