/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.minecraft.class_481.class_483;
import net.wurstclient.WurstClient;

@Mixin(class_481.class)
public abstract class CreativeInventoryScreenMixin
	extends class_465<class_481.class_483>
{
	private CreativeInventoryScreenMixin(WurstClient wurst,
		class_483 screenHandler, class_1661 inventory,
		class_2561 title)
	{
		super(screenHandler, inventory, title);
	}
	
	@Inject(at = @At("HEAD"),
		method = "shouldShowOperatorTab(Lnet/minecraft/entity/player/PlayerEntity;)Z",
		cancellable = true)
	private void onShouldShowOperatorTab(class_1657 player,
		CallbackInfoReturnable<Boolean> cir)
	{
		if(WurstClient.INSTANCE.isEnabled())
			cir.setReturnValue(true);
	}
}
