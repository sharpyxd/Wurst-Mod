/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_310;
import net.minecraft.class_350;
import net.minecraft.class_4265;
import net.minecraft.class_459;
import net.wurstclient.WurstClient;

@Mixin(class_459.class)
public abstract class ControlsListWidgetMixin
	extends class_4265<class_459.class_461>
{
	public ControlsListWidgetMixin(WurstClient wurst, class_310 client,
		int width, int height, int y, int itemHeight)
	{
		super(client, width, height, y, itemHeight);
	}
	
	/**
	 * Prevents Wurst's zoom keybind from being added to the controls list.
	 */
	@WrapOperation(at = @At(value = "INVOKE",
		target = "Lnet/minecraft/client/gui/screen/option/ControlsListWidget;addEntry(Lnet/minecraft/client/gui/widget/EntryListWidget$Entry;)I",
		ordinal = 1),
		method = "<init>(Lnet/minecraft/client/gui/screen/option/KeybindsScreen;Lnet/minecraft/client/MinecraftClient;)V")
	private int dontAddZoomEntry(class_459 instance,
		class_350.class_351<?> entry, Operation<Integer> original)
	{
		if(!(entry instanceof class_459.class_462 kbEntry))
			return original.call(instance, entry);
		
		class_2561 name = kbEntry.field_2741;
		if(name == null || !(name
			.method_10851() instanceof class_2588 trContent))
			return original.call(instance, entry);
		
		if(!"key.wurst.zoom".equals(trContent.method_11022()))
			return original.call(instance, entry);
		
		return 0;
	}
}
