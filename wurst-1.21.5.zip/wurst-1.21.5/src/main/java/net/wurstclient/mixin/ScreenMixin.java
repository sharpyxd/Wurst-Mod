/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_332;
import net.minecraft.class_362;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.wurstclient.WurstClient;

@Mixin(class_437.class)
public abstract class ScreenMixin extends class_362
	implements class_4068
{
	@Inject(at = @At("HEAD"),
		method = "renderInGameBackground(Lnet/minecraft/client/gui/DrawContext;)V",
		cancellable = true)
	public void onRenderInGameBackground(class_332 context, CallbackInfo ci)
	{
		if(WurstClient.INSTANCE.getHax().noBackgroundHack
			.shouldCancelBackground((class_437)(Object)this))
			ci.cancel();
	}
}
