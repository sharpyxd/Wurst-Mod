/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.ai;

import java.util.ArrayList;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2399;
import net.minecraft.class_243;
import net.minecraft.class_2541;
import net.minecraft.class_3532;
import net.wurstclient.WurstClient;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.RotationUtils;

public class WalkPathProcessor extends PathProcessor
{
	public WalkPathProcessor(ArrayList<PathPos> path)
	{
		super(path);
	}
	
	@Override
	public void process()
	{
		// get positions
		class_2338 pos;
		if(WurstClient.MC.field_1724.method_24828())
			pos = class_2338.method_49637(WurstClient.MC.field_1724.method_23317(),
				WurstClient.MC.field_1724.method_23318() + 0.5,
				WurstClient.MC.field_1724.method_23321());
		else
			pos = class_2338.method_49638(WurstClient.MC.field_1724.method_19538());
		PathPos nextPos = path.get(index);
		int posIndex = path.indexOf(pos);
		
		if(posIndex == -1)
			ticksOffPath++;
		else
			ticksOffPath = 0;
		
		// update index
		if(pos.equals(nextPos))
		{
			index++;
			
			// disable when done
			if(index >= path.size())
				done = true;
			return;
		}
		if(posIndex > index)
		{
			index = posIndex + 1;
			
			// disable when done
			if(index >= path.size())
				done = true;
			return;
		}
		
		lockControls();
		WurstClient.MC.field_1724.method_31549().field_7479 = false;
		
		// face next position
		facePosition(nextPos);
		if(class_3532.method_15393(Math.abs(RotationUtils
			.getHorizontalAngleToLookVec(class_243.method_24953(nextPos)))) > 90)
			return;
		
		if(WURST.getHax().jesusHack.isEnabled())
		{
			// wait for Jesus to swim up
			if(WurstClient.MC.field_1724.method_23318() < nextPos.method_10264()
				&& (WurstClient.MC.field_1724.method_5799()
					|| WurstClient.MC.field_1724.method_5771()))
				return;
			
			// manually swim down if using Jesus
			if(WurstClient.MC.field_1724.method_23318() - nextPos.method_10264() > 0.5
				&& (WurstClient.MC.field_1724.method_5799()
					|| WurstClient.MC.field_1724.method_5771()
					|| WURST.getHax().jesusHack.isOverLiquid()))
				MC.field_1690.field_1832.method_23481(true);
		}
		
		// horizontal movement
		if(pos.method_10263() != nextPos.method_10263() || pos.method_10260() != nextPos.method_10260())
		{
			MC.field_1690.field_1894.method_23481(true);
			
			if(index > 0 && path.get(index - 1).isJumping()
				|| pos.method_10264() < nextPos.method_10264())
				MC.field_1690.field_1903.method_23481(true);
			
			// vertical movement
		}else if(pos.method_10264() != nextPos.method_10264())
			// go up
			if(pos.method_10264() < nextPos.method_10264())
			{
				// climb up
				// TODO: Spider
				class_2248 block = BlockUtils.getBlock(pos);
				if(block instanceof class_2399 || block instanceof class_2541)
				{
					WURST.getRotationFaker().faceVectorClientIgnorePitch(
						BlockUtils.getBoundingBox(pos).method_1005());
					
					MC.field_1690.field_1894.method_23481(true);
					
				}else
				{
					// directional jump
					if(index < path.size() - 1
						&& !nextPos.method_10084().equals(path.get(index + 1)))
						index++;
					
					// jump up
					MC.field_1690.field_1903.method_23481(true);
				}
				
				// go down
			}else
			{
				// skip mid-air nodes and go straight to the bottom
				while(index < path.size() - 1
					&& path.get(index).method_10074().equals(path.get(index + 1)))
					index++;
				
				// walk off the edge
				if(WurstClient.MC.field_1724.method_24828())
					MC.field_1690.field_1894.method_23481(true);
			}
	}
	
	@Override
	public boolean canBreakBlocks()
	{
		return MC.field_1724.method_24828();
	}
}
