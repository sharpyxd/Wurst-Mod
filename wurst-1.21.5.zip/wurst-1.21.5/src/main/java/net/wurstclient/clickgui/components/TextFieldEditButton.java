/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.clickgui.components;

import java.util.Objects;

import org.lwjgl.glfw.GLFW;
import net.minecraft.class_2583;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.wurstclient.clickgui.ClickGui;
import net.wurstclient.clickgui.Component;
import net.wurstclient.clickgui.screens.EditTextFieldScreen;
import net.wurstclient.settings.TextFieldSetting;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.RenderUtils;

public final class TextFieldEditButton extends Component
{
	private static final ClickGui GUI = WURST.getGui();
	private static final class_327 TR = MC.field_1772;
	private static final int TEXT_HEIGHT = 11;
	
	private final TextFieldSetting setting;
	
	public TextFieldEditButton(TextFieldSetting setting)
	{
		this.setting = Objects.requireNonNull(setting);
		setWidth(getDefaultWidth());
		setHeight(getDefaultHeight());
	}
	
	@Override
	public void handleMouseClick(double mouseX, double mouseY, int mouseButton)
	{
		if(mouseY < getY() + TEXT_HEIGHT)
			return;
		
		switch(mouseButton)
		{
			case GLFW.GLFW_MOUSE_BUTTON_LEFT:
			MC.method_1507(new EditTextFieldScreen(MC.field_1755, setting));
			break;
			
			case GLFW.GLFW_MOUSE_BUTTON_RIGHT:
			setting.resetToDefault();
			break;
		}
	}
	
	@Override
	public void render(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		float[] bgColor = GUI.getBgColor();
		float opacity = GUI.getOpacity();
		
		int x1 = getX();
		int x2 = x1 + getWidth();
		int y1 = getY();
		int y2 = y1 + getHeight();
		int y3 = y1 + TEXT_HEIGHT;
		
		boolean hovering = isHovering(mouseX, mouseY);
		boolean hText = hovering && mouseY < y3;
		boolean hBox = hovering && mouseY >= y3;
		
		if(hText)
			GUI.setTooltip(ChatUtils.wrapText(setting.getDescription(), 200));
		else if(hBox)
			GUI.setTooltip(ChatUtils.wrapText(setting.getValue(), 200));
		
		// background
		context.method_25294(x1, y1, x2, y3, RenderUtils.toIntColor(bgColor, opacity));
		
		// box
		context.method_25294(x1, y3, x2, y2,
			RenderUtils.toIntColor(bgColor, opacity * (hBox ? 1.5F : 1)));
		RenderUtils.drawBorder2D(context, x1, y3, x2, y2,
			RenderUtils.toIntColor(GUI.getAcColor(), 0.5F));
		
		// text
		int txtColor = GUI.getTxtColor();
		context.method_51433(TR, setting.getName(), x1, y1 + 2, txtColor, false);
		String value = setting.getValue();
		int maxWidth = getWidth() - TR.method_1727("...") - 2;
		int maxLength = TR.method_27527().method_35715(value,
			maxWidth, class_2583.field_24360);
		if(maxLength < value.length())
			value = value.substring(0, maxLength) + "...";
		context.method_51433(TR, value, x1 + 2, y3 + 2, txtColor, false);
	}
	
	@Override
	public int getDefaultWidth()
	{
		return TR.method_1727(setting.getName()) + 4;
	}
	
	@Override
	public int getDefaultHeight()
	{
		return TEXT_HEIGHT * 2;
	}
}
