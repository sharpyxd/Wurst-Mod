/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.clickgui.screens;

import java.util.Objects;

import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;
import net.minecraft.class_156;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_4280;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9636;
import net.wurstclient.hacks.autolibrarian.BookOffer;
import net.wurstclient.settings.BookOffersSetting;
import net.wurstclient.util.MathUtils;
import net.wurstclient.util.RenderUtils;

public final class AddBookOfferScreen extends class_437
{
	private final class_437 prevScreen;
	private final BookOffersSetting bookOffers;
	
	private ListGui listGui;
	
	private class_342 levelField;
	private class_4185 levelPlusButton;
	private class_4185 levelMinusButton;
	
	private class_342 priceField;
	private class_4185 pricePlusButton;
	private class_4185 priceMinusButton;
	
	private class_4185 addButton;
	private class_4185 cancelButton;
	
	private BookOffer offerToAdd;
	private boolean alreadyAdded;
	
	public AddBookOfferScreen(class_437 prevScreen, BookOffersSetting bookOffers)
	{
		super(class_2561.method_43470(""));
		this.prevScreen = prevScreen;
		this.bookOffers = bookOffers;
	}
	
	@Override
	public void method_25426()
	{
		listGui = new ListGui(field_22787, this);
		method_25429(listGui);
		
		levelField = new class_342(field_22787.field_1772, field_22789 / 2 - 32,
			field_22790 - 74, 28, 12, class_2561.method_43470(""));
		method_25429(levelField);
		levelField.method_1880(2);
		levelField.method_1890(t -> {
			if(t.isEmpty())
				return true;
			
			if(!MathUtils.isInteger(t))
				return false;
			
			int level = Integer.parseInt(t);
			if(level < 1 || level > 10)
				return false;
			
			if(offerToAdd == null)
				return true;
			
			class_1887 enchantment = offerToAdd.getEnchantment();
			return level <= enchantment.method_8183();
		});
		levelField.method_1863(t -> {
			if(!MathUtils.isInteger(t))
				return;
			
			int level = Integer.parseInt(t);
			updateLevel(level, false);
		});
		
		priceField = new class_342(field_22787.field_1772, field_22789 / 2 - 32,
			field_22790 - 58, 28, 12, class_2561.method_43470(""));
		method_25429(priceField);
		priceField.method_1880(2);
		priceField.method_1890(t -> t.isEmpty() || MathUtils.isInteger(t)
			&& Integer.parseInt(t) >= 1 && Integer.parseInt(t) <= 64);
		priceField.method_1863(t -> {
			if(!MathUtils.isInteger(t))
				return;
			
			int price = Integer.parseInt(t);
			updatePrice(price, false);
		});
		
		method_37063(levelPlusButton =
			class_4185.method_46430(class_2561.method_43470("+"), b -> updateLevel(1, true))
				.method_46434(field_22789 / 2 + 2, field_22790 - 74, 20, 12)
				.method_46435(sup -> class_2561
					.method_43469("gui.narrate.button", "increase level")
					.method_27693(", current value: " + levelField.method_1882()))
				.method_46431());
		levelPlusButton.field_22763 = false;
		
		method_37063(levelMinusButton =
			class_4185.method_46430(class_2561.method_43470("-"), b -> updateLevel(-1, true))
				.method_46434(field_22789 / 2 + 26, field_22790 - 74, 20, 12)
				.method_46435(sup -> class_2561
					.method_43469("gui.narrate.button", "decrease level")
					.method_27693(", current value: " + levelField.method_1882()))
				.method_46431());
		levelMinusButton.field_22763 = false;
		
		method_37063(pricePlusButton = class_4185
			.method_46430(class_2561.method_43470("+"), b -> updatePrice(1, true))
			.method_46434(field_22789 / 2 + 2, field_22790 - 58, 20, 12)
			.method_46435(sup -> class_2561
				.method_43469("gui.narrate.button", "increase max price")
				.method_27693(", current value: " + priceField.method_1882()))
			.method_46431());
		pricePlusButton.field_22763 = false;
		
		method_37063(priceMinusButton = class_4185
			.method_46430(class_2561.method_43470("-"), b -> updatePrice(-1, true))
			.method_46434(field_22789 / 2 + 26, field_22790 - 58, 20, 12)
			.method_46435(sup -> class_2561
				.method_43469("gui.narrate.button", "decrease max price")
				.method_27693(", current value: " + priceField.method_1882()))
			.method_46431());
		priceMinusButton.field_22763 = false;
		
		method_37063(
			addButton = class_4185.method_46430(class_2561.method_43470("Add"), b -> {
				bookOffers.add(offerToAdd);
				field_22787.method_1507(prevScreen);
			}).method_46434(field_22789 / 2 - 102, field_22790 - 28, 100, 20).method_46431());
		addButton.field_22763 = false;
		
		method_37063(cancelButton = class_4185
			.method_46430(class_2561.method_43470("Cancel"), b -> field_22787.method_1507(prevScreen))
			.method_46434(field_22789 / 2 + 2, field_22790 - 28, 100, 20).method_46431());
	}
	
	private void updateLevel(int i, boolean offset)
	{
		if(offerToAdd == null)
			return;
		
		String id = offerToAdd.id();
		int level = offset ? offerToAdd.level() + i : i;
		int price = offerToAdd.price();
		
		class_1887 enchantment = offerToAdd.getEnchantment();
		if(level < 1 || level > enchantment.method_8183())
			return;
		
		updateSelectedOffer(new BookOffer(id, level, price));
	}
	
	private void updatePrice(int i, boolean offset)
	{
		if(offerToAdd == null)
			return;
		
		String id = offerToAdd.id();
		int level = offerToAdd.level();
		int price = offset ? offerToAdd.price() + i : i;
		
		if(price < 1 || price > 64)
			return;
		
		updateSelectedOffer(new BookOffer(id, level, price));
	}
	
	private void updateSelectedOffer(BookOffer offer)
	{
		offerToAdd = offer;
		alreadyAdded = offer != null && bookOffers.contains(offer);
		addButton.field_22763 = offer != null && !alreadyAdded;
		
		if(offer == null)
		{
			if(!levelField.method_1882().isEmpty())
				levelField.method_1852("");
			
			if(!priceField.method_1882().isEmpty())
				priceField.method_1852("");
			
		}else
		{
			String level = "" + offer.level();
			if(!levelField.method_1882().equals(level))
				levelField.method_1852(level);
			
			String price = "" + offer.price();
			if(!priceField.method_1882().equals(price))
				priceField.method_1852(price);
		}
	}
	
	@Override
	public boolean method_25402(double mouseX, double mouseY, int mouseButton)
	{
		boolean childClicked = super.method_25402(mouseX, mouseY, mouseButton);
		
		levelField.method_25402(mouseX, mouseY, mouseButton);
		priceField.method_25402(mouseX, mouseY, mouseButton);
		
		if(mouseButton == GLFW.GLFW_MOUSE_BUTTON_4)
			cancelButton.method_25306();
		
		return childClicked;
	}
	
	@Override
	public boolean method_25404(int keyCode, int scanCode, int int_3)
	{
		switch(keyCode)
		{
			case GLFW.GLFW_KEY_ENTER:
			if(addButton.field_22763)
				addButton.method_25306();
			break;
			
			case GLFW.GLFW_KEY_ESCAPE:
			cancelButton.method_25306();
			break;
			
			default:
			break;
		}
		
		return super.method_25404(keyCode, scanCode, int_3);
	}
	
	@Override
	public void method_25393()
	{
		levelPlusButton.field_22763 = offerToAdd != null
			&& offerToAdd.level() < offerToAdd.getEnchantment().method_8183();
		levelMinusButton.field_22763 = offerToAdd != null && offerToAdd.level() > 1;
		
		pricePlusButton.field_22763 = offerToAdd != null && offerToAdd.price() < 64;
		priceMinusButton.field_22763 = offerToAdd != null && offerToAdd.price() > 1;
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		class_4587 matrixStack = context.method_51448();
		method_25420(context, mouseX, mouseY, partialTicks);
		
		listGui.method_25394(context, mouseX, mouseY, partialTicks);
		
		matrixStack.method_22903();
		matrixStack.method_46416(0, 0, 300);
		
		class_327 tr = field_22787.field_1772;
		String titleText =
			"Available Books (" + listGui.method_25396().size() + ")";
		context.method_25300(tr, titleText, field_22789 / 2, 12,
			0xffffff);
		
		levelField.method_25394(context, mouseX, mouseY, partialTicks);
		priceField.method_25394(context, mouseX, mouseY, partialTicks);
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
		
		matrixStack.method_46416(field_22789 / 2 - 100, 0, 0);
		
		context.method_25303(tr, "Level:", 0, field_22790 - 72, 0xf0f0f0);
		context.method_25303(tr, "Max price:", 0, field_22790 - 56, 0xf0f0f0);
		
		if(alreadyAdded && offerToAdd != null)
		{
			String errorText = offerToAdd.getEnchantmentNameWithLevel()
				+ " is already on your list!";
			context.method_25303(tr, errorText, 0, field_22790 - 40, 0xff5555);
		}
		
		matrixStack.method_22909();
		
		RenderUtils.drawItem(context, new class_1799(class_1802.field_8687),
			field_22789 / 2 - 16, field_22790 - 58, false);
	}
	
	@Override
	public boolean method_25421()
	{
		return false;
	}
	
	@Override
	public boolean method_25422()
	{
		return false;
	}
	
	private final class Entry
		extends class_4280.class_4281<AddBookOfferScreen.Entry>
	{
		private final BookOffer bookOffer;
		private long lastClickTime;
		
		public Entry(BookOffer bookOffer)
		{
			this.bookOffer = Objects.requireNonNull(bookOffer);
		}
		
		@Override
		public class_2561 method_37006()
		{
			class_6880<class_1887> enchantment =
				bookOffer.getEnchantmentEntry().get();
			
			int maxLevel = enchantment.comp_349().method_8183();
			String levels = maxLevel + (maxLevel == 1 ? " level" : " levels");
			
			return class_2561.method_43469("narrator.select",
				"Enchantment " + bookOffer.getEnchantmentName() + ", ID "
					+ bookOffer.id() + ", " + levels);
		}
		
		@Override
		public boolean method_25402(double mouseX, double mouseY,
			int mouseButton)
		{
			if(mouseButton != GLFW.GLFW_MOUSE_BUTTON_LEFT)
				return false;
			
			long timeSinceLastClick = class_156.method_658() - lastClickTime;
			lastClickTime = class_156.method_658();
			
			if(timeSinceLastClick < 250 && addButton.field_22763)
				addButton.method_25306();
			
			return true;
		}
		
		@Override
		public void method_25343(class_332 context, int index, int y, int x,
			int entryWidth, int entryHeight, int mouseX, int mouseY,
			boolean hovered, float tickDelta)
		{
			class_1792 item = class_7923.field_41178.method_63535(class_2960.method_60654("enchanted_book"));
			class_1799 stack = new class_1799(item);
			RenderUtils.drawItem(context, stack, x + 1, y + 1, true);
			
			class_327 tr = field_22787.field_1772;
			class_6880<class_1887> enchantment =
				bookOffer.getEnchantmentEntry().get();
			
			String name = bookOffer.getEnchantmentName();
			int nameColor =
				enchantment.method_40220(class_9636.field_51551) ? 0xFF5555 : 0xF0F0F0;
			context.method_51433(tr, name, x + 28, y, nameColor, false);
			
			context.method_51433(tr, bookOffer.id(), x + 28, y + 9, 0xA0A0A0,
				false);
			
			int maxLevel = enchantment.comp_349().method_8183();
			String levels = maxLevel + (maxLevel == 1 ? " level" : " levels");
			context.method_51433(tr, levels, x + 28, y + 18, 0xA0A0A0, false);
		}
	}
	
	private final class ListGui
		extends class_4280<AddBookOfferScreen.Entry>
	{
		public ListGui(class_310 minecraft, AddBookOfferScreen screen)
		{
			super(minecraft, screen.field_22789, screen.field_22790 - 120, 36, 30, 0);
			
			class_5455 drm = field_22740.field_1687.method_30349();
			class_2378<class_1887> registry =
				drm.method_30530(class_7924.field_41265);
			
			registry.method_10220().map(BookOffer::create)
				.filter(BookOffer::isFullyValid).sorted()
				.map(AddBookOfferScreen.Entry::new).forEach(this::method_25321);
		}
		
		@Override
		public void setSelected(@Nullable AddBookOfferScreen.Entry entry)
		{
			super.method_25313(entry);
			updateSelectedOffer(entry == null ? null : entry.bookOffer);
		}
	}
}
