/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.clickgui.screens;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

import org.lwjgl.glfw.GLFW;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.wurstclient.settings.ColorSetting;
import net.wurstclient.util.ColorUtils;

public final class EditColorScreen extends class_437
{
	private final class_437 prevScreen;
	private final ColorSetting colorSetting;
	private Color color;
	
	private class_342 hexValueField;
	private class_342 redValueField;
	private class_342 greenValueField;
	private class_342 blueValueField;
	
	private class_4185 doneButton;
	
	private final class_2960 paletteIdentifier =
		class_2960.method_60655("wurst", "colorpalette.png");
	private BufferedImage paletteAsBufferedImage;
	
	private int paletteX = 0;
	private int paletteY = 0;
	
	private final int paletteWidth = 200;
	private final int paletteHeight = 84;
	
	private int fieldsX = 0;
	private int fieldsY = 0;
	
	private boolean ignoreChanges;
	
	public EditColorScreen(class_437 prevScreen, ColorSetting colorSetting)
	{
		super(class_2561.method_43470(""));
		this.prevScreen = prevScreen;
		this.colorSetting = colorSetting;
		color = colorSetting.getColor();
	}
	
	@Override
	public void method_25426()
	{
		// Cache color palette
		try(InputStream stream = field_22787.method_1478()
			.getResourceOrThrow(paletteIdentifier).method_14482())
		{
			paletteAsBufferedImage = ImageIO.read(stream);
			
		}catch(IOException e)
		{
			paletteAsBufferedImage = null;
			e.printStackTrace();
		}
		
		class_327 tr = field_22787.field_1772;
		paletteX = field_22789 / 2 - 100;
		paletteY = 32;
		fieldsX = field_22789 / 2 - 100;
		fieldsY = 129 + 5;
		
		hexValueField =
			new class_342(tr, fieldsX, fieldsY, 92, 20, class_2561.method_43470(""));
		hexValueField.method_1852(ColorUtils.toHex(color).substring(1));
		hexValueField.method_1880(6);
		hexValueField.method_1863(s -> updateColor(true));
		
		// RGB fields
		redValueField = new class_342(tr, fieldsX, fieldsY + 35, 50, 20,
			class_2561.method_43470(""));
		redValueField.method_1852("" + color.getRed());
		redValueField.method_1880(3);
		redValueField.method_1863(s -> updateColor(false));
		
		greenValueField = new class_342(tr, fieldsX + 75, fieldsY + 35,
			50, 20, class_2561.method_43470(""));
		greenValueField.method_1852("" + color.getGreen());
		greenValueField.method_1880(3);
		greenValueField.method_1863(s -> updateColor(false));
		
		blueValueField = new class_342(tr, fieldsX + 150, fieldsY + 35,
			50, 20, class_2561.method_43470(""));
		blueValueField.method_1852("" + color.getBlue());
		blueValueField.method_1880(3);
		blueValueField.method_1863(s -> updateColor(false));
		
		method_25429(hexValueField);
		method_25429(redValueField);
		method_25429(greenValueField);
		method_25429(blueValueField);
		
		method_25395(hexValueField);
		hexValueField.method_25365(true);
		hexValueField.method_1875(0);
		hexValueField.method_1884(6);
		
		doneButton = class_4185.method_46430(class_2561.method_43470("Done"), b -> done())
			.method_46434(fieldsX, field_22790 - 30, 200, 20).method_46431();
		method_37063(doneButton);
	}
	
	private void updateColor(boolean hex)
	{
		if(ignoreChanges)
			return;
		
		Color newColor;
		
		if(hex)
			newColor = ColorUtils.tryParseHex("#" + hexValueField.method_1882());
		else
			newColor = ColorUtils.tryParseRGB(redValueField.method_1882(),
				greenValueField.method_1882(), blueValueField.method_1882());
		
		if(newColor == null || newColor.equals(color))
			return;
		
		color = newColor;
		ignoreChanges = true;
		hexValueField.method_1852(ColorUtils.toHex(color).substring(1));
		redValueField.method_1852("" + color.getRed());
		greenValueField.method_1852("" + color.getGreen());
		blueValueField.method_1852("" + color.getBlue());
		ignoreChanges = false;
	}
	
	private void done()
	{
		colorSetting.setColor(color);
		field_22787.method_1507(prevScreen);
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		class_327 tr = field_22787.field_1772;
		
		method_25420(context, mouseX, mouseY, partialTicks);
		context.method_25300(field_22787.field_1772,
			colorSetting.getName(), field_22789 / 2, 16, 0xF0F0F0);
		
		// Draw palette
		int x = paletteX;
		int y = paletteY;
		int w = paletteWidth;
		int h = paletteHeight;
		int fw = paletteWidth;
		int fh = paletteHeight;
		float u = 0;
		float v = 0;
		context.method_25290(class_1921::method_62277, paletteIdentifier, x,
			y, u, v, w, h, fw, fh);
		
		// RGB letters
		context.method_51433(tr, "#", fieldsX - 3 - tr.method_1727("#"), fieldsY + 6,
			0xF0F0F0, false);
		context.method_51433(tr, "R:", fieldsX - 3 - tr.method_1727("R:"),
			fieldsY + 6 + 35, 0xFF0000, false);
		context.method_51433(tr, "G:", fieldsX + 75 - 3 - tr.method_1727("G:"),
			fieldsY + 6 + 35, 0x00FF00, false);
		context.method_51433(tr, "B:", fieldsX + 150 - 3 - tr.method_1727("B:"),
			fieldsY + 6 + 35, 0x0000FF, false);
		
		hexValueField.method_25394(context, mouseX, mouseY, partialTicks);
		redValueField.method_25394(context, mouseX, mouseY, partialTicks);
		greenValueField.method_25394(context, mouseX, mouseY, partialTicks);
		blueValueField.method_25394(context, mouseX, mouseY, partialTicks);
		
		// Color preview
		
		int borderSize = 1;
		int boxWidth = 92;
		int boxHeight = 20;
		int boxX = field_22789 / 2 + 8;
		int boxY = fieldsY;
		
		// Border
		context.method_25294(boxX - borderSize, boxY - borderSize,
			boxX + boxWidth + borderSize, boxY + boxHeight + borderSize,
			0xFFAAAAAA);
		
		// Color box
		context.method_25294(boxX, boxY, boxX + boxWidth, boxY + boxHeight,
			color.getRGB());
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
	}
	
	@Override
	public void method_25410(class_310 client, int width, int height)
	{
		String hex = hexValueField.method_1882();
		String r = redValueField.method_1882();
		String g = greenValueField.method_1882();
		String b = blueValueField.method_1882();
		
		method_25423(client, width, height);
		
		hexValueField.method_1852(hex);
		redValueField.method_1852(r);
		greenValueField.method_1852(g);
		blueValueField.method_1852(b);
	}
	
	@Override
	public boolean method_25404(int keyCode, int scanCode, int int_3)
	{
		switch(keyCode)
		{
			case GLFW.GLFW_KEY_ENTER:
			done();
			break;
			
			case GLFW.GLFW_KEY_ESCAPE:
			field_22787.method_1507(prevScreen);
			break;
		}
		
		return super.method_25404(keyCode, scanCode, int_3);
	}
	
	@Override
	public boolean method_25402(double mouseX, double mouseY, int button)
	{
		if(mouseX >= paletteX && mouseX <= paletteX + paletteWidth
			&& mouseY >= paletteY && mouseY <= paletteY + paletteHeight)
		{
			if(paletteAsBufferedImage == null)
				return super.method_25402(mouseX, mouseY, button);
			
			int x = (int)Math.round((mouseX - paletteX) / paletteWidth
				* paletteAsBufferedImage.getWidth());
			int y = (int)Math.round((mouseY - paletteY) / paletteHeight
				* paletteAsBufferedImage.getHeight());
			
			if(x > 0 && y > 0 && x < paletteAsBufferedImage.getWidth()
				&& y < paletteAsBufferedImage.getHeight())
			{
				int rgb = paletteAsBufferedImage.getRGB(x, y);
				Color color = new Color(rgb, true);
				
				// Set color if pixel has full alpha
				if(color.getAlpha() >= 255)
					setColor(color);
			}
		}
		
		return super.method_25402(mouseX, mouseY, button);
	}
	
	private void setColor(Color color)
	{
		hexValueField.method_1852(ColorUtils.toHex(color).substring(1));
		redValueField.method_1852("" + color.getRed());
		greenValueField.method_1852("" + color.getGreen());
		blueValueField.method_1852("" + color.getBlue());
	}
	
	@Override
	public boolean method_25421()
	{
		return false;
	}
	
	@Override
	public boolean method_25422()
	{
		return false;
	}
}
