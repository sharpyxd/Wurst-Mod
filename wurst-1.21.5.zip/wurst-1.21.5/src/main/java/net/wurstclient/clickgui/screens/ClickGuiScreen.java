/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.clickgui.screens;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.wurstclient.clickgui.ClickGui;

public final class ClickGuiScreen extends class_437
{
	private final ClickGui gui;
	
	public ClickGuiScreen(ClickGui gui)
	{
		super(class_2561.method_43470(""));
		this.gui = gui;
	}
	
	@Override
	public boolean method_25421()
	{
		return false;
	}
	
	@Override
	public boolean method_25402(double mouseX, double mouseY, int mouseButton)
	{
		gui.handleMouseClick((int)mouseX, (int)mouseY, mouseButton);
		return super.method_25402(mouseX, mouseY, mouseButton);
	}
	
	@Override
	public boolean method_25406(double mouseX, double mouseY, int mouseButton)
	{
		gui.handleMouseRelease(mouseX, mouseY, mouseButton);
		return super.method_25406(mouseX, mouseY, mouseButton);
	}
	
	@Override
	public boolean method_25401(double mouseX, double mouseY,
		double horizontalAmount, double verticalAmount)
	{
		gui.handleMouseScroll(mouseX, mouseY, verticalAmount);
		return super.method_25401(mouseX, mouseY, horizontalAmount,
			verticalAmount);
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
		
		gui.render(context, mouseX, mouseY, partialTicks);
	}
}
