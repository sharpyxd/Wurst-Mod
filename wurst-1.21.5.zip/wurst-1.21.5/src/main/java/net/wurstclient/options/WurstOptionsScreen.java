/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.options;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_156;
import net.minecraft.class_156.class_158;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.wurstclient.WurstClient;
import net.wurstclient.analytics.PlausibleAnalytics;
import net.wurstclient.commands.FriendsCmd;
import net.wurstclient.hacks.XRayHack;
import net.wurstclient.other_features.VanillaSpoofOtf;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.util.ChatUtils;

public class WurstOptionsScreen extends class_437
{
	private class_437 prevScreen;
	
	public WurstOptionsScreen(class_437 prevScreen)
	{
		super(class_2561.method_43470(""));
		this.prevScreen = prevScreen;
	}
	
	@Override
	public void method_25426()
	{
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Back"), b -> field_22787.method_1507(prevScreen))
			.method_46434(field_22789 / 2 - 100, field_22790 / 4 + 144 - 16, 200, 20)
			.method_46431());
		
		addSettingButtons();
		addManagerButtons();
		addLinkButtons();
	}
	
	private void addSettingButtons()
	{
		WurstClient wurst = WurstClient.INSTANCE;
		FriendsCmd friendsCmd = wurst.getCmds().friendsCmd;
		CheckboxSetting middleClickFriends = friendsCmd.getMiddleClickFriends();
		PlausibleAnalytics plausible = wurst.getPlausible();
		VanillaSpoofOtf vanillaSpoofOtf = wurst.getOtfs().vanillaSpoofOtf;
		CheckboxSetting forceEnglish =
			wurst.getOtfs().translationsOtf.getForceEnglish();
		
		new WurstOptionsButton(-154, 24,
			() -> "Click Friends: "
				+ (middleClickFriends.isChecked() ? "ON" : "OFF"),
			middleClickFriends.getWrappedDescription(200),
			b -> middleClickFriends
				.setChecked(!middleClickFriends.isChecked()));
		
		new WurstOptionsButton(-154, 48,
			() -> "Count Users: " + (plausible.isEnabled() ? "ON" : "OFF"),
			"Counts how many people are using Wurst and which versions are the"
				+ " most popular. This data helps me to decide when I can stop"
				+ " supporting old versions.\n\n"
				+ "These statistics are completely anonymous, never sold, and"
				+ " stay in the EU (I'm self-hosting Plausible in Germany)."
				+ " There are no cookies or persistent identifiers"
				+ " (see plausible.io).",
			b -> plausible.setEnabled(!plausible.isEnabled()));
		
		new WurstOptionsButton(-154, 72,
			() -> "Spoof Vanilla: "
				+ (vanillaSpoofOtf.isEnabled() ? "ON" : "OFF"),
			vanillaSpoofOtf.getDescription(),
			b -> vanillaSpoofOtf.doPrimaryAction());
		
		new WurstOptionsButton(-154, 96,
			() -> "Translations: " + (!forceEnglish.isChecked() ? "ON" : "OFF"),
			"Allows text in Wurst to be displayed in other languages than"
				+ " English. It will use the same language that Minecraft is"
				+ " set to.\n\n" + "This is an experimental feature!",
			b -> forceEnglish.setChecked(!forceEnglish.isChecked()));
	}
	
	private void addManagerButtons()
	{
		XRayHack xRayHack = WurstClient.INSTANCE.getHax().xRayHack;
		
		new WurstOptionsButton(-50, 24, () -> "Keybinds",
			"Keybinds allow you to toggle any hack or command by simply"
				+ " pressing a button.",
			b -> field_22787.method_1507(new KeybindManagerScreen(this)));
		
		new WurstOptionsButton(-50, 48, () -> "X-Ray Blocks",
			"Manager for the blocks that X-Ray will show.",
			b -> xRayHack.openBlockListEditor(this));
		
		new WurstOptionsButton(-50, 72, () -> "Zoom",
			"The Zoom Manager allows you to change the zoom key and how far it"
				+ " will zoom in.",
			b -> field_22787.method_1507(new ZoomManagerScreen(this)));
	}
	
	private void addLinkButtons()
	{
		class_158 os = class_156.method_668();
		
		new WurstOptionsButton(54, 24, () -> "Official Website",
			"§n§lWurstClient.net",
			b -> os.method_670("https://www.wurstclient.net/options-website/"));
		
		new WurstOptionsButton(54, 48, () -> "Wurst Wiki", "§n§lWurst.Wiki",
			b -> os.method_670("https://www.wurstclient.net/options-wiki/"));
		
		new WurstOptionsButton(54, 72, () -> "WurstForum", "§n§lWurstForum.net",
			b -> os.method_670("https://www.wurstclient.net/options-forum/"));
		
		new WurstOptionsButton(54, 96, () -> "Twitter", "@Wurst_Imperium",
			b -> os.method_670("https://www.wurstclient.net/options-twitter/"));
		
		new WurstOptionsButton(54, 120, () -> "Donate",
			"§n§lWurstClient.net/donate\n"
				+ "Donate now to help me keep the Wurst Client alive and free"
				+ " to use for everyone.\n\n"
				+ "Every bit helps and is much appreciated! You can also get a"
				+ " few cool perks in return.",
			b -> os.method_670("https://www.wurstclient.net/options-donate/"));
	}
	
	@Override
	public void method_25419()
	{
		field_22787.method_1507(prevScreen);
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		method_25420(context, mouseX, mouseY, partialTicks);
		renderTitles(context);
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
		
		renderButtonTooltip(context, mouseX, mouseY);
	}
	
	private void renderTitles(class_332 context)
	{
		class_327 tr = field_22787.field_1772;
		int middleX = field_22789 / 2;
		int y1 = 40;
		int y2 = field_22790 / 4 + 24 - 28;
		
		context.method_25300(tr, "Wurst Options", middleX, y1,
			0xffffff);
		
		context.method_25300(tr, "Settings", middleX - 104, y2,
			0xcccccc);
		context.method_25300(tr, "Managers", middleX, y2,
			0xcccccc);
		context.method_25300(tr, "Links", middleX + 104, y2,
			0xcccccc);
	}
	
	private void renderButtonTooltip(class_332 context, int mouseX,
		int mouseY)
	{
		for(class_339 button : Screens.getButtons(this))
		{
			if(!button.method_25367() || !(button instanceof WurstOptionsButton))
				continue;
			
			WurstOptionsButton woButton = (WurstOptionsButton)button;
			
			if(woButton.tooltip.isEmpty())
				continue;
			
			context.method_51434(field_22793, woButton.tooltip, mouseX, mouseY);
			break;
		}
	}
	
	private final class WurstOptionsButton extends class_4185
	{
		private final Supplier<String> messageSupplier;
		private final List<class_2561> tooltip;
		
		public WurstOptionsButton(int xOffset, int yOffset,
			Supplier<String> messageSupplier, String tooltip,
			class_4241 pressAction)
		{
			super(WurstOptionsScreen.this.field_22789 / 2 + xOffset,
				WurstOptionsScreen.this.field_22790 / 4 - 16 + yOffset, 100, 20,
				class_2561.method_43470(messageSupplier.get()), pressAction,
				class_4185.field_40754);
			
			this.messageSupplier = messageSupplier;
			
			if(tooltip.isEmpty())
				this.tooltip = Arrays.asList();
			else
			{
				String[] lines = ChatUtils.wrapText(tooltip, 200).split("\n");
				
				class_2561[] lines2 = new class_2561[lines.length];
				for(int i = 0; i < lines.length; i++)
					lines2[i] = class_2561.method_43470(lines[i]);
				
				this.tooltip = Arrays.asList(lines2);
			}
			
			method_37063(this);
		}
		
		@Override
		public void method_25306()
		{
			super.method_25306();
			method_25355(class_2561.method_43470(messageSupplier.get()));
		}
	}
}
