/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.settings;

import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import net.minecraft.class_2189;
import net.minecraft.class_2248;
import net.wurstclient.WurstClient;
import net.wurstclient.clickgui.Component;
import net.wurstclient.clickgui.components.BlockComponent;
import net.wurstclient.keybinds.PossibleKeybind;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.json.JsonException;
import net.wurstclient.util.json.JsonUtils;
import net.wurstclient.util.text.WText;

public final class BlockSetting extends Setting
{
	private String blockName = "";
	private final String defaultName;
	private final boolean allowAir;
	
	public BlockSetting(String name, WText description, String blockName,
		boolean allowAir)
	{
		super(name, description);
		
		class_2248 block = BlockUtils.getBlockFromNameOrID(blockName);
		Objects.requireNonNull(block);
		this.blockName = BlockUtils.getName(block);
		
		defaultName = this.blockName;
		this.allowAir = allowAir;
	}
	
	public BlockSetting(String name, String descriptionKey, String blockName,
		boolean allowAir)
	{
		this(name, WText.translated(descriptionKey), blockName, allowAir);
	}
	
	public BlockSetting(String name, String blockName, boolean allowAir)
	{
		this(name, WText.empty(), blockName, allowAir);
	}
	
	/**
	 * @return this setting's {@link class_2248}. Cannot be null.
	 */
	public class_2248 getBlock()
	{
		return BlockUtils.getBlockFromName(blockName);
	}
	
	public String getBlockName()
	{
		return blockName;
	}
	
	public String getShortBlockName()
	{
		return blockName.replace("minecraft:", "");
	}
	
	public void setBlock(class_2248 block)
	{
		if(block == null)
			return;
		
		if(!allowAir && block instanceof class_2189)
			return;
		
		String newName = Objects.requireNonNull(BlockUtils.getName(block));
		
		if(blockName.equals(newName))
			return;
		
		blockName = newName;
		WurstClient.INSTANCE.saveSettings();
	}
	
	public void setBlockName(String blockName)
	{
		class_2248 block = BlockUtils.getBlockFromNameOrID(blockName);
		Objects.requireNonNull(block);
		
		setBlock(block);
	}
	
	public void resetToDefault()
	{
		blockName = defaultName;
		WurstClient.INSTANCE.saveSettings();
	}
	
	@Override
	public Component getComponent()
	{
		return new BlockComponent(this);
	}
	
	@Override
	public void fromJson(JsonElement json)
	{
		try
		{
			String newName = JsonUtils.getAsString(json);
			
			class_2248 newBlock = BlockUtils.getBlockFromNameOrID(newName);
			if(newBlock == null)
				throw new JsonException();
			
			if(!allowAir && newBlock instanceof class_2189)
				throw new JsonException();
			
			blockName = BlockUtils.getName(newBlock);
			
		}catch(JsonException e)
		{
			e.printStackTrace();
			resetToDefault();
		}
	}
	
	@Override
	public JsonElement toJson()
	{
		return new JsonPrimitive(blockName);
	}
	
	@Override
	public JsonObject exportWikiData()
	{
		JsonObject json = new JsonObject();
		json.addProperty("name", getName());
		json.addProperty("description", getDescription());
		json.addProperty("type", "Block");
		json.addProperty("defaultValue", defaultName);
		json.addProperty("allowAir", allowAir);
		return json;
	}
	
	@Override
	public Set<PossibleKeybind> getPossibleKeybinds(String featureName)
	{
		String fullName = featureName + " " + getName();
		
		String command = ".setblock " + featureName.toLowerCase() + " ";
		command += getName().toLowerCase().replace(" ", "_") + " ";
		
		LinkedHashSet<PossibleKeybind> pkb = new LinkedHashSet<>();
		// Can't just list all the blocks here. Would need to change UI to allow
		// user to choose a block after selecting this option.
		// pkb.add(new PossibleKeybind(command + "dirt", "Set " + fullName + "
		// to dirt"));
		pkb.add(new PossibleKeybind(command + "reset", "Reset " + fullName));
		
		return pkb;
	}
}
