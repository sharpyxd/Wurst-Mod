/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.settings.filters;

import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1454;
import net.minecraft.class_4836;
import net.minecraft.class_5354;

public final class FilterNeutralSetting extends AttackDetectingEntityFilter
{
	private FilterNeutralSetting(String description, Mode selected,
		boolean checked)
	{
		super("Filter neutral mobs", description, selected, checked);
	}
	
	public FilterNeutralSetting(String description, Mode selected)
	{
		this(description, selected, false);
	}
	
	@Override
	public boolean onTest(class_1297 e)
	{
		return !(e instanceof class_5354 || e instanceof class_1454
			|| e instanceof class_4836);
	}
	
	@Override
	public boolean ifCalmTest(class_1297 e)
	{
		// special case for pufferfish
		if(e instanceof class_1454 pfe)
			return pfe.method_6594() > 0;
		
		if(e instanceof class_5354 || e instanceof class_4836)
			if(e instanceof class_1308 me)
				return me.method_6510();
			
		return true;
	}
	
	public static FilterNeutralSetting genericCombat(Mode selected)
	{
		return new FilterNeutralSetting(
			"description.wurst.setting.generic.filter_neutral_combat",
			selected);
	}
	
	public static FilterNeutralSetting genericVision(Mode selected)
	{
		return new FilterNeutralSetting(
			"description.wurst.setting.generic.filter_neutral_vision",
			selected);
	}
	
	public static FilterNeutralSetting onOffOnly(String description,
		boolean onByDefault)
	{
		return new FilterNeutralSetting(description, null, onByDefault);
	}
}
