/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.nochatreports;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3544;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5489;
import net.wurstclient.WurstClient;
import net.wurstclient.other_feature.OtfList;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.LastServerRememberer;

public final class NcrModRequiredScreen extends class_437
{
	private static final List<String> DISCONNECT_REASONS = Arrays.asList(
		// Older versions of NCR have a bug that sends the raw translation key.
		"disconnect.nochatreports.server",
		"You do not have No Chat Reports, and this server is configured to require it on client!");
	
	private final class_437 prevScreen;
	private final class_2561 reason;
	private class_5489 reasonFormatted = class_5489.field_26528;
	private int reasonHeight;
	
	private class_4185 signatureButton;
	private final Supplier<String> sigButtonMsg;
	
	private class_4185 vsButton;
	private final Supplier<String> vsButtonMsg;
	
	public NcrModRequiredScreen(class_437 prevScreen)
	{
		super(class_2561.method_43470(ChatUtils.WURST_PREFIX + WurstClient.INSTANCE
			.translate("gui.wurst.nochatreports.ncr_mod_server.title")));
		this.prevScreen = prevScreen;
		
		reason = class_2561.method_43470(WurstClient.INSTANCE
			.translate("gui.wurst.nochatreports.ncr_mod_server.message"));
		
		OtfList otfs = WurstClient.INSTANCE.getOtfs();
		
		sigButtonMsg = () -> WurstClient.INSTANCE
			.translate("button.wurst.nochatreports.signatures_status")
			+ blockedOrAllowed(otfs.noChatReportsOtf.isEnabled());
		
		vsButtonMsg =
			() -> "VanillaSpoof: " + onOrOff(otfs.vanillaSpoofOtf.isEnabled());
	}
	
	private String onOrOff(boolean on)
	{
		return WurstClient.INSTANCE.translate("options." + (on ? "on" : "off"))
			.toUpperCase();
	}
	
	private String blockedOrAllowed(boolean blocked)
	{
		return WurstClient.INSTANCE.translate(
			"gui.wurst.generic.allcaps_" + (blocked ? "blocked" : "allowed"));
	}
	
	@Override
	protected void method_25426()
	{
		reasonFormatted =
			class_5489.method_30890(field_22793, reason, field_22789 - 50);
		reasonHeight = reasonFormatted.method_30887() * field_22793.field_2000;
		
		int buttonX = field_22789 / 2 - 100;
		int belowReasonY =
			(field_22790 - 78) / 2 + reasonHeight / 2 + field_22793.field_2000 * 2;
		int signaturesY = Math.min(belowReasonY, field_22790 - 68);
		int reconnectY = signaturesY + 24;
		int backButtonY = reconnectY + 24;
		
		method_37063(signatureButton = class_4185
			.method_46430(class_2561.method_43470(sigButtonMsg.get()), b -> toggleSignatures())
			.method_46434(buttonX - 48, signaturesY, 148, 20).method_46431());
		
		method_37063(vsButton = class_4185
			.method_46430(class_2561.method_43470(vsButtonMsg.get()), b -> toggleVanillaSpoof())
			.method_46434(buttonX + 102, signaturesY, 148, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Reconnect"),
				b -> LastServerRememberer.reconnect(prevScreen))
			.method_46434(buttonX, reconnectY, 200, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43471("gui.toMenu"),
				b -> field_22787.method_1507(prevScreen))
			.method_46434(buttonX, backButtonY, 200, 20).method_46431());
	}
	
	private void toggleSignatures()
	{
		WurstClient.INSTANCE.getOtfs().noChatReportsOtf.doPrimaryAction();
		signatureButton.method_25355(class_2561.method_43470(sigButtonMsg.get()));
	}
	
	private void toggleVanillaSpoof()
	{
		WurstClient.INSTANCE.getOtfs().vanillaSpoofOtf.doPrimaryAction();
		vsButton.method_25355(class_2561.method_43470(vsButtonMsg.get()));
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		method_25420(context, mouseX, mouseY, partialTicks);
		
		int centerX = field_22789 / 2;
		int reasonY = (field_22790 - 68) / 2 - reasonHeight / 2;
		int titleY = reasonY - field_22793.field_2000 * 2;
		
		context.method_27534(field_22793, field_22785, centerX, titleY,
			0xAAAAAA);
		reasonFormatted.method_30888(context, centerX, reasonY);
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
	}
	
	@Override
	public boolean method_25422()
	{
		return false;
	}
	
	public static boolean isCausedByLackOfNCR(class_2561 disconnectReason)
	{
		OtfList otfs = WurstClient.INSTANCE.getOtfs();
		if(otfs.noChatReportsOtf.isActive()
			&& !otfs.vanillaSpoofOtf.isEnabled())
			return false;
		
		String text = disconnectReason.getString();
		if(text == null)
			return false;
		
		text = class_3544.method_15440(text);
		return DISCONNECT_REASONS.contains(text);
	}
}
