/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.wurstclient.WurstClient;
import net.wurstclient.hacks.NoWeatherHack;

@Mixin(class_1937.class)
public abstract class WorldMixin implements class_1936, AutoCloseable
{
	@Inject(at = @At("HEAD"),
		method = "getRainGradient(F)F",
		cancellable = true)
	private void onGetRainGradient(float delta,
		CallbackInfoReturnable<Float> cir)
	{
		if(WurstClient.INSTANCE.getHax().noWeatherHack.isRainDisabled())
			cir.setReturnValue(0F);
	}
	
	@Override
	public float method_30274(float tickDelta)
	{
		NoWeatherHack noWeather = WurstClient.INSTANCE.getHax().noWeatherHack;
		
		long timeOfDay = noWeather.isTimeChanged() ? noWeather.getChangedTime()
			: method_8401().method_217();
		
		return method_8597().method_28528(timeOfDay);
	}
	
	@Override
	public int method_30273()
	{
		NoWeatherHack noWeather = WurstClient.INSTANCE.getHax().noWeatherHack;
		
		if(noWeather.isMoonPhaseChanged())
			return noWeather.getChangedMoonPhase();
		
		return method_8597().method_28531(method_30271());
	}
}
