/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_4899;
import net.minecraft.class_4905;
import net.wurstclient.WurstClient;
import net.wurstclient.nochatreports.ForcedChatReportsScreen;

@Mixin(class_4899.class)
public class DisconnectedRealmsScreenMixin extends class_4905
{
	@Shadow
	@Final
	private class_2561 reason;
	@Shadow
	@Final
	private class_437 parent;
	
	private DisconnectedRealmsScreenMixin(WurstClient wurst, class_2561 title)
	{
		super(title);
	}
	
	@Inject(at = @At("TAIL"), method = "init()V")
	private void onInit(CallbackInfo ci)
	{
		if(!WurstClient.INSTANCE.isEnabled())
			return;
		
		System.out.println("Realms disconnected: " + reason);
		
		if(ForcedChatReportsScreen.isCausedByNoChatReports(reason))
			field_22787.method_1507(new ForcedChatReportsScreen(parent));
	}
}
