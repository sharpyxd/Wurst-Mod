/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1297;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_758;
import net.minecraft.class_758.class_7286;
import net.wurstclient.WurstClient;

@Mixin(class_758.class)
public abstract class BackgroundRendererMixin
{
	/**
	 * Makes the distance fog 100% transparent when NoFog is enabled,
	 * effectively removing it.
	 */
	@Inject(at = @At("HEAD"),
		method = "applyFog(Lnet/minecraft/client/render/Camera;Lnet/minecraft/client/render/BackgroundRenderer$FogType;FZF)V")
	private static void onApplyFog(class_4184 camera,
		class_758.class_4596 fogType, float viewDistance,
		boolean thickFog, float tickDelta, CallbackInfo ci)
	{
		if(!WurstClient.INSTANCE.getHax().noFogHack.isEnabled()
			|| fogType != class_758.class_4596.field_20946)
			return;
		
		class_5636 cameraSubmersionType = camera.method_19334();
		if(cameraSubmersionType != class_5636.field_27888)
			return;
		
		class_1297 entity = camera.method_19331();
		if(class_758.method_42588(entity, tickDelta) != null)
			return;
		
		RenderSystem.setShaderFogColor(0, 0, 0, 0);
	}
	
	@Inject(at = @At("HEAD"),
		method = "getFogModifier(Lnet/minecraft/entity/Entity;F)Lnet/minecraft/client/render/BackgroundRenderer$StatusEffectFogModifier;",
		cancellable = true)
	private static void onGetFogModifier(class_1297 entity, float tickDelta,
		CallbackInfoReturnable<class_7286> ci)
	{
		if(WurstClient.INSTANCE.getHax().antiBlindHack.isEnabled())
			ci.setReturnValue(null);
	}
}
