/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1074;
import net.minecraft.class_2561;
import net.minecraft.class_339;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.wurstclient.WurstClient;
import net.wurstclient.altmanager.screens.AltManagerScreen;

@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437
{
	private class_339 realmsButton = null;
	private class_4185 altsButton;
	
	private TitleScreenMixin(WurstClient wurst, class_2561 title)
	{
		super(title);
	}
	
	/**
	 * Adds the AltManager button to the title screen. This mixin must not
	 * run in demo mode, as the Realms button doesn't exist there.
	 */
	@Inject(at = @At("RETURN"), method = "initWidgetsNormal(II)V")
	private void onInitWidgetsNormal(int y, int spacingY, CallbackInfo ci)
	{
		if(!WurstClient.INSTANCE.isEnabled())
			return;
		
		for(class_339 button : Screens.getButtons(this))
		{
			if(!button.method_25369().getString()
				.equals(class_1074.method_4662("menu.online")))
				continue;
			
			realmsButton = button;
			break;
		}
		
		if(realmsButton == null)
			throw new IllegalStateException("Couldn't find realms button!");
		
		// make Realms button smaller
		realmsButton.method_25358(98);
		
		// add AltManager button
		method_37063(altsButton = class_4185
			.method_46430(class_2561.method_43470("Alt Manager"),
				b -> field_22787.method_1507(new AltManagerScreen(this,
					WurstClient.INSTANCE.getAltManager())))
			.method_46434(field_22789 / 2 + 2, realmsButton.method_46427(), 98, 20).method_46431());
	}
	
	@Inject(at = @At("RETURN"), method = "tick()V")
	private void onTick(CallbackInfo ci)
	{
		if(realmsButton == null || altsButton == null)
			return;
			
		// adjust AltManager button if Realms button has been moved
		// happens when ModMenu is installed
		altsButton.method_46419(realmsButton.method_46427());
	}
	
	/**
	 * Stops the multiplayer button being grayed out if the user's Microsoft
	 * account is parental-control'd or banned from online play.
	 */
	@Inject(at = @At("HEAD"),
		method = "getMultiplayerDisabledText()Lnet/minecraft/text/Text;",
		cancellable = true)
	private void onGetMultiplayerDisabledText(CallbackInfoReturnable<class_2561> cir)
	{
		cir.setReturnValue(null);
	}
}
