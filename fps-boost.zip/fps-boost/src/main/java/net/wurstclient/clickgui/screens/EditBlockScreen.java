/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.clickgui.screens;

import org.lwjgl.glfw.GLFW;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.wurstclient.settings.BlockSetting;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.RenderUtils;

public final class EditBlockScreen extends class_437
{
	private final class_437 prevScreen;
	private final BlockSetting setting;
	
	private class_342 blockField;
	private class_4185 doneButton;
	
	public EditBlockScreen(class_437 prevScreen, BlockSetting setting)
	{
		super(class_2561.method_43470(""));
		this.prevScreen = prevScreen;
		this.setting = setting;
	}
	
	@Override
	public void method_25426()
	{
		int x1 = field_22789 / 2 - 100;
		int y1 = 59;
		int y2 = field_22790 / 3 * 2;
		
		class_327 tr = field_22787.field_1772;
		String valueString = setting.getBlockName();
		
		blockField = new class_342(tr, x1, y1, 178, 20, class_2561.method_43470(""));
		blockField.method_1852(valueString);
		blockField.method_1875(0);
		blockField.method_1880(256);
		
		method_25429(blockField);
		method_25395(blockField);
		blockField.method_25365(true);
		
		doneButton = class_4185.method_46430(class_2561.method_43470("Done"), b -> done())
			.method_46434(x1, y2, 200, 20).method_46431();
		method_37063(doneButton);
	}
	
	private void done()
	{
		String nameOrId = blockField.method_1882();
		class_2248 block = BlockUtils.getBlockFromNameOrID(nameOrId);
		
		if(block != null)
			setting.setBlock(block);
		
		field_22787.method_1507(prevScreen);
	}
	
	@Override
	public boolean method_25404(int keyCode, int scanCode, int int_3)
	{
		switch(keyCode)
		{
			case GLFW.GLFW_KEY_ENTER:
			done();
			break;
			
			case GLFW.GLFW_KEY_ESCAPE:
			field_22787.method_1507(prevScreen);
			break;
		}
		
		return super.method_25404(keyCode, scanCode, int_3);
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		class_4587 matrixStack = context.method_51448();
		class_327 tr = field_22787.field_1772;
		
		method_25420(context, mouseX, mouseY, partialTicks);
		context.method_25300(tr, setting.getName(), field_22789 / 2, 20,
			0xFFFFFF);
		
		blockField.method_25394(context, mouseX, mouseY, partialTicks);
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
		
		matrixStack.method_22903();
		matrixStack.method_46416(-64 + field_22789 / 2 - 100, 115, 0);
		
		boolean lblAbove =
			!blockField.method_1882().isEmpty() || blockField.method_25370();
		String lblText =
			lblAbove ? "Block ID or number:" : "block ID or number";
		int lblX = lblAbove ? 50 : 68;
		int lblY = lblAbove ? -66 : -50;
		int lblColor = lblAbove ? 0xF0F0F0 : 0x808080;
		context.method_25303(tr, lblText, lblX, lblY, lblColor);
		
		int border = blockField.method_25370() ? 0xffffffff : 0xffa0a0a0;
		int black = 0xff000000;
		
		context.method_25294(48, -56, 64, -36, border);
		context.method_25294(49, -55, 65, -37, black);
		context.method_25294(242, -56, 246, -36, border);
		context.method_25294(241, -55, 245, -37, black);
		
		matrixStack.method_22909();
		
		String nameOrId = blockField.method_1882();
		class_2248 blockToAdd = BlockUtils.getBlockFromNameOrID(nameOrId);
		
		if(blockToAdd == null)
			blockToAdd = class_2246.field_10124;
		
		RenderUtils.drawItem(context, new class_1799(blockToAdd),
			-64 + field_22789 / 2 - 100 + 52, 115 - 52, false);
	}
	
	@Override
	public boolean method_25421()
	{
		return false;
	}
	
	@Override
	public boolean method_25422()
	{
		return false;
	}
}
