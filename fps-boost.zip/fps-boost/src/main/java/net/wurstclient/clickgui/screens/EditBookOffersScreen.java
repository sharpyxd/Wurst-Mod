/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.clickgui.screens;

import java.util.List;
import java.util.Objects;

import org.lwjgl.glfw.GLFW;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import net.minecraft.class_4280;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9636;
import net.wurstclient.hacks.autolibrarian.BookOffer;
import net.wurstclient.settings.BookOffersSetting;
import net.wurstclient.util.RenderUtils;

public final class EditBookOffersScreen extends class_437
{
	private final class_437 prevScreen;
	private final BookOffersSetting bookOffers;
	
	private ListGui listGui;
	private class_4185 editButton;
	private class_4185 removeButton;
	private class_4185 doneButton;
	
	public EditBookOffersScreen(class_437 prevScreen, BookOffersSetting bookOffers)
	{
		super(class_2561.method_43470(""));
		this.prevScreen = prevScreen;
		this.bookOffers = bookOffers;
	}
	
	@Override
	public void method_25426()
	{
		listGui = new ListGui(field_22787, this, bookOffers.getOffers());
		method_25429(listGui);
		
		method_37063(
			class_4185
				.method_46430(class_2561.method_43470("Add"),
					b -> field_22787
						.method_1507(new AddBookOfferScreen(this, bookOffers)))
				.method_46434(field_22789 / 2 - 154, field_22790 - 56, 100, 20).method_46431());
		
		method_37063(
			editButton = class_4185.method_46430(class_2561.method_43470("Edit"), b -> {
				BookOffer selected = listGui.getSelectedOffer();
				if(selected == null)
					return;
				
				field_22787.method_1507(new EditBookOfferScreen(this, bookOffers,
					bookOffers.indexOf(selected)));
			}).method_46434(field_22789 / 2 - 50, field_22790 - 56, 100, 20).method_46431());
		editButton.field_22763 = false;
		
		method_37063(
			removeButton = class_4185.method_46430(class_2561.method_43470("Remove"), b -> {
				bookOffers
					.remove(bookOffers.indexOf(listGui.getSelectedOffer()));
				field_22787.method_1507(EditBookOffersScreen.this);
			}).method_46434(field_22789 / 2 + 54, field_22790 - 56, 100, 20).method_46431());
		removeButton.field_22763 = false;
		
		method_37063(class_4185.method_46430(class_2561.method_43470("Reset to Defaults"),
			b -> field_22787.method_1507(new class_410(b2 -> {
				if(b2)
					bookOffers.resetToDefaults();
				field_22787.method_1507(EditBookOffersScreen.this);
			}, class_2561.method_43470("Reset to Defaults"),
				class_2561.method_43470("Are you sure?"))))
			.method_46434(field_22789 - 106, 6, 100, 20).method_46431());
		
		method_37063(doneButton = class_4185
			.method_46430(class_2561.method_43470("Done"), b -> field_22787.method_1507(prevScreen))
			.method_46434(field_22789 / 2 - 100, field_22790 - 32, 200, 20).method_46431());
	}
	
	@Override
	public boolean method_25402(double mouseX, double mouseY, int mouseButton)
	{
		boolean childClicked = super.method_25402(mouseX, mouseY, mouseButton);
		
		if(mouseButton == GLFW.GLFW_MOUSE_BUTTON_4)
			doneButton.method_25306();
		
		return childClicked;
	}
	
	@Override
	public boolean method_25404(int keyCode, int scanCode, int int_3)
	{
		switch(keyCode)
		{
			case GLFW.GLFW_KEY_ENTER:
			if(editButton.field_22763)
				editButton.method_25306();
			break;
			
			case GLFW.GLFW_KEY_DELETE:
			removeButton.method_25306();
			break;
			
			case GLFW.GLFW_KEY_ESCAPE:
			case GLFW.GLFW_KEY_BACKSPACE:
			doneButton.method_25306();
			break;
			
			default:
			break;
		}
		
		return super.method_25404(keyCode, scanCode, int_3);
	}
	
	@Override
	public void method_25393()
	{
		boolean selected = listGui.method_25334() != null;
		editButton.field_22763 = selected;
		removeButton.field_22763 = selected;
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		class_4587 matrixStack = context.method_51448();
		method_25420(context, mouseX, mouseY, partialTicks);
		
		listGui.method_25394(context, mouseX, mouseY, partialTicks);
		
		matrixStack.method_22903();
		matrixStack.method_46416(0, 0, 300);
		
		context.method_25300(field_22787.field_1772,
			bookOffers.getName() + " (" + bookOffers.getOffers().size() + ")",
			field_22789 / 2, 12, 0xFFFFFF);
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
		
		matrixStack.method_22909();
	}
	
	@Override
	public boolean method_25421()
	{
		return false;
	}
	
	@Override
	public boolean method_25422()
	{
		return false;
	}
	
	private final class Entry
		extends class_4280.class_4281<EditBookOffersScreen.Entry>
	{
		private final BookOffer bookOffer;
		
		public Entry(BookOffer bookOffer)
		{
			this.bookOffer = Objects.requireNonNull(bookOffer);
		}
		
		@Override
		public class_2561 method_37006()
		{
			return class_2561.method_43469("narrator.select",
				"Book offer " + bookOffer.getEnchantmentNameWithLevel()
					+ ", ID " + bookOffer.id() + ", " + getPriceText());
		}
		
		@Override
		public void method_25343(class_332 context, int index, int y, int x,
			int entryWidth, int entryHeight, int mouseX, int mouseY,
			boolean hovered, float tickDelta)
		{
			class_1792 item = class_7923.field_41178.method_10223(class_2960.method_60654("enchanted_book"));
			class_1799 stack = new class_1799(item);
			RenderUtils.drawItem(context, stack, x + 1, y + 1, true);
			
			class_327 tr = field_22787.field_1772;
			String name = bookOffer.getEnchantmentNameWithLevel();
			
			class_6880<class_1887> enchantment =
				bookOffer.getEnchantmentEntry().get();
			int nameColor =
				enchantment.method_40220(class_9636.field_51551) ? 0xFF5555 : 0xF0F0F0;
			context.method_51433(tr, name, x + 28, y, nameColor, false);
			
			context.method_51433(tr, bookOffer.id(), x + 28, y + 9, 0xA0A0A0,
				false);
			
			String price = getPriceText();
			context.method_51433(tr, price, x + 28, y + 18, 0xA0A0A0, false);
			
			if(bookOffer.price() < 64)
				RenderUtils.drawItem(context, new class_1799(class_1802.field_8687),
					x + 28 + tr.method_1727(price), y + 16, false);
		}
		
		private String getPriceText()
		{
			if(bookOffer.price() >= 64)
				return "any price";
			
			return "max " + bookOffer.price();
		}
	}
	
	private final class ListGui
		extends class_4280<EditBookOffersScreen.Entry>
	{
		public ListGui(class_310 minecraft, EditBookOffersScreen screen,
			List<BookOffer> list)
		{
			super(minecraft, screen.field_22789, screen.field_22790 - 108, 36, 30);
			
			list.stream().map(EditBookOffersScreen.Entry::new)
				.forEach(this::method_25321);
		}
		
		public BookOffer getSelectedOffer()
		{
			EditBookOffersScreen.Entry entry = method_25334();
			return entry != null ? entry.bookOffer : null;
		}
	}
}
