/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.options;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import org.lwjgl.glfw.GLFW;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_4280;
import net.minecraft.class_437;
import net.wurstclient.WurstClient;
import net.wurstclient.util.json.JsonException;

public final class KeybindProfilesScreen extends class_437
{
	private final class_437 prevScreen;
	
	private ListGui listGui;
	private class_4185 loadButton;
	
	public KeybindProfilesScreen(class_437 prevScreen)
	{
		super(class_2561.method_43470(""));
		this.prevScreen = prevScreen;
	}
	
	@Override
	public void method_25426()
	{
		listGui = new ListGui(field_22787, this,
			WurstClient.INSTANCE.getKeybinds().listProfiles());
		method_25429(listGui);
		
		method_37063(
			class_4185.method_46430(class_2561.method_43470("Open Folder"), b -> openFolder())
				.method_46434(8, 8, 100, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("New Profile"),
				b -> field_22787.method_1507(
					new EnterProfileNameScreen(this, this::newProfile)))
			.method_46434(field_22789 / 2 - 154, field_22790 - 48, 100, 20).method_46431());
		
		loadButton = method_37063(
			class_4185.method_46430(class_2561.method_43470("Load"), b -> loadSelected())
				.method_46434(field_22789 / 2 - 50, field_22790 - 48, 100, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Cancel"), b -> field_22787.method_1507(prevScreen))
			.method_46434(field_22789 / 2 + 54, field_22790 - 48, 100, 20).method_46431());
	}
	
	private void openFolder()
	{
		class_156.method_668().method_672(
			WurstClient.INSTANCE.getKeybinds().getProfilesFolder().toFile());
	}
	
	private void newProfile(String name)
	{
		if(!name.endsWith(".json"))
			name += ".json";
		
		try
		{
			WurstClient.INSTANCE.getKeybinds().saveProfile(name);
			
		}catch(IOException | JsonException e)
		{
			throw new RuntimeException(e);
		}
	}
	
	private void loadSelected()
	{
		Path path = listGui.getSelectedPath();
		if(path == null)
		{
			field_22787.method_1507(prevScreen);
			return;
		}
		
		try
		{
			String fileName = "" + path.getFileName();
			WurstClient.INSTANCE.getKeybinds().loadProfile(fileName);
			field_22787.method_1507(prevScreen);
			
		}catch(IOException | JsonException e)
		{
			e.printStackTrace();
			return;
		}
	}
	
	@Override
	public boolean method_25404(int keyCode, int scanCode, int int_3)
	{
		if(keyCode == GLFW.GLFW_KEY_ENTER)
			loadSelected();
		else if(keyCode == GLFW.GLFW_KEY_ESCAPE)
			field_22787.method_1507(prevScreen);
		
		return super.method_25404(keyCode, scanCode, int_3);
	}
	
	@Override
	public void method_25393()
	{
		loadButton.field_22763 = listGui.method_25334() != null;
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		method_25420(context, mouseX, mouseY, partialTicks);
		listGui.method_25394(context, mouseX, mouseY, partialTicks);
		
		context.method_25300(field_22787.field_1772,
			"Keybind Profiles", field_22789 / 2, 12, 0xffffff);
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
		
		if(loadButton.method_25367() && !loadButton.field_22763)
			context.method_51434(field_22793,
				Arrays.asList(class_2561.method_43470("You must first select a file.")),
				mouseX, mouseY);
	}
	
	@Override
	public boolean method_25422()
	{
		return false;
	}
	
	private final class Entry
		extends class_4280.class_4281<KeybindProfilesScreen.Entry>
	{
		private final Path path;
		
		public Entry(Path path)
		{
			this.path = Objects.requireNonNull(path);
		}
		
		@Override
		public class_2561 method_37006()
		{
			return class_2561.method_43469("narrator.select",
				"Profile " + path.getFileName());
		}
		
		@Override
		public void method_25343(class_332 context, int index, int y, int x,
			int entryWidth, int entryHeight, int mouseX, int mouseY,
			boolean hovered, float tickDelta)
		{
			class_327 tr = field_22787.field_1772;
			
			String fileName = "" + path.getFileName();
			context.method_25303(tr, fileName, x + 28, y, 0xF0F0F0);
			
			String relPath = "" + field_22787.field_1697.toPath().relativize(path);
			context.method_25303(tr, relPath, x + 28, y + 9, 0xA0A0A0);
		}
	}
	
	private final class ListGui
		extends class_4280<KeybindProfilesScreen.Entry>
	{
		public ListGui(class_310 mc, KeybindProfilesScreen screen,
			List<Path> list)
		{
			super(mc, screen.field_22789, screen.field_22790 - 96, 36, 20);
			
			list.stream().map(KeybindProfilesScreen.Entry::new)
				.forEach(this::method_25321);
		}
		
		public Path getSelectedPath()
		{
			KeybindProfilesScreen.Entry selected = method_25334();
			return selected != null ? selected.path : null;
		}
	}
}
