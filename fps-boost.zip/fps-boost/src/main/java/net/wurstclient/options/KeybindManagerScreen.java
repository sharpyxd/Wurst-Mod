/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.options;

import java.util.Objects;

import org.lwjgl.glfw.GLFW;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import net.minecraft.class_4280;
import net.minecraft.class_437;
import net.wurstclient.WurstClient;
import net.wurstclient.keybinds.Keybind;
import net.wurstclient.keybinds.KeybindList;

public final class KeybindManagerScreen extends class_437
{
	private final class_437 prevScreen;
	
	private ListGui listGui;
	private class_4185 addButton;
	private class_4185 editButton;
	private class_4185 removeButton;
	private class_4185 backButton;
	
	public KeybindManagerScreen(class_437 prevScreen)
	{
		super(class_2561.method_43470(""));
		this.prevScreen = prevScreen;
	}
	
	@Override
	public void method_25426()
	{
		listGui = new ListGui(field_22787, this);
		method_25429(listGui);
		
		method_37063(addButton = class_4185
			.method_46430(class_2561.method_43470("Add"),
				b -> field_22787.method_1507(new KeybindEditorScreen(this)))
			.method_46434(field_22789 / 2 - 102, field_22790 - 52, 100, 20).method_46431());
		
		method_37063(
			editButton = class_4185.method_46430(class_2561.method_43470("Edit"), b -> edit())
				.method_46434(field_22789 / 2 + 2, field_22790 - 52, 100, 20).method_46431());
		
		method_37063(removeButton =
			class_4185.method_46430(class_2561.method_43470("Remove"), b -> remove())
				.method_46434(field_22789 / 2 - 102, field_22790 - 28, 100, 20).method_46431());
		
		method_37063(backButton = class_4185
			.method_46430(class_2561.method_43470("Back"), b -> field_22787.method_1507(prevScreen))
			.method_46434(field_22789 / 2 + 2, field_22790 - 28, 100, 20).method_46431());
		
		method_37063(class_4185.method_46430(class_2561.method_43470("Reset Keybinds"),
			b -> field_22787.method_1507(new class_410(confirmed -> {
				if(confirmed)
					WurstClient.INSTANCE.getKeybinds()
						.setKeybinds(KeybindList.DEFAULT_KEYBINDS);
				field_22787.method_1507(this);
			}, class_2561.method_43470("Are you sure you want to reset your keybinds?"),
				class_2561.method_43470("This cannot be undone!"))))
			.method_46434(8, 8, 100, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Profiles..."),
				b -> field_22787.method_1507(new KeybindProfilesScreen(this)))
			.method_46434(field_22789 - 108, 8, 100, 20).method_46431());
	}
	
	private void edit()
	{
		Keybind keybind = listGui.getSelectedKeybind();
		if(keybind == null)
			return;
		
		field_22787.method_1507(new KeybindEditorScreen(this, keybind.getKey(),
			keybind.getCommands()));
	}
	
	private void remove()
	{
		Keybind keybind = listGui.getSelectedKeybind();
		if(keybind == null)
			return;
		
		WurstClient.INSTANCE.getKeybinds().remove(keybind.getKey());
		field_22787.method_1507(this);
	}
	
	@Override
	public boolean method_25404(int keyCode, int scanCode, int modifiers)
	{
		switch(keyCode)
		{
			case GLFW.GLFW_KEY_ENTER:
			if(editButton.field_22763)
				editButton.method_25306();
			else
				addButton.method_25306();
			break;
			
			case GLFW.GLFW_KEY_DELETE:
			removeButton.method_25306();
			break;
			
			case GLFW.GLFW_KEY_ESCAPE:
			backButton.method_25306();
			break;
			
			default:
			break;
		}
		
		return super.method_25404(keyCode, scanCode, modifiers);
	}
	
	@Override
	public void method_25393()
	{
		boolean selected = listGui.method_25334() != null;
		editButton.field_22763 = selected;
		removeButton.field_22763 = selected;
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		method_25420(context, mouseX, mouseY, partialTicks);
		listGui.method_25394(context, mouseX, mouseY, partialTicks);
		
		context.method_25300(field_22793, "Keybind Manager",
			field_22789 / 2, 8, 0xFFFFFF);
		
		int count = WurstClient.INSTANCE.getKeybinds().getAllKeybinds().size();
		context.method_25300(field_22793, "Keybinds: " + count,
			field_22789 / 2, 20, 0xFFFFFF);
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
	}
	
	@Override
	public boolean method_25422()
	{
		return false;
	}
	
	private final class Entry
		extends class_4280.class_4281<KeybindManagerScreen.Entry>
	{
		private final Keybind keybind;
		
		public Entry(Keybind keybind)
		{
			this.keybind = Objects.requireNonNull(keybind);
		}
		
		@Override
		public class_2561 method_37006()
		{
			return class_2561.method_43469("narrator.select", "Keybind " + keybind);
		}
		
		@Override
		public void method_25343(class_332 context, int index, int y, int x,
			int entryWidth, int entryHeight, int mouseX, int mouseY,
			boolean hovered, float tickDelta)
		{
			class_327 tr = field_22787.field_1772;
			
			String keyText =
				"Key: " + keybind.getKey().replace("key.keyboard.", "");
			context.method_51433(tr, keyText, x + 3, y + 3, 0xA0A0A0, false);
			
			String cmdText = "Commands: " + keybind.getCommands();
			context.method_51433(tr, cmdText, x + 3, y + 15, 0xA0A0A0, false);
		}
	}
	
	private final class ListGui
		extends class_4280<KeybindManagerScreen.Entry>
	{
		public ListGui(class_310 mc, KeybindManagerScreen screen)
		{
			super(mc, screen.field_22789, screen.field_22790 - 96, 36, 30);
			
			WurstClient.INSTANCE.getKeybinds().getAllKeybinds().stream()
				.map(KeybindManagerScreen.Entry::new).forEach(this::method_25321);
		}
		
		public Keybind getSelectedKeybind()
		{
			KeybindManagerScreen.Entry selected = method_25334();
			return selected != null ? selected.keybind : null;
		}
	}
}
