/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.navigator;

import java.awt.Rectangle;

import org.joml.Matrix4f;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.wurstclient.WurstClient;
import net.wurstclient.clickgui.ClickGui;
import net.wurstclient.util.RenderUtils;

public abstract class NavigatorScreen extends class_437
{
	protected int scroll = 0;
	private int scrollKnobPosition = 2;
	private boolean scrolling;
	private int maxScroll;
	protected boolean scrollbarLocked;
	protected int middleX;
	protected boolean hasBackground = true;
	protected int nonScrollableArea = 26;
	private boolean showScrollbar;
	
	public NavigatorScreen()
	{
		super(class_2561.method_43470(""));
	}
	
	@Override
	protected final void method_25426()
	{
		middleX = field_22789 / 2;
		onResize();
	}
	
	@Override
	public final boolean method_25404(int keyCode, int scanCode, int int_3)
	{
		onKeyPress(keyCode, scanCode, int_3);
		return super.method_25404(keyCode, scanCode, int_3);
	}
	
	@Override
	public final boolean method_25402(double x, double y, int button)
	{
		// scrollbar
		if(new Rectangle(field_22789 / 2 + 170, 60, 12, field_22790 - 103).contains(x, y))
			scrolling = true;
		
		onMouseClick(x, y, button);
		
		// vanilla buttons
		return super.method_25402(x, y, button);
	}
	
	@Override
	public final boolean method_25403(double mouseX, double mouseY,
		int mouseButton, double double_3, double double_4)
	{
		// scrollbar
		if(scrolling && !scrollbarLocked && mouseButton == 0)
		{
			if(maxScroll == 0)
				scroll = 0;
			else
				scroll = (int)((mouseY - 72) * maxScroll / (field_22790 - 131));
			
			if(scroll > 0)
				scroll = 0;
			else if(scroll < maxScroll)
				scroll = maxScroll;
			
			if(maxScroll == 0)
				scrollKnobPosition = 0;
			else
				scrollKnobPosition =
					(int)((field_22790 - 131) * scroll / (float)maxScroll);
			scrollKnobPosition += 2;
		}
		
		onMouseDrag(mouseX, mouseY, mouseButton, double_3, double_4);
		
		return super.method_25403(mouseX, mouseY, mouseButton, double_3,
			double_4);
	}
	
	@Override
	public final boolean method_25406(double x, double y, int button)
	{
		// scrollbar
		scrolling = false;
		
		onMouseRelease(x, y, button);
		
		// vanilla buttons
		return super.method_25406(x, y, button);
	}
	
	@Override
	public final boolean method_25401(double mouseX, double mouseY,
		double horizontalAmount, double verticalAmount)
	{
		// scrollbar
		if(!scrollbarLocked)
		{
			scroll += verticalAmount * 4;
			
			if(scroll > 0)
				scroll = 0;
			else if(scroll < maxScroll)
				scroll = maxScroll;
			
			if(maxScroll == 0)
				scrollKnobPosition = 0;
			else
				scrollKnobPosition =
					(int)((field_22790 - 131) * scroll / (float)maxScroll);
			scrollKnobPosition += 2;
		}
		
		return super.method_25401(mouseX, mouseY, horizontalAmount,
			verticalAmount);
	}
	
	@Override
	public final void method_25393()
	{
		onUpdate();
	}
	
	@Override
	public final void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		// background
		int bgx1 = middleX - 154;
		int bgx2 = middleX + 154;
		int bgy1 = 60;
		int bgy2 = field_22790 - 43;
		if(hasBackground)
			drawBackgroundBox(context, bgx1, bgy1, bgx2, bgy2);
		
		// scrollbar
		if(showScrollbar)
		{
			// bar
			int x1 = bgx2 + 16;
			int x2 = x1 + 12;
			int y1 = bgy1;
			int y2 = bgy2;
			drawBackgroundBox(context, x1, y1, x2, y2);
			
			// knob
			x1 += 2;
			x2 -= 2;
			y1 += scrollKnobPosition;
			y2 = y1 + 24;
			drawBackgroundBox(context, x1, y1, x2, y2);
			int i;
			for(x1++, x2--, y1 += 8, y2 -= 15, i = 0; i < 3; y1 += 4, y2 +=
				4, i++)
				drawDownShadow(context, x1, y1, x2, y2);
		}
		
		onRender(context, mouseX, mouseY, partialTicks);
	}
	
	@Override
	public final boolean method_25421()
	{
		return false;
	}
	
	protected abstract void onResize();
	
	protected abstract void onKeyPress(int keyCode, int scanCode, int int_3);
	
	protected abstract void onMouseClick(double x, double y, int button);
	
	protected abstract void onMouseDrag(double mouseX, double mouseY,
		int button, double double_3, double double_4);
	
	protected abstract void onMouseRelease(double x, double y, int button);
	
	protected abstract void onUpdate();
	
	protected abstract void onRender(class_332 context, int mouseX,
		int mouseY, float partialTicks);
	
	protected final int getStringHeight(String s)
	{
		int fontHeight = field_22787.field_1772.field_2000;
		int height = fontHeight;
		
		for(int i = 0; i < s.length(); i++)
			if(s.charAt(i) == '\n')
				height += fontHeight;
			
		return height;
	}
	
	protected final void setContentHeight(int contentHeight)
	{
		maxScroll = field_22790 - contentHeight - nonScrollableArea - 120;
		if(maxScroll > 0)
			maxScroll = 0;
		showScrollbar = maxScroll != 0;
		
		if(scroll < maxScroll)
			scroll = maxScroll;
	}
	
	protected final void drawDownShadow(class_332 context, int x1, int y1,
		int x2, int y2)
	{
		float[] acColor = WurstClient.INSTANCE.getGui().getAcColor();
		
		// line
		float yi1 = y1 + 0.1F;
		int lineColor = RenderUtils.toIntColor(acColor, 0.5F);
		RenderUtils.drawLine2D(context, x1, yi1, x2, yi1, lineColor);
		
		// shadow
		int shadowColor1 = RenderUtils.toIntColor(acColor, 0.75F);
		int shadowColor2 = 0x00000000;
		
		class_4587 matrixStack = context.method_51448();
		Matrix4f matrix = matrixStack.method_23760().method_23761();
		
		class_4588 buffer =
			RenderUtils.getVCP().getBuffer(class_1921.method_51784());
		buffer.method_22918(matrix, x1, y1, 0).method_39415(shadowColor1);
		buffer.method_22918(matrix, x1, y2, 0).method_39415(shadowColor2);
		buffer.method_22918(matrix, x2, y2, 0).method_39415(shadowColor2);
		buffer.method_22918(matrix, x2, y1, 0).method_39415(shadowColor1);
	}
	
	protected final void drawBox(class_332 context, int x1, int y1, int x2,
		int y2, int color)
	{
		context.method_25294(x1, y1, x2, y2, color);
		RenderUtils.drawBoxShadow2D(context, x1, y1, x2, y2);
	}
	
	protected final int getBackgroundColor()
	{
		ClickGui gui = WurstClient.INSTANCE.getGui();
		gui.updateColors();
		return RenderUtils.toIntColor(gui.getBgColor(), gui.getOpacity());
	}
	
	protected final void drawBackgroundBox(class_332 context, int x1, int y1,
		int x2, int y2)
	{
		drawBox(context, x1, y1, x2, y2, getBackgroundColor());
	}
}
