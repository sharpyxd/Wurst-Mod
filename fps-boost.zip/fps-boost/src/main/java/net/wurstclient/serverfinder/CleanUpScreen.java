/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.serverfinder;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

import org.lwjgl.glfw.GLFW;

import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_155;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_4267;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_642;
import net.wurstclient.mixinterface.IMultiplayerScreen;

public class CleanUpScreen extends class_437
{
	private class_500 prevScreen;
	private class_4185 cleanUpButton;
	
	private boolean removeAll;
	private boolean cleanupFailed = true;
	private boolean cleanupOutdated = true;
	private boolean cleanupRename = true;
	private boolean cleanupUnknown = true;
	private boolean cleanupGriefMe;
	
	public CleanUpScreen(class_500 prevScreen)
	{
		super(class_2561.method_43470(""));
		this.prevScreen = prevScreen;
	}
	
	@Override
	public void method_25426()
	{
		method_37063(new CleanUpButton(field_22789 / 2 - 100,
			field_22790 / 4 + 168 + 12, () -> "Cancel", "", b -> method_25419()));
		
		method_37063(cleanUpButton = new CleanUpButton(field_22789 / 2 - 100,
			field_22790 / 4 + 144 + 12, () -> "Clean Up",
			"Start the Clean Up with the settings\n" + "you specified above.\n"
				+ "It might look like the game is not\n"
				+ "responding for a couple of seconds.",
			b -> cleanUp()));
		
		method_37063(
			new CleanUpButton(field_22789 / 2 - 100, field_22790 / 4 - 24 + 12,
				() -> "Unknown Hosts: " + removeOrKeep(cleanupUnknown),
				"Servers that clearly don't exist.",
				b -> cleanupUnknown = !cleanupUnknown));
		
		method_37063(new CleanUpButton(field_22789 / 2 - 100, field_22790 / 4 + 0 + 12,
			() -> "Outdated Servers: " + removeOrKeep(cleanupOutdated),
			"Servers that run a different Minecraft\n" + "version than you.",
			b -> cleanupOutdated = !cleanupOutdated));
		
		method_37063(
			new CleanUpButton(field_22789 / 2 - 100, field_22790 / 4 + 24 + 12,
				() -> "Failed Ping: " + removeOrKeep(cleanupFailed),
				"All servers that failed the last ping.\n"
					+ "Make sure that the last ping is complete\n"
					+ "before you do this. That means: Go back,\n"
					+ "press the refresh button and wait until\n"
					+ "all servers are done refreshing.",
				b -> cleanupFailed = !cleanupFailed));
		
		method_37063(
			new CleanUpButton(field_22789 / 2 - 100, field_22790 / 4 + 48 + 12,
				() -> "\"Grief me\" Servers: " + removeOrKeep(cleanupGriefMe),
				"All servers where the name starts with \"Grief me\"\n"
					+ "Useful for removing servers found by ServerFinder.",
				b -> cleanupGriefMe = !cleanupGriefMe));
		
		method_37063(
			new CleanUpButton(field_22789 / 2 - 100, field_22790 / 4 + 72 + 12,
				() -> "\u00a7cRemove all Servers: " + yesOrNo(removeAll),
				"This will completely clear your server\n"
					+ "list. \u00a7cUse with caution!\u00a7r",
				b -> removeAll = !removeAll));
		
		method_37063(
			new CleanUpButton(field_22789 / 2 - 100, field_22790 / 4 + 96 + 12,
				() -> "Rename all Servers: " + yesOrNo(cleanupRename),
				"Renames your servers to \"Grief me #1\",\n"
					+ "\"Grief me #2\", etc.",
				b -> cleanupRename = !cleanupRename));
	}
	
	private String yesOrNo(boolean b)
	{
		return b ? "Yes" : "No";
	}
	
	private String removeOrKeep(boolean b)
	{
		return b ? "Remove" : "Keep";
	}
	
	private void cleanUp()
	{
		for(int i = prevScreen.method_2529().method_2984() - 1; i >= 0; i--)
		{
			class_642 server = prevScreen.method_2529().method_2982(i);
			
			if(removeAll || shouldRemove(server))
				prevScreen.method_2529().method_2983(server);
		}
		
		if(cleanupRename)
			for(int i = 0; i < prevScreen.method_2529().method_2984(); i++)
			{
				class_642 server = prevScreen.method_2529().method_2982(i);
				server.field_3752 = "Grief me #" + (i + 1);
			}
		
		saveServerList();
		field_22787.method_1507(prevScreen);
	}
	
	private boolean shouldRemove(class_642 server)
	{
		if(server == null)
			return false;
		
		if(cleanupUnknown && isUnknownHost(server))
			return true;
		
		if(cleanupOutdated && !isSameProtocol(server))
			return true;
		
		if(cleanupFailed && isFailedPing(server))
			return true;
		
		if(cleanupGriefMe && isGriefMeServer(server))
			return true;
		
		return false;
	}
	
	private boolean isUnknownHost(class_642 server)
	{
		if(server.field_3757 == null)
			return false;
		
		if(server.field_3757.getString() == null)
			return false;
		
		return server.field_3757.getString()
			.equals("\u00a74Can\'t resolve hostname");
	}
	
	private boolean isSameProtocol(class_642 server)
	{
		return server.field_3756 == class_155.method_16673()
			.method_48020();
	}
	
	private boolean isFailedPing(class_642 server)
	{
		return server.field_3758 != -2L && server.field_3758 < 0L;
	}
	
	private boolean isGriefMeServer(class_642 server)
	{
		return server.field_3752 != null && server.field_3752.startsWith("Grief me");
	}
	
	private void saveServerList()
	{
		prevScreen.method_2529().method_2987();
		
		class_4267 serverListSelector =
			((IMultiplayerScreen)prevScreen).getServerListSelector();
		
		serverListSelector.method_20122(null);
		serverListSelector.method_20125(prevScreen.method_2529());
	}
	
	@Override
	public boolean method_25404(int keyCode, int scanCode, int int_3)
	{
		if(keyCode == GLFW.GLFW_KEY_ENTER)
			cleanUpButton.method_25306();
		
		return super.method_25404(keyCode, scanCode, int_3);
	}
	
	@Override
	public boolean method_25402(double mouseX, double mouseY, int button)
	{
		if(button == GLFW.GLFW_MOUSE_BUTTON_4)
		{
			method_25419();
			return true;
		}
		
		return super.method_25402(mouseX, mouseY, button);
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		method_25420(context, mouseX, mouseY, partialTicks);
		context.method_25300(field_22793, "Clean Up", field_22789 / 2,
			20, 16777215);
		context.method_25300(field_22793,
			"Please select the servers you want to remove:", field_22789 / 2, 36,
			10526880);
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
		
		renderButtonTooltip(context, mouseX, mouseY);
	}
	
	private void renderButtonTooltip(class_332 context, int mouseX,
		int mouseY)
	{
		for(class_339 button : Screens.getButtons(this))
		{
			if(!button.method_25367() || !(button instanceof CleanUpButton))
				continue;
			
			CleanUpButton cuButton = (CleanUpButton)button;
			
			if(cuButton.tooltip.isEmpty())
				continue;
			
			context.method_51434(field_22793, cuButton.tooltip, mouseX, mouseY);
			break;
		}
	}
	
	@Override
	public void method_25419()
	{
		field_22787.method_1507(prevScreen);
	}
	
	private final class CleanUpButton extends class_4185
	{
		private final Supplier<String> messageSupplier;
		private final List<class_2561> tooltip;
		
		public CleanUpButton(int x, int y, Supplier<String> messageSupplier,
			String tooltip, class_4241 pressAction)
		{
			super(x, y, 200, 20, class_2561.method_43470(messageSupplier.get()),
				pressAction, class_4185.field_40754);
			this.messageSupplier = messageSupplier;
			
			if(tooltip.isEmpty())
				this.tooltip = Arrays.asList();
			else
			{
				String[] lines = tooltip.split("\n");
				
				class_2561[] lines2 = new class_2561[lines.length];
				for(int i = 0; i < lines.length; i++)
					lines2[i] = class_2561.method_43470(lines[i]);
				
				this.tooltip = Arrays.asList(lines2);
			}
		}
		
		@Override
		public void method_25306()
		{
			super.method_25306();
			method_25355(class_2561.method_43470(messageSupplier.get()));
		}
	}
}
