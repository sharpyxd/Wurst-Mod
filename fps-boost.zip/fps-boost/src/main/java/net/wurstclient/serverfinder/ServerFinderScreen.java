/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.serverfinder;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;

import org.lwjgl.glfw.GLFW;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_4267;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_641;
import net.minecraft.class_642;
import net.minecraft.class_642.class_8678;
import net.wurstclient.mixinterface.IMultiplayerScreen;
import net.wurstclient.util.MathUtils;

public class ServerFinderScreen extends class_437
{
	private final class_500 prevScreen;
	
	private class_342 ipBox;
	private class_342 maxThreadsBox;
	private class_4185 searchButton;
	
	private ServerFinderState state;
	private int maxThreads;
	private int checked;
	private int working;
	
	public ServerFinderScreen(class_500 prevScreen)
	{
		super(class_2561.method_43470("Server Finder"));
		this.prevScreen = prevScreen;
	}
	
	@Override
	public void method_25426()
	{
		method_37063(searchButton =
			class_4185.method_46430(class_2561.method_43470("Search"), b -> searchOrCancel())
				.method_46434(field_22789 / 2 - 100, field_22790 / 4 + 96 + 12, 200, 20)
				.method_46431());
		searchButton.field_22763 = false;
		
		method_37063(
			class_4185
				.method_46430(class_2561.method_43470("Tutorial"),
					b -> class_156.method_668().method_670(
						"https://www.wurstclient.net/serverfinder-tutorial/"))
				.method_46434(field_22789 / 2 - 100, field_22790 / 4 + 120 + 12, 200, 20)
				.method_46431());
		
		method_37063(
			class_4185.method_46430(class_2561.method_43470("Back"), b -> method_25419())
				.method_46434(field_22789 / 2 - 100, field_22790 / 4 + 144 + 12, 200, 20)
				.method_46431());
		
		ipBox = new class_342(field_22793, field_22789 / 2 - 100,
			field_22790 / 4 + 34, 200, 20, class_2561.method_43473());
		ipBox.method_1880(200);
		method_25429(ipBox);
		method_25395(ipBox);
		
		maxThreadsBox = new class_342(field_22793, field_22789 / 2 - 32,
			field_22790 / 4 + 58, 26, 12, class_2561.method_43473());
		maxThreadsBox.method_1880(3);
		maxThreadsBox.method_1852("128");
		method_25429(maxThreadsBox);
		
		state = ServerFinderState.NOT_RUNNING;
	}
	
	private void searchOrCancel()
	{
		if(state.isRunning())
		{
			state = ServerFinderState.CANCELLED;
			ipBox.field_22763 = true;
			maxThreadsBox.field_22763 = true;
			searchButton.method_25355(class_2561.method_43470("Search"));
			return;
		}
		
		state = ServerFinderState.RESOLVING;
		maxThreads = Integer.parseInt(maxThreadsBox.method_1882());
		ipBox.field_22763 = false;
		maxThreadsBox.field_22763 = false;
		searchButton.method_25355(class_2561.method_43470("Cancel"));
		checked = 0;
		working = 0;
		
		new Thread(this::findServers, "Server Finder").start();
	}
	
	private void findServers()
	{
		try
		{
			InetAddress addr =
				InetAddress.getByName(ipBox.method_1882().split(":")[0].trim());
			
			int[] ipParts = new int[4];
			for(int i = 0; i < 4; i++)
				ipParts[i] = addr.getAddress()[i] & 0xff;
			
			state = ServerFinderState.SEARCHING;
			ArrayList<WurstServerPinger> pingers = new ArrayList<>();
			int[] changes = {0, 1, -1, 2, -2, 3, -3};
			for(int change : changes)
				for(int i2 = 0; i2 <= 255; i2++)
				{
					if(state == ServerFinderState.CANCELLED)
						return;
					
					int[] ipParts2 = ipParts.clone();
					ipParts2[2] = ipParts[2] + change & 0xff;
					ipParts2[3] = i2;
					String ip = ipParts2[0] + "." + ipParts2[1] + "."
						+ ipParts2[2] + "." + ipParts2[3];
					
					WurstServerPinger pinger = new WurstServerPinger();
					pinger.ping(ip);
					pingers.add(pinger);
					while(pingers.size() >= maxThreads)
					{
						if(state == ServerFinderState.CANCELLED)
							return;
						
						updatePingers(pingers);
					}
				}
			while(pingers.size() > 0)
			{
				if(state == ServerFinderState.CANCELLED)
					return;
				
				updatePingers(pingers);
			}
			state = ServerFinderState.DONE;
			
		}catch(UnknownHostException e)
		{
			state = ServerFinderState.UNKNOWN_HOST;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			state = ServerFinderState.ERROR;
		}
	}
	
	private void updatePingers(ArrayList<WurstServerPinger> pingers)
	{
		for(int i = 0; i < pingers.size(); i++)
		{
			WurstServerPinger pinger = pingers.get(i);
			if(pinger.isStillPinging())
				continue;
			
			checked++;
			if(pinger.isWorking())
			{
				working++;
				String name = "Grief me #" + working;
				String ip = pinger.getServerIP();
				addServerToList(name, ip);
			}
			
			pingers.remove(i);
			i--;
		}
	}
	
	// Basically what MultiplayerScreen.addEntry() does,
	// but without changing the current screen.
	private void addServerToList(String name, String ip)
	{
		class_641 serverList = prevScreen.method_2529();
		if(serverList.method_44295(ip) != null)
			return;
		
		serverList.method_2988(new class_642(name, ip, class_8678.field_45611), false);
		serverList.method_2987();
		
		class_4267 selector =
			((IMultiplayerScreen)prevScreen).getServerListSelector();
		selector.method_20122(null);
		selector.method_20125(serverList);
	}
	
	@Override
	public void method_25393()
	{
		searchButton.field_22763 = MathUtils.isInteger(maxThreadsBox.method_1882())
			&& !ipBox.method_1882().isEmpty();
	}
	
	@Override
	public boolean method_25404(int keyCode, int scanCode, int int_3)
	{
		if(keyCode == GLFW.GLFW_KEY_ENTER)
			searchButton.method_25306();
		
		return super.method_25404(keyCode, scanCode, int_3);
	}
	
	@Override
	public boolean method_25402(double mouseX, double mouseY, int button)
	{
		if(button == GLFW.GLFW_MOUSE_BUTTON_4)
		{
			method_25419();
			return true;
		}
		
		return super.method_25402(mouseX, mouseY, button);
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		method_25420(context, mouseX, mouseY, partialTicks);
		
		context.method_25300(field_22793, "Server Finder",
			field_22789 / 2, 20, 16777215);
		context.method_25300(field_22793,
			"This will search for servers with similar IPs", field_22789 / 2, 40,
			10526880);
		context.method_25300(field_22793,
			"to the IP you type into the field below.", field_22789 / 2, 50,
			10526880);
		context.method_25300(field_22793,
			"The servers it finds will be added to your server list.",
			field_22789 / 2, 60, 10526880);
		
		context.method_25303(field_22793, "Server address:",
			field_22789 / 2 - 100, field_22790 / 4 + 24, 10526880);
		ipBox.method_25394(context, mouseX, mouseY, partialTicks);
		
		context.method_25303(field_22793, "Max. threads:",
			field_22789 / 2 - 100, field_22790 / 4 + 60, 10526880);
		maxThreadsBox.method_25394(context, mouseX, mouseY, partialTicks);
		
		context.method_25300(field_22793, state.toString(),
			field_22789 / 2, field_22790 / 4 + 73, 10526880);
		
		context.method_25303(field_22793,
			"Checked: " + checked + " / 1792", field_22789 / 2 - 100, field_22790 / 4 + 84,
			10526880);
		context.method_25303(field_22793, "Working: " + working,
			field_22789 / 2 - 100, field_22790 / 4 + 94, 10526880);
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
	}
	
	@Override
	public void method_25419()
	{
		state = ServerFinderState.CANCELLED;
		field_22787.method_1507(prevScreen);
	}
	
	enum ServerFinderState
	{
		NOT_RUNNING(""),
		SEARCHING("\u00a72Searching..."),
		RESOLVING("\u00a72Resolving..."),
		UNKNOWN_HOST("\u00a74Unknown Host!"),
		CANCELLED("\u00a74Cancelled!"),
		DONE("\u00a72Done!"),
		ERROR("\u00a74An error occurred!");
		
		private final String name;
		
		private ServerFinderState(String name)
		{
			this.name = name;
		}
		
		public boolean isRunning()
		{
			return this == SEARCHING || this == RESOLVING;
		}
		
		@Override
		public String toString()
		{
			return name;
		}
	}
}
