/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.commands;

import java.util.Comparator;
import java.util.stream.StreamSupport;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.wurstclient.command.CmdError;
import net.wurstclient.command.CmdException;
import net.wurstclient.command.CmdSyntaxError;
import net.wurstclient.command.Command;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.util.FakePlayerEntity;
import net.wurstclient.util.MathUtils;

public final class TpCmd extends Command
{
	private final CheckboxSetting disableFreecam =
		new CheckboxSetting("Disable Freecam",
			"Disables Freecam just before teleporting.\n\n"
				+ "This allows you to teleport your actual character to your"
				+ " Freecam position by typing \".tp ~ ~ ~\" while Freecam is"
				+ " enabled.",
			true);
	
	public TpCmd()
	{
		super("tp", "Teleports you up to 10 blocks away.", ".tp <x> <y> <z>",
			".tp <entity>");
		addSetting(disableFreecam);
	}
	
	@Override
	public void call(String[] args) throws CmdException
	{
		class_2338 pos = argsToPos(args);
		
		if(disableFreecam.isChecked() && WURST.getHax().freecamHack.isEnabled())
			WURST.getHax().freecamHack.setEnabled(false);
		
		MC.field_1724.method_5814(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5);
	}
	
	private class_2338 argsToPos(String... args) throws CmdException
	{
		switch(args.length)
		{
			default:
			throw new CmdSyntaxError("Invalid coordinates.");
			
			case 1:
			return argsToEntityPos(args[0]);
			
			case 3:
			return argsToXyzPos(args);
		}
	}
	
	private class_2338 argsToEntityPos(String name) throws CmdError
	{
		class_1309 entity = StreamSupport
			.stream(MC.field_1687.method_18112().spliterator(), true)
			.filter(class_1309.class::isInstance).map(e -> (class_1309)e)
			.filter(e -> !e.method_31481() && e.method_6032() > 0)
			.filter(e -> e != MC.field_1724)
			.filter(e -> !(e instanceof FakePlayerEntity))
			.filter(e -> name.equalsIgnoreCase(e.method_5476().getString()))
			.min(
				Comparator.comparingDouble(e -> MC.field_1724.method_5858(e)))
			.orElse(null);
		
		if(entity == null)
			throw new CmdError("Entity \"" + name + "\" could not be found.");
		
		return class_2338.method_49638(entity.method_19538());
	}
	
	private class_2338 argsToXyzPos(String... xyz) throws CmdSyntaxError
	{
		class_2338 playerPos = class_2338.method_49638(MC.field_1724.method_19538());
		int[] player = {playerPos.method_10263(), playerPos.method_10264(), playerPos.method_10260()};
		int[] pos = new int[3];
		
		for(int i = 0; i < 3; i++)
			if(MathUtils.isInteger(xyz[i]))
				pos[i] = Integer.parseInt(xyz[i]);
			else if(xyz[i].equals("~"))
				pos[i] = player[i];
			else if(xyz[i].startsWith("~")
				&& MathUtils.isInteger(xyz[i].substring(1)))
				pos[i] = player[i] + Integer.parseInt(xyz[i].substring(1));
			else
				throw new CmdSyntaxError("Invalid coordinates.");
			
		return new class_2338(pos[0], pos[1], pos[2]);
	}
}
