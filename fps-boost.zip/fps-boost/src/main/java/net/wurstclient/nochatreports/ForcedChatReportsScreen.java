/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.nochatreports;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5489;
import net.minecraft.class_8828.class_2585;
import net.wurstclient.WurstClient;
import net.wurstclient.other_features.NoChatReportsOtf;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.LastServerRememberer;

public final class ForcedChatReportsScreen extends class_437
{
	private static final List<String> TRANSLATABLE_DISCONNECT_REASONS =
		Arrays.asList("multiplayer.disconnect.missing_public_key",
			"multiplayer.disconnect.invalid_public_key_signature",
			"multiplayer.disconnect.invalid_public_key",
			"multiplayer.disconnect.unsigned_chat");
	
	private static final List<String> LITERAL_DISCONNECT_REASONS =
		Arrays.asList("An internal error occurred in your connection.",
			"A secure profile is required to join this server.",
			"Secure profile expired.", "Secure profile invalid.");
	
	private final class_437 prevScreen;
	private final class_2561 reason;
	private class_5489 reasonFormatted = class_5489.field_26528;
	private int reasonHeight;
	
	private class_4185 signatureButton;
	private final Supplier<String> sigButtonMsg;
	
	public ForcedChatReportsScreen(class_437 prevScreen)
	{
		super(class_2561.method_43470(ChatUtils.WURST_PREFIX)
			.method_10852(class_2561.method_43470(WurstClient.INSTANCE
				.translate("gui.wurst.nochatreports.unsafe_server.title"))));
		this.prevScreen = prevScreen;
		
		reason = class_2561.method_43470(WurstClient.INSTANCE
			.translate("gui.wurst.nochatreports.unsafe_server.message"));
		
		NoChatReportsOtf ncr = WurstClient.INSTANCE.getOtfs().noChatReportsOtf;
		sigButtonMsg = () -> WurstClient.INSTANCE
			.translate("button.wurst.nochatreports.signatures_status")
			+ blockedOrAllowed(ncr.isEnabled());
	}
	
	private String blockedOrAllowed(boolean blocked)
	{
		return WurstClient.INSTANCE.translate(
			"gui.wurst.generic.allcaps_" + (blocked ? "blocked" : "allowed"));
	}
	
	@Override
	protected void method_25426()
	{
		reasonFormatted =
			class_5489.method_30890(field_22793, reason, field_22789 - 50);
		reasonHeight = reasonFormatted.method_30887() * field_22793.field_2000;
		
		int buttonX = field_22789 / 2 - 100;
		int belowReasonY =
			(field_22790 - 78) / 2 + reasonHeight / 2 + field_22793.field_2000 * 2;
		int signaturesY = Math.min(belowReasonY, field_22790 - 68);
		int reconnectY = signaturesY + 24;
		int backButtonY = reconnectY + 24;
		
		method_37063(signatureButton = class_4185
			.method_46430(class_2561.method_43470(sigButtonMsg.get()), b -> toggleSignatures())
			.method_46434(buttonX, signaturesY, 200, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Reconnect"),
				b -> LastServerRememberer.reconnect(prevScreen))
			.method_46434(buttonX, reconnectY, 200, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43471("gui.toMenu"),
				b -> field_22787.method_1507(prevScreen))
			.method_46434(buttonX, backButtonY, 200, 20).method_46431());
	}
	
	private void toggleSignatures()
	{
		WurstClient.INSTANCE.getOtfs().noChatReportsOtf.doPrimaryAction();
		signatureButton.method_25355(class_2561.method_43470(sigButtonMsg.get()));
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		method_25420(context, mouseX, mouseY, partialTicks);
		
		int centerX = field_22789 / 2;
		int reasonY = (field_22790 - 68) / 2 - reasonHeight / 2;
		int titleY = reasonY - field_22793.field_2000 * 2;
		
		context.method_27534(field_22793, field_22785, centerX, titleY,
			0xAAAAAA);
		reasonFormatted.method_30888(context, centerX, reasonY);
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
	}
	
	@Override
	public boolean method_25422()
	{
		return false;
	}
	
	public static boolean isCausedByNoChatReports(class_2561 disconnectReason)
	{
		if(!WurstClient.INSTANCE.getOtfs().noChatReportsOtf.isActive())
			return false;
		
		if(disconnectReason.method_10851() instanceof class_2588 tr
			&& TRANSLATABLE_DISCONNECT_REASONS.contains(tr.method_11022()))
			return true;
		
		if(disconnectReason.method_10851() instanceof class_2585 lt
			&& LITERAL_DISCONNECT_REASONS.contains(lt.comp_737()))
			return true;
		
		return false;
	}
}
