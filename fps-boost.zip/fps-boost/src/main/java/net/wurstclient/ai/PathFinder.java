/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.ai;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import com.mojang.blaze3d.platform.GlConst;
import com.mojang.blaze3d.systems.RenderSystem;

import net.minecraft.block.*;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2266;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_2354;
import net.minecraft.class_238;
import net.minecraft.class_2399;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_2440;
import net.minecraft.class_2478;
import net.minecraft.class_2490;
import net.minecraft.class_2492;
import net.minecraft.class_2538;
import net.minecraft.class_2541;
import net.minecraft.class_2544;
import net.minecraft.class_2560;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3611;
import net.minecraft.class_3616;
import net.minecraft.class_3621;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4770;
import net.wurstclient.WurstClient;
import net.wurstclient.WurstRenderLayers;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.RegionPos;
import net.wurstclient.util.RenderUtils;

public class PathFinder
{
	private static final class_310 MC = WurstClient.MC;
	
	private final PlayerAbilities abilities = PlayerAbilities.get();
	protected boolean fallingAllowed = true;
	protected boolean divingAllowed = true;
	
	private final PathPos start;
	protected PathPos current;
	private final class_2338 goal;
	
	private final HashMap<PathPos, Float> costMap = new HashMap<>();
	protected final HashMap<PathPos, PathPos> prevPosMap = new HashMap<>();
	private final PathQueue queue = new PathQueue();
	
	protected int thinkSpeed = 1024;
	protected int thinkTime = 200;
	private int iterations;
	
	protected boolean done;
	protected boolean failed;
	private final ArrayList<PathPos> path = new ArrayList<>();
	
	public PathFinder(class_2338 goal)
	{
		if(MC.field_1724.method_24828())
			start = new PathPos(class_2338.method_49637(MC.field_1724.method_23317(),
				MC.field_1724.method_23318() + 0.5, MC.field_1724.method_23321()));
		else
			start = new PathPos(class_2338.method_49638(MC.field_1724.method_19538()));
		this.goal = goal;
		
		costMap.put(start, 0F);
		queue.add(start, getHeuristic(start));
	}
	
	public PathFinder(PathFinder pathFinder)
	{
		this(pathFinder.goal);
		thinkSpeed = pathFinder.thinkSpeed;
		thinkTime = pathFinder.thinkTime;
	}
	
	public void think()
	{
		if(done)
			throw new IllegalStateException("Path was already found!");
		
		int i = 0;
		for(; i < thinkSpeed && !checkFailed(); i++)
		{
			// get next position from queue
			current = queue.poll();
			
			// check if path is found
			if(checkDone())
				return;
			
			// add neighbors to queue
			for(PathPos next : getNeighbors(current))
			{
				// check cost
				float newCost = costMap.get(current) + getCost(current, next);
				if(costMap.containsKey(next) && costMap.get(next) <= newCost)
					continue;
				
				// add to queue
				costMap.put(next, newCost);
				prevPosMap.put(next, current);
				queue.add(next, newCost + getHeuristic(next));
			}
		}
		iterations += i;
	}
	
	protected boolean checkDone()
	{
		return done = goal.equals(current);
	}
	
	private boolean checkFailed()
	{
		return failed = queue.isEmpty() || iterations >= thinkSpeed * thinkTime;
	}
	
	private ArrayList<PathPos> getNeighbors(PathPos pos)
	{
		ArrayList<PathPos> neighbors = new ArrayList<>();
		
		// abort if too far away
		if(Math.abs(start.method_10263() - pos.method_10263()) > 256
			|| Math.abs(start.method_10260() - pos.method_10260()) > 256)
			return neighbors;
		
		// get all neighbors
		class_2338 north = pos.method_10095();
		class_2338 east = pos.method_10078();
		class_2338 south = pos.method_10072();
		class_2338 west = pos.method_10067();
		
		class_2338 northEast = north.method_10078();
		class_2338 southEast = south.method_10078();
		class_2338 southWest = south.method_10067();
		class_2338 northWest = north.method_10067();
		
		class_2338 up = pos.method_10084();
		class_2338 down = pos.method_10074();
		
		// flying
		boolean flying = canFlyAt(pos);
		// walking
		boolean onGround = canBeSolid(down);
		
		// player can move sideways if flying, standing on the ground, jumping,
		// or inside of a block that allows sideways movement (ladders, webs,
		// etc.)
		if(flying || onGround || pos.isJumping()
			|| canMoveSidewaysInMidairAt(pos) || canClimbUpAt(pos.method_10074()))
		{
			// north
			if(checkHorizontalMovement(pos, north))
				neighbors.add(new PathPos(north));
			
			// east
			if(checkHorizontalMovement(pos, east))
				neighbors.add(new PathPos(east));
			
			// south
			if(checkHorizontalMovement(pos, south))
				neighbors.add(new PathPos(south));
			
			// west
			if(checkHorizontalMovement(pos, west))
				neighbors.add(new PathPos(west));
			
			// north-east
			if(checkDiagonalMovement(pos, class_2350.field_11043, class_2350.field_11034))
				neighbors.add(new PathPos(northEast));
			
			// south-east
			if(checkDiagonalMovement(pos, class_2350.field_11035, class_2350.field_11034))
				neighbors.add(new PathPos(southEast));
			
			// south-west
			if(checkDiagonalMovement(pos, class_2350.field_11035, class_2350.field_11039))
				neighbors.add(new PathPos(southWest));
			
			// north-west
			if(checkDiagonalMovement(pos, class_2350.field_11043, class_2350.field_11039))
				neighbors.add(new PathPos(northWest));
		}
		
		// up
		if(pos.method_10264() < MC.field_1687.method_31600() && canGoThrough(up.method_10084())
			&& (flying || onGround || canClimbUpAt(pos))
			&& (flying || canClimbUpAt(pos) || goal.equals(up)
				|| canSafelyStandOn(north) || canSafelyStandOn(east)
				|| canSafelyStandOn(south) || canSafelyStandOn(west))
			&& (divingAllowed || BlockUtils.getBlock(up.method_10084()) != class_2246.field_10382))
			neighbors.add(new PathPos(up, onGround));
		
		// down
		if(pos.method_10264() > MC.field_1687.method_31607() && canGoThrough(down)
			&& canGoAbove(down.method_10074()) && (flying || canFallBelow(pos))
			&& (divingAllowed || BlockUtils.getBlock(pos) != class_2246.field_10382))
			neighbors.add(new PathPos(down));
		
		return neighbors;
	}
	
	private boolean checkHorizontalMovement(class_2338 current, class_2338 next)
	{
		if(isPassable(next) && (canFlyAt(current) || canGoThrough(next.method_10074())
			|| canSafelyStandOn(next.method_10074())))
			return true;
		
		return false;
	}
	
	private boolean checkDiagonalMovement(class_2338 current,
		class_2350 direction1, class_2350 direction2)
	{
		class_2338 horizontal1 = current.method_10093(direction1);
		class_2338 horizontal2 = current.method_10093(direction2);
		class_2338 next = horizontal1.method_10093(direction2);
		
		if(isPassableWithoutMining(horizontal1)
			&& isPassableWithoutMining(horizontal2)
			&& checkHorizontalMovement(current, next))
			return true;
		
		return false;
	}
	
	protected boolean isPassable(class_2338 pos)
	{
		if(!canGoThrough(pos) && !isMineable(pos))
			return false;
		
		class_2338 up = pos.method_10084();
		if(!canGoThrough(up) && !isMineable(up))
			return false;
		
		if(!canGoAbove(pos.method_10074()))
			return false;
		
		if(!divingAllowed && BlockUtils.getBlock(up) == class_2246.field_10382)
			return false;
		
		return true;
	}
	
	protected boolean isPassableWithoutMining(class_2338 pos)
	{
		if(!canGoThrough(pos))
			return false;
		
		class_2338 up = pos.method_10084();
		if(!canGoThrough(up))
			return false;
		
		if(!canGoAbove(pos.method_10074()))
			return false;
		
		if(!divingAllowed && BlockUtils.getBlock(up) == class_2246.field_10382)
			return false;
		
		return true;
	}
	
	protected boolean isMineable(class_2338 pos)
	{
		return false;
	}
	
	@SuppressWarnings("deprecation")
	protected boolean canBeSolid(class_2338 pos)
	{
		class_2680 state = BlockUtils.getState(pos);
		class_2248 block = state.method_26204();
		
		return state.method_51366() && !(block instanceof class_2478)
			|| block instanceof class_2399 || abilities.jesus()
				&& (block == class_2246.field_10382 || block == class_2246.field_10164);
	}
	
	@SuppressWarnings("deprecation")
	private boolean canGoThrough(class_2338 pos)
	{
		// check if loaded
		// Can't see why isChunkLoaded() is deprecated. Still seems to be widely
		// used with no replacement.
		if(!MC.field_1687.method_22340(pos))
			return false;
		
		// check if solid
		class_2680 state = BlockUtils.getState(pos);
		class_2248 block = state.method_26204();
		if(state.method_51366() && !(block instanceof class_2478))
			return false;
		
		// check if trapped
		if(block instanceof class_2538
			|| block instanceof class_2440)
			return false;
		
		// check if safe
		if(!abilities.invulnerable()
			&& (block == class_2246.field_10164 || block instanceof class_4770))
			return false;
		
		return true;
	}
	
	private boolean canGoAbove(class_2338 pos)
	{
		// check for fences, etc.
		class_2248 block = BlockUtils.getBlock(pos);
		if(block instanceof class_2354 || block instanceof class_2544
			|| block instanceof class_2349)
			return false;
		
		return true;
	}
	
	private boolean canSafelyStandOn(class_2338 pos)
	{
		// check if solid
		if(!canBeSolid(pos))
			return false;
		
		// check if safe
		class_2680 state = BlockUtils.getState(pos);
		class_3611 fluid = state.method_26227().method_15772();
		if(!abilities.invulnerable() && (state.method_26204() instanceof class_2266
			|| fluid instanceof class_3616))
			return false;
		
		return true;
	}
	
	private boolean canFallBelow(PathPos pos)
	{
		// check if player can keep falling
		class_2338 down2 = pos.method_10087(2);
		if(fallingAllowed && canGoThrough(down2))
			return true;
		
		// check if player can stand below
		if(!canSafelyStandOn(down2))
			return false;
		
		// check if fall damage is off
		if(abilities.immuneToFallDamage() && fallingAllowed)
			return true;
		
		// check if fall ends with slime block
		if(BlockUtils.getBlock(down2) instanceof class_2490 && fallingAllowed)
			return true;
		
		// check fall damage
		class_2338 prevPos = pos;
		for(int i = 0; i <= (fallingAllowed ? 3 : 1); i++)
		{
			// check if prevPos does not exist, meaning that the pathfinding
			// started during the fall and fall damage should be ignored because
			// it cannot be prevented
			if(prevPos == null)
				return true;
				
			// check if point is not part of this fall, meaning that the fall is
			// too short to cause any damage
			if(!pos.method_10086(i).equals(prevPos))
				return true;
			
			// check if block resets fall damage
			class_2248 prevBlock = BlockUtils.getBlock(prevPos);
			class_2680 prevState = BlockUtils.getState(prevPos);
			if(prevState.method_26227().method_15772() instanceof class_3621
				|| prevBlock instanceof class_2399
				|| prevBlock instanceof class_2541
				|| prevBlock instanceof class_2560)
				return true;
			
			prevPos = prevPosMap.get(prevPos);
		}
		
		return false;
	}
	
	private boolean canFlyAt(class_2338 pos)
	{
		return abilities.flying() || !abilities.noWaterSlowdown()
			&& BlockUtils.getBlock(pos) == class_2246.field_10382;
	}
	
	private boolean canClimbUpAt(class_2338 pos)
	{
		// check if this block works for climbing
		class_2248 block = BlockUtils.getBlock(pos);
		if(!abilities.spider() && !(block instanceof class_2399)
			&& !(block instanceof class_2541))
			return false;
		
		// check if any adjacent block is solid
		class_2338 up = pos.method_10084();
		if(!canBeSolid(pos.method_10095()) && !canBeSolid(pos.method_10078())
			&& !canBeSolid(pos.method_10072()) && !canBeSolid(pos.method_10067())
			&& !canBeSolid(up.method_10095()) && !canBeSolid(up.method_10078())
			&& !canBeSolid(up.method_10072()) && !canBeSolid(up.method_10067()))
			return false;
		
		return true;
	}
	
	private boolean canMoveSidewaysInMidairAt(class_2338 pos)
	{
		// check feet
		class_2248 blockFeet = BlockUtils.getBlock(pos);
		if(BlockUtils.getBlock(pos) instanceof class_2404
			|| blockFeet instanceof class_2399
			|| blockFeet instanceof class_2541
			|| blockFeet instanceof class_2560)
			return true;
		
		// check head
		class_2248 blockHead = BlockUtils.getBlock(pos.method_10084());
		if(BlockUtils.getBlock(pos.method_10084()) instanceof class_2404
			|| blockHead instanceof class_2560)
			return true;
		
		return false;
	}
	
	private float getCost(class_2338 current, class_2338 next)
	{
		float[] costs = {0.5F, 0.5F};
		class_2338[] positions = {current, next};
		
		for(int i = 0; i < positions.length; i++)
		{
			class_2338 pos = positions[i];
			class_2248 block = BlockUtils.getBlock(pos);
			
			// liquids
			if(block == class_2246.field_10382 && !abilities.noWaterSlowdown())
				costs[i] *= 1.3164437838225804F;
			else if(block == class_2246.field_10164)
				costs[i] *= 4.539515393656079F;
			
			// soul sand
			if(!canFlyAt(pos)
				&& BlockUtils.getBlock(pos.method_10074()) instanceof class_2492)
				costs[i] *= 2.5F;
			
			// mining
			if(isMineable(pos))
				costs[i] *= 2F;
			if(isMineable(pos.method_10084()))
				costs[i] *= 2F;
		}
		
		float cost = costs[0] + costs[1];
		
		// diagonal movement
		if(current.method_10263() != next.method_10263() && current.method_10260() != next.method_10260())
			cost *= 1.4142135623730951F;
		
		return cost;
	}
	
	private float getHeuristic(class_2338 pos)
	{
		float dx = Math.abs(pos.method_10263() - goal.method_10263());
		float dy = Math.abs(pos.method_10264() - goal.method_10264());
		float dz = Math.abs(pos.method_10260() - goal.method_10260());
		return 1.001F * (dx + dy + dz - 0.5857864376269049F * Math.min(dx, dz));
	}
	
	public PathPos getCurrentPos()
	{
		return current;
	}
	
	public class_2338 getGoal()
	{
		return goal;
	}
	
	public int countProcessedBlocks()
	{
		return prevPosMap.size();
	}
	
	public int getQueueSize()
	{
		return queue.size();
	}
	
	public float getCost(class_2338 pos)
	{
		return costMap.get(pos);
	}
	
	public boolean isDone()
	{
		return done;
	}
	
	public boolean isFailed()
	{
		return failed;
	}
	
	public ArrayList<PathPos> formatPath()
	{
		if(!done && !failed)
			throw new IllegalStateException("No path found!");
		if(!path.isEmpty())
			throw new IllegalStateException("Path was already formatted!");
		
		// get last position
		PathPos pos;
		if(!failed)
			pos = current;
		else
		{
			pos = start;
			for(PathPos next : prevPosMap.keySet())
				if(getHeuristic(next) < getHeuristic(pos)
					&& (canFlyAt(next) || canBeSolid(next.method_10074())))
					pos = next;
		}
		
		// get positions
		while(pos != null)
		{
			path.add(pos);
			pos = prevPosMap.get(pos);
		}
		
		// reverse path
		Collections.reverse(path);
		
		return path;
	}
	
	public void renderPath(class_4587 matrixStack, boolean debugMode,
		boolean depthTest)
	{
		int depthFunc = depthTest ? GlConst.GL_LEQUAL : GlConst.GL_ALWAYS;
		RenderSystem.enableDepthTest();
		RenderSystem.depthFunc(depthFunc);
		
		class_4597.class_4598 vcp =
			MC.method_22940().method_23000();
		class_4588 buffer =
			vcp.getBuffer(WurstRenderLayers.getLines(depthTest));
		
		matrixStack.method_22903();
		
		RegionPos region = RenderUtils.getCameraRegion();
		class_243 regionOffset = region.negate().toVec3d();
		RenderUtils.applyRegionalRenderOffset(matrixStack, region);
		
		if(debugMode)
		{
			int thingsRendered = 0;
			
			// queue (yellow)
			for(PathPos element : queue.toArray())
			{
				if(thingsRendered >= 5000)
					break;
				
				class_238 box = new class_238(element).method_997(regionOffset).method_1011(0.4);
				RenderUtils.drawNode(matrixStack, buffer, box, 0xC0FFFF00);
				thingsRendered++;
			}
			
			// processed (red or magenta)
			for(Entry<PathPos, PathPos> entry : prevPosMap.entrySet())
			{
				if(thingsRendered >= 5000)
					break;
				
				int color =
					entry.getKey().isJumping() ? 0xC0FF00FF : 0xC0FF0000;
				
				RenderUtils.drawArrow(matrixStack, buffer, entry.getValue(),
					entry.getKey(), region, color);
				thingsRendered++;
			}
		}
		
		// path (blue or green)
		int pathColor = debugMode ? 0xC00000FF : 0xC000FF00;
		for(int i = 0; i < path.size() - 1; i++)
			RenderUtils.drawArrow(matrixStack, buffer, path.get(i),
				path.get(i + 1), region, pathColor);
		
		matrixStack.method_22909();
		
		vcp.method_37104();
	}
	
	public boolean isPathStillValid(int index)
	{
		if(path.isEmpty())
			throw new IllegalStateException("Path is not formatted!");
		
		// check player abilities
		if(!abilities.equals(PlayerAbilities.get()))
			return false;
		
		// if index is zero, check if first pos is safe
		if(index == 0)
		{
			PathPos pos = path.get(0);
			if(!isPassable(pos) || !canFlyAt(pos) && !canGoThrough(pos.method_10074())
				&& !canSafelyStandOn(pos.method_10074()))
				return false;
		}
		
		// check path
		for(int i = Math.max(1, index); i < path.size(); i++)
			if(!getNeighbors(path.get(i - 1)).contains(path.get(i)))
				return false;
			
		return true;
	}
	
	public PathProcessor getProcessor()
	{
		if(abilities.flying())
			return new FlyPathProcessor(path, abilities.creativeFlying());
		
		return new WalkPathProcessor(path);
	}
	
	public void setThinkSpeed(int thinkSpeed)
	{
		this.thinkSpeed = thinkSpeed;
	}
	
	public void setThinkTime(int thinkTime)
	{
		this.thinkTime = thinkTime;
	}
	
	public void setFallingAllowed(boolean fallingAllowed)
	{
		this.fallingAllowed = fallingAllowed;
	}
	
	public void setDivingAllowed(boolean divingAllowed)
	{
		this.divingAllowed = divingAllowed;
	}
	
	public List<PathPos> getPath()
	{
		return Collections.unmodifiableList(path);
	}
}
