/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient;

import java.util.OptionalDouble;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_4668;

public enum WurstRenderLayers
{
	;
	
	/**
	 * Similar to {@link class_1921#method_49043(double)}, but as a
	 * non-srip version with support for transparency.
	 *
	 * @implNote Just like {@link class_1921#method_49043(double)}, this
	 *           layer doesn't support any other line width than 1px. Changing
	 *           the line width number does nothing.
	 */
	public static final class_1921.class_4687 ONE_PIXEL_LINES =
		class_1921.method_24049("wurst:1px_lines", class_290.field_1576,
			class_5596.field_29344, 1536, false, true,
			class_1921.class_4688.method_23598()
				.method_34578(class_1921.field_29442)
				.method_23609(new class_4668.class_4677(OptionalDouble.of(1)))
				.method_23615(class_1921.field_21370)
				.method_23603(class_1921.field_21345).method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_49043(double)}, but with
	 * support for transparency.
	 *
	 * @implNote Just like {@link class_1921#method_49043(double)}, this
	 *           layer doesn't support any other line width than 1px. Changing
	 *           the line width number does nothing.
	 */
	public static final class_1921.class_4687 ONE_PIXEL_LINE_STRIP =
		class_1921.method_24049("wurst:1px_line_strip", class_290.field_1576,
			class_5596.field_29345, 1536, false, true,
			class_1921.class_4688.method_23598()
				.method_34578(class_1921.field_29442)
				.method_23609(new class_4668.class_4677(OptionalDouble.of(1)))
				.method_23615(class_1921.field_21370)
				.method_23603(class_1921.field_21345).method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_23594()}, but with line width 2.
	 */
	public static final class_1921.class_4687 LINES =
		class_1921.method_24049("wurst:lines", class_290.field_29337,
			class_293.class_5596.field_27377, 1536, false, true,
			class_1921.class_4688.method_23598()
				.method_34578(class_1921.field_29433)
				.method_23609(new class_4668.class_4677(OptionalDouble.of(2)))
				.method_23607(class_1921.field_22241)
				.method_23615(class_1921.field_21370)
				.method_23610(class_1921.field_25643)
				.method_23616(class_1921.field_21349)
				.method_23604(class_1921.field_21348)
				.method_23603(class_1921.field_21345).method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_23594()}, but with line width 2 and no
	 * depth test.
	 *
	 * @apiNote Until 25w08a (1.21.5), turning off depth test has to be done
	 *          manually, by calling
	 *          {@code RenderSystem.depthFunc(GlConst.GL_ALWAYS);} before
	 *          drawing the ESP lines. Without this code, ESP lines will be
	 *          drawn with depth test set to LEQUALS (only visible if not
	 *          obstructed).
	 */
	public static final class_1921.class_4687 ESP_LINES =
		class_1921.method_24049("wurst:esp_lines", class_290.field_29337,
			class_293.class_5596.field_27377, 1536, false, true,
			class_1921.class_4688.method_23598()
				.method_34578(class_1921.field_29433)
				.method_23609(new class_4668.class_4677(OptionalDouble.of(2)))
				.method_23607(class_1921.field_22241)
				.method_23615(class_1921.field_21370)
				.method_23610(class_1921.field_25643)
				.method_23616(class_1921.field_21349)
				.method_23604(class_1921.field_21346)
				.method_23603(class_1921.field_21345).method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_34572()}, but with line width 2.
	 *
	 * @apiNote Until 25w08a (1.21.5), turning off depth test has to be done
	 *          manually, by calling
	 *          {@code RenderSystem.depthFunc(GlConst.GL_ALWAYS);} before
	 *          drawing the ESP lines. Without this code, ESP lines will be
	 *          drawn with depth test set to LEQUALS (only visible if not
	 *          obstructed).
	 */
	public static final class_1921.class_4687 LINE_STRIP =
		class_1921.method_24049("wurst:line_strip", class_290.field_29337,
			class_293.class_5596.field_27378, 1536, false, true,
			class_1921.class_4688.method_23598()
				.method_34578(class_1921.field_29433)
				.method_23609(new class_4668.class_4677(OptionalDouble.of(2)))
				.method_23607(class_1921.field_22241)
				.method_23615(class_1921.field_21370)
				.method_23610(class_1921.field_25643)
				.method_23616(class_1921.field_21349)
				.method_23604(class_1921.field_21348)
				.method_23603(class_1921.field_21345).method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_34572()}, but with line width 2 and
	 * no depth test.
	 *
	 * @apiNote Until 25w08a (1.21.5), turning off depth test has to be done
	 *          manually, by calling
	 *          {@code RenderSystem.depthFunc(GlConst.GL_ALWAYS);} before
	 *          drawing the ESP lines. Without this code, ESP lines will be
	 *          drawn with depth test set to LEQUALS (only visible if not
	 *          obstructed).
	 */
	public static final class_1921.class_4687 ESP_LINE_STRIP =
		class_1921.method_24049("wurst:esp_line_strip", class_290.field_29337,
			class_293.class_5596.field_27378, 1536, false, true,
			class_1921.class_4688.method_23598()
				.method_34578(class_1921.field_29433)
				.method_23609(new class_4668.class_4677(OptionalDouble.of(2)))
				.method_23607(class_1921.field_22241)
				.method_23615(class_1921.field_21370)
				.method_23610(class_1921.field_25643)
				.method_23616(class_1921.field_21349)
				.method_23604(class_1921.field_21346)
				.method_23603(class_1921.field_21345).method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_49042()}, but with culling enabled.
	 */
	public static final class_1921.class_4687 QUADS =
		class_1921.method_24049("wurst:quads", class_290.field_1576,
			class_293.class_5596.field_27382, 1536, false, true,
			class_1921.class_4688.method_23598()
				.method_34578(class_1921.field_29442)
				.method_23615(class_1921.field_21370)
				.method_23604(class_1921.field_21348).method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_49042()}, but with culling enabled
	 * and no depth test.
	 *
	 * @apiNote Until 25w08a (1.21.5), turning off depth test has to be done
	 *          manually, by calling
	 *          {@code RenderSystem.depthFunc(GlConst.GL_ALWAYS);} before
	 *          drawing the ESP lines. Without this code, ESP lines will be
	 *          drawn with depth test set to LEQUALS (only visible if not
	 *          obstructed).
	 */
	public static final class_1921.class_4687 ESP_QUADS =
		class_1921.method_24049("wurst:esp_quads", class_290.field_1576,
			class_293.class_5596.field_27382, 1536, false, true,
			class_1921.class_4688.method_23598()
				.method_34578(class_1921.field_29442)
				.method_23615(class_1921.field_21370)
				.method_23604(class_1921.field_21346).method_23617(false));
	
	/**
	 * Similar to {@link class_1921#method_49042()}, but with no depth test.
	 *
	 * @apiNote Until 25w08a (1.21.5), turning off depth test has to be done
	 *          manually, by calling
	 *          {@code RenderSystem.depthFunc(GlConst.GL_ALWAYS);} before
	 *          drawing the ESP lines. Without this code, ESP lines will be
	 *          drawn with depth test set to LEQUALS (only visible if not
	 *          obstructed).
	 */
	public static final class_1921.class_4687 ESP_QUADS_NO_CULLING =
		class_1921.method_24049("wurst:esp_quads_no_culling",
			class_290.field_1576, class_293.class_5596.field_27382, 1536,
			false, true,
			class_1921.class_4688.method_23598()
				.method_34578(class_1921.field_29442)
				.method_23615(class_1921.field_21370)
				.method_23603(class_1921.field_21345)
				.method_23604(class_1921.field_21346).method_23617(false));
	
	/**
	 * Returns either {@link #QUADS} or {@link #ESP_QUADS} depending on the
	 * value of {@code depthTest}.
	 *
	 * @apiNote Until 25w08a (1.21.5), turning off depth test has to be done
	 *          manually, by calling
	 *          {@code RenderSystem.depthFunc(GlConst.GL_ALWAYS);} before
	 *          drawing the ESP lines. Without this code, ESP lines will be
	 *          drawn with depth test set to LEQUALS (only visible if not
	 *          obstructed).
	 */
	public static class_1921 getQuads(boolean depthTest)
	{
		return depthTest ? QUADS : ESP_QUADS;
	}
	
	/**
	 * Returns either {@link #LINES} or {@link #ESP_LINES} depending on the
	 * value of {@code depthTest}.
	 *
	 * @apiNote Until 25w08a (1.21.5), turning off depth test has to be done
	 *          manually, by calling
	 *          {@code RenderSystem.depthFunc(GlConst.GL_ALWAYS);} before
	 *          drawing the ESP lines. Without this code, ESP lines will be
	 *          drawn with depth test set to LEQUALS (only visible if not
	 *          obstructed).
	 */
	public static class_1921 getLines(boolean depthTest)
	{
		return depthTest ? LINES : ESP_LINES;
	}
	
	/**
	 * Returns either {@link #LINE_STRIP} or {@link #ESP_LINE_STRIP} depending
	 * on the value of {@code depthTest}.
	 *
	 * @apiNote Until 25w08a (1.21.5), turning off depth test has to be done
	 *          manually, by calling
	 *          {@code RenderSystem.depthFunc(GlConst.GL_ALWAYS);} before
	 *          drawing the ESP lines. Without this code, ESP lines will be
	 *          drawn with depth test set to LEQUALS (only visible if not
	 *          obstructed).
	 */
	public static class_1921 getLineStrip(boolean depthTest)
	{
		return depthTest ? LINE_STRIP : ESP_LINE_STRIP;
	}
}
