/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_2873;
import net.minecraft.class_9334;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.EnumSetting;
import net.wurstclient.util.ChatUtils;

@SearchTags({"kill potion", "KillerPotion", "killer potion", "KillingPotion",
	"killing potion", "InstantDeathPotion", "instant death potion"})
public final class KillPotionHack extends Hack
{
	private final EnumSetting<PotionType> potionType =
		new EnumSetting<>("Potion type", "The type of potion to generate.",
			PotionType.values(), PotionType.SPLASH);
	
	public KillPotionHack()
	{
		super("KillPotion");
		
		setCategory(Category.ITEMS);
		addSetting(potionType);
	}
	
	@Override
	protected void onEnable()
	{
		// check gamemode
		if(!MC.field_1724.method_31549().field_7477)
		{
			ChatUtils.error("Creative mode only.");
			setEnabled(false);
			return;
		}
		
		// generate potion
		class_1799 stack = potionType.getSelected().createPotionStack();
		
		// give potion
		if(placeStackInHotbar(stack))
			ChatUtils.message("Potion created.");
		else
			ChatUtils.error("Please clear a slot in your hotbar.");
		
		setEnabled(false);
	}
	
	private boolean placeStackInHotbar(class_1799 stack)
	{
		for(int i = 0; i < 9; i++)
		{
			if(!MC.field_1724.method_31548().method_5438(i).method_7960())
				continue;
			
			MC.field_1724.field_3944.method_52787(
				new class_2873(36 + i, stack));
			return true;
		}
		
		return false;
	}
	
	private enum PotionType
	{
		NORMAL("Normal", "Potion", class_1802.field_8574),
		
		SPLASH("Splash", "Splash Potion", class_1802.field_8436),
		
		LINGERING("Lingering", "Lingering Potion", class_1802.field_8150);
		
		// does not work
		// ARROW("Arrow", "Arrow", Items.TIPPED_ARROW);
		
		private final String name;
		private final String itemName;
		private final class_1792 item;
		
		private PotionType(String name, String itemName, class_1792 item)
		{
			this.name = name;
			this.itemName = itemName;
			this.item = item;
		}
		
		@Override
		public String toString()
		{
			return name;
		}
		
		public class_1799 createPotionStack()
		{
			class_1799 stack = new class_1799(item);
			
			class_1293 effect = new class_1293(
				class_1294.field_5915, 2000, 125);
			
			class_1844 potionContents =
				new class_1844(Optional.empty(), Optional.empty(),
					List.of(effect));
			
			stack.method_57379(class_9334.field_49651, potionContents);
			
			String name =
				"\u00a7f" + itemName + " of \u00a74\u00a7lINSTANT DEATH";
			stack.method_57379(class_9334.field_49631, class_2561.method_43470(name));
			
			return stack;
		}
	}
}
