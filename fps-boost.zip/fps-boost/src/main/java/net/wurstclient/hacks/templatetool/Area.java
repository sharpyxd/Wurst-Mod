/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.templatetool;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_3532;
import net.wurstclient.util.BlockUtils;

public final class Area
{
	private final int minX, minY, minZ;
	private final int sizeX, sizeY, sizeZ;
	
	private final int totalBlocks, scanSpeed;
	private final Iterator<class_2338> iterator;
	
	private int scannedBlocks;
	private float progress;
	
	private final ArrayList<class_2338> blocksFound = new ArrayList<>();
	
	public Area(class_2338 start, class_2338 end)
	{
		int startX = start.method_10263();
		int startY = start.method_10264();
		int startZ = start.method_10260();
		
		int endX = end.method_10263();
		int endY = end.method_10264();
		int endZ = end.method_10260();
		
		minX = Math.min(startX, endX);
		minY = Math.min(startY, endY);
		minZ = Math.min(startZ, endZ);
		
		sizeX = Math.abs(startX - endX);
		sizeY = Math.abs(startY - endY);
		sizeZ = Math.abs(startZ - endZ);
		
		totalBlocks = (sizeX + 1) * (sizeY + 1) * (sizeZ + 1);
		scanSpeed = class_3532.method_15340(totalBlocks / 30, 1, 1024);
		iterator = BlockUtils.getAllInBox(start, end).iterator();
	}
	
	public int getScannedBlocks()
	{
		return scannedBlocks;
	}
	
	public void setScannedBlocks(int scannedBlocks)
	{
		this.scannedBlocks = scannedBlocks;
	}
	
	public float getProgress()
	{
		return progress;
	}
	
	public void setProgress(float progress)
	{
		this.progress = progress;
	}
	
	public int getMinX()
	{
		return minX;
	}
	
	public int getMinY()
	{
		return minY;
	}
	
	public int getMinZ()
	{
		return minZ;
	}
	
	public int getSizeX()
	{
		return sizeX;
	}
	
	public int getSizeY()
	{
		return sizeY;
	}
	
	public int getSizeZ()
	{
		return sizeZ;
	}
	
	public int getTotalBlocks()
	{
		return totalBlocks;
	}
	
	public int getScanSpeed()
	{
		return scanSpeed;
	}
	
	public Iterator<class_2338> getIterator()
	{
		return iterator;
	}
	
	public ArrayList<class_2338> getBlocksFound()
	{
		return blocksFound;
	}
	
	public class_238 toBox()
	{
		return new class_238(minX, minY, minZ, minX + sizeX, minY + sizeY,
			minZ + sizeZ);
	}
}
