/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.treebot;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_4587;
import net.wurstclient.util.RenderUtils;

public class Tree
{
	private final class_2338 stump;
	private final ArrayList<class_2338> logs;
	
	public Tree(class_2338 stump, ArrayList<class_2338> logs)
	{
		this.stump = stump;
		this.logs = logs;
	}
	
	public void draw(class_4587 matrixStack)
	{
		int green = 0x8000FF00;
		class_238 box = new class_238(class_2338.field_10980).method_1011(1 / 16.0);
		
		class_238 stumpBox = box.method_996(stump);
		RenderUtils.drawCrossBox(matrixStack, stumpBox, green, false);
		
		List<class_238> logBoxes = logs.stream().map(pos -> box.method_996(pos)).toList();
		RenderUtils.drawOutlinedBoxes(matrixStack, logBoxes, green, false);
	}
	
	public class_2338 getStump()
	{
		return stump;
	}
	
	public ArrayList<class_2338> getLogs()
	{
		return logs;
	}
}
