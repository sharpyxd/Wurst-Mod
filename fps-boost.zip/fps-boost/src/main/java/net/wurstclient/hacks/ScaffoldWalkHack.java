/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.Arrays;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2682;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.RotationUtils;

@SearchTags({"scaffold walk", "BridgeWalk", "bridge walk", "AutoBridge",
	"auto bridge", "tower"})
public final class ScaffoldWalkHack extends Hack implements UpdateListener
{
	public ScaffoldWalkHack()
	{
		super("ScaffoldWalk");
		setCategory(Category.BLOCKS);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		class_2338 belowPlayer = class_2338.method_49638(MC.field_1724.method_19538()).method_10074();
		
		// check if block is already placed
		if(!BlockUtils.getState(belowPlayer).method_45474())
			return;
		
		// search blocks in hotbar
		int newSlot = -1;
		for(int i = 0; i < 9; i++)
		{
			// filter out non-block items
			class_1799 stack = MC.field_1724.method_31548().method_5438(i);
			if(stack.method_7960() || !(stack.method_7909() instanceof class_1747))
				continue;
			
			// filter out non-solid blocks
			class_2248 block = class_2248.method_9503(stack.method_7909());
			class_2680 state = block.method_9564();
			if(!state.method_26234(class_2682.field_12294, class_2338.field_10980))
				continue;
			
			// filter out blocks that would fall
			if(block instanceof class_2346 && class_2346
				.method_10128(BlockUtils.getState(belowPlayer.method_10074())))
				continue;
			
			newSlot = i;
			break;
		}
		
		// check if any blocks were found
		if(newSlot == -1)
			return;
		
		// set slot
		int oldSlot = MC.field_1724.method_31548().field_7545;
		MC.field_1724.method_31548().field_7545 = newSlot;
		
		scaffoldTo(belowPlayer);
		
		// reset slot
		MC.field_1724.method_31548().field_7545 = oldSlot;
	}
	
	private void scaffoldTo(class_2338 belowPlayer)
	{
		// tries to place a block directly under the player
		if(placeBlock(belowPlayer))
			return;
			
		// if that doesn't work, tries to place a block next to the block that's
		// under the player
		class_2350[] sides = class_2350.values();
		for(class_2350 side : sides)
		{
			class_2338 neighbor = belowPlayer.method_10093(side);
			if(placeBlock(neighbor))
				return;
		}
		
		// if that doesn't work, tries to place a block next to a block that's
		// next to the block that's under the player
		for(class_2350 side : sides)
			for(class_2350 side2 : Arrays.copyOfRange(sides, side.ordinal(), 6))
			{
				if(side.method_10153().equals(side2))
					continue;
				
				class_2338 neighbor = belowPlayer.method_10093(side).method_10093(side2);
				if(placeBlock(neighbor))
					return;
			}
	}
	
	private boolean placeBlock(class_2338 pos)
	{
		class_243 eyesPos = RotationUtils.getEyesPos();
		
		for(class_2350 side : class_2350.values())
		{
			class_2338 neighbor = pos.method_10093(side);
			class_2350 side2 = side.method_10153();
			
			// check if side is visible (facing away from player)
			if(eyesPos.method_1025(class_243.method_24953(pos)) >= eyesPos
				.method_1025(class_243.method_24953(neighbor)))
				continue;
			
			// check if neighbor can be right clicked
			if(!BlockUtils.canBeClicked(neighbor))
				continue;
			
			class_243 hitVec = class_243.method_24953(neighbor)
				.method_1019(class_243.method_24954(side2.method_10163()).method_1021(0.5));
			
			// check if hitVec is within range (4.25 blocks)
			if(eyesPos.method_1025(hitVec) > 18.0625)
				continue;
			
			// place block
			RotationUtils.getNeededRotations(hitVec).sendPlayerLookPacket();
			IMC.getInteractionManager().rightClickBlock(neighbor, side2,
				hitVec);
			MC.field_1724.method_6104(class_1268.field_5808);
			MC.field_1752 = 4;
			
			return true;
		}
		
		return false;
	}
}
