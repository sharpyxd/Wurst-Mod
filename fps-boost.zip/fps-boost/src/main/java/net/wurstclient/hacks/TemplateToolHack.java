/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.glfw.GLFW;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.wurstclient.Category;
import net.wurstclient.events.GUIRenderListener;
import net.wurstclient.events.RenderListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.hacks.templatetool.Area;
import net.wurstclient.hacks.templatetool.ChooseNameScreen;
import net.wurstclient.hacks.templatetool.Step;
import net.wurstclient.hacks.templatetool.Template;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.RenderUtils;
import net.wurstclient.util.json.JsonUtils;

public final class TemplateToolHack extends Hack
	implements UpdateListener, RenderListener, GUIRenderListener
{
	private Step step;
	private class_2338 posLookingAt;
	private Area area;
	private Template template;
	private File file;
	
	public TemplateToolHack()
	{
		super("TemplateTool");
		setCategory(Category.BLOCKS);
	}
	
	@Override
	public void onEnable()
	{
		// disable conflicting hacks
		WURST.getHax().autoBuildHack.setEnabled(false);
		WURST.getHax().bowAimbotHack.setEnabled(false);
		WURST.getHax().excavatorHack.setEnabled(false);
		
		step = Step.START_POS;
		
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(RenderListener.class, this);
		EVENTS.add(GUIRenderListener.class, this);
	}
	
	@Override
	public void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		EVENTS.remove(GUIRenderListener.class, this);
		
		for(Step step : Step.values())
			step.setPos(null);
		posLookingAt = null;
		area = null;
		template = null;
		file = null;
	}
	
	@Override
	public void onUpdate()
	{
		// select position steps
		if(step.doesSelectPos())
		{
			// continue with next step
			if(step.getPos() != null && class_3675
				.method_15987(MC.method_22683().method_4490(), GLFW.GLFW_KEY_ENTER))
			{
				step = Step.values()[step.ordinal() + 1];
				
				// delete posLookingAt
				if(!step.doesSelectPos())
					posLookingAt = null;
				
				return;
			}
			
			if(MC.field_1765 instanceof class_3965 bHitResult)
			{
				// set posLookingAt
				posLookingAt = bHitResult.method_17777();
				
				// offset if sneaking
				if(MC.field_1690.field_1832.method_1434())
					posLookingAt = posLookingAt.method_10093(bHitResult.method_17780());
				
			}else
				posLookingAt = null;
			
			// set selected position
			if(posLookingAt != null && MC.field_1690.field_1904.method_1434())
				step.setPos(posLookingAt);
			
			// scanning area step
		}else if(step == Step.SCAN_AREA)
		{
			// initialize area
			if(area == null)
			{
				area = new Area(Step.START_POS.getPos(), Step.END_POS.getPos());
				Step.START_POS.setPos(null);
				Step.END_POS.setPos(null);
			}
			
			// scan area
			for(int i = 0; i < area.getScanSpeed()
				&& area.getIterator().hasNext(); i++)
			{
				area.setScannedBlocks(area.getScannedBlocks() + 1);
				class_2338 pos = area.getIterator().next();
				
				if(!BlockUtils.getState(pos).method_45474())
					area.getBlocksFound().add(pos);
			}
			
			// update progress
			area.setProgress(
				(float)area.getScannedBlocks() / (float)area.getTotalBlocks());
			
			// continue with next step
			if(!area.getIterator().hasNext())
				step = Step.values()[step.ordinal() + 1];
			
			// creating template step
		}else if(step == Step.CREATE_TEMPLATE)
		{
			// initialize template
			if(template == null)
				template = new Template(Step.FIRST_BLOCK.getPos(),
					area.getBlocksFound().size());
			
			// sort blocks by distance
			if(!area.getBlocksFound().isEmpty())
			{
				// move blocks to TreeSet
				int min = Math.max(0,
					area.getBlocksFound().size() - template.getScanSpeed());
				for(int i = area.getBlocksFound().size() - 1; i >= min; i--)
				{
					class_2338 pos = area.getBlocksFound().get(i);
					template.getRemainingBlocks().add(pos);
					area.getBlocksFound().remove(i);
				}
				
				// update progress
				template.setProgress((float)template.getRemainingBlocks().size()
					/ (float)template.getTotalBlocks());
				
				return;
			}
			
			// add closest block first
			if(template.getSortedBlocks().isEmpty()
				&& !template.getRemainingBlocks().isEmpty())
			{
				class_2338 first = template.getRemainingBlocks().first();
				template.getSortedBlocks().add(first);
				template.getRemainingBlocks().remove(first);
				template.setLastAddedBlock(first);
			}
			
			// add remaining blocks
			for(int i = 0; i < template.getScanSpeed()
				&& !template.getRemainingBlocks().isEmpty(); i++)
			{
				class_2338 current = template.getRemainingBlocks().first();
				double dCurrent = Double.MAX_VALUE;
				
				for(class_2338 pos : template.getRemainingBlocks())
				{
					double dPos =
						template.getLastAddedBlock().method_10262(pos);
					if(dPos >= dCurrent)
						continue;
					
					for(class_2350 facing : class_2350.values())
					{
						class_2338 next = pos.method_10093(facing);
						if(!template.getSortedBlocks().contains(next))
							continue;
						
						current = pos;
						dCurrent = dPos;
					}
				}
				
				template.getSortedBlocks().add(current);
				template.getRemainingBlocks().remove(current);
				template.setLastAddedBlock(current);
			}
			
			// update progress
			template.setProgress((float)template.getRemainingBlocks().size()
				/ (float)template.getTotalBlocks());
			
			// continue with next step
			if(template.getSortedBlocks().size() == template.getTotalBlocks())
			{
				step = Step.values()[step.ordinal() + 1];
				MC.method_1507(new ChooseNameScreen());
			}
		}
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		int black = 0x80000000;
		int gray = 0x26404040;
		int green1 = 0x2600FF00;
		int green2 = 0x4D00FF00;
		
		// area
		if(area != null)
		{
			// recently scanned blocks
			if(step == Step.SCAN_AREA && area.getProgress() < 1)
			{
				ArrayList<class_238> boxes = new ArrayList<>();
				for(int i = Math.max(0,
					area.getBlocksFound().size()
						- area.getScanSpeed()); i < area.getBlocksFound()
							.size(); i++)
					boxes.add(
						new class_238(area.getBlocksFound().get(i)).method_1014(0.005));
				
				RenderUtils.drawOutlinedBoxes(matrixStack, boxes, black, true);
				RenderUtils.drawSolidBoxes(matrixStack, boxes, green1, true);
			}
			
			// area box
			class_238 areaBox = area.toBox();
			RenderUtils.drawOutlinedBox(matrixStack, areaBox, black, true);
			
			// area scanner
			if(area.getProgress() < 1)
			{
				double scannerX = class_3532.method_16436(area.getProgress(),
					areaBox.field_1323, areaBox.field_1320);
				class_238 scanner = areaBox.method_35574(scannerX).method_35577(scannerX);
				
				RenderUtils.drawOutlinedBox(matrixStack, scanner, black, true);
				RenderUtils.drawSolidBox(matrixStack, scanner, green2, true);
				
				// template scanner
			}else if(template != null && template.getProgress() > 0)
			{
				double scannerX = class_3532.method_16436(template.getProgress(),
					areaBox.field_1323, areaBox.field_1320);
				class_238 scanner = areaBox.method_35574(scannerX).method_35577(scannerX);
				
				RenderUtils.drawOutlinedBox(matrixStack, scanner, black, true);
				RenderUtils.drawSolidBox(matrixStack, scanner, green2, true);
			}
		}
		
		// sorted blocks
		if(template != null)
		{
			List<class_238> boxes = template.getSortedBlocks().reversed().stream()
				.map(pos -> new class_238(pos).method_1011(1 / 16.0)).limit(1024)
				.toList();
			RenderUtils.drawOutlinedBoxes(matrixStack, boxes, black, false);
		}
		
		// area preview
		if(area == null && step == Step.END_POS && step.getPos() != null)
		{
			class_238 preview =
				class_238.method_54784(Step.START_POS.getPos(), Step.END_POS.getPos())
					.method_1011(1 / 16.0);
			RenderUtils.drawOutlinedBox(matrixStack, preview, black, true);
		}
		
		// selected positions
		ArrayList<class_238> selectedBoxes = new ArrayList<>();
		for(Step step : Step.SELECT_POSITION_STEPS)
			if(step.getPos() != null)
				selectedBoxes.add(new class_238(step.getPos()).method_1011(1 / 16.0));
		RenderUtils.drawOutlinedBoxes(matrixStack, selectedBoxes, black, false);
		RenderUtils.drawSolidBoxes(matrixStack, selectedBoxes, green1, false);
		
		// posLookingAt
		if(posLookingAt != null)
		{
			class_238 box = new class_238(posLookingAt).method_1011(1 / 16.0);
			RenderUtils.drawOutlinedBox(matrixStack, box, black, false);
			RenderUtils.drawSolidBox(matrixStack, box, gray, false);
		}
	}
	
	@Override
	public void onRenderGUI(class_332 context, float partialTicks)
	{
		String message;
		if(step.doesSelectPos() && step.getPos() != null)
			message = "Press enter to confirm, or select a different position.";
		else if(step == Step.FILE_NAME && file != null && file.exists())
			message = "WARNING: This file already exists.";
		else
			message = step.getMessage();
		
		class_327 tr = MC.field_1772;
		int msgWidth = tr.method_1727(message);
		
		int msgX1 = context.method_51421() / 2 - msgWidth / 2;
		int msgX2 = msgX1 + msgWidth + 2;
		int msgY1 = context.method_51443() / 2 + 1;
		int msgY2 = msgY1 + 10;
		
		// background
		context.method_25294(msgX1, msgY1, msgX2, msgY2, 0x80000000);
		
		// text
		context.method_51433(tr, message, msgX1 + 2, msgY1 + 1, 0xFFFFFFFF, false);
	}
	
	public void saveFile()
	{
		step = Step.values()[step.ordinal() + 1];
		JsonObject json = new JsonObject();
		
		// get facings
		class_2350 front = MC.field_1724.method_5735();
		class_2350 left = front.method_10160();
		
		// add sorted blocks
		JsonArray jsonBlocks = new JsonArray();
		for(class_2338 pos : template.getSortedBlocks())
		{
			// translate
			pos = pos.method_10059(Step.FIRST_BLOCK.getPos());
			
			// rotate
			pos = new class_2338(0, pos.method_10264(), 0).method_10079(front, pos.method_10260())
				.method_10079(left, pos.method_10263());
			
			// add to json
			jsonBlocks.add(JsonUtils.GSON.toJsonTree(
				new int[]{pos.method_10263(), pos.method_10264(), pos.method_10260()}, int[].class));
		}
		json.add("blocks", jsonBlocks);
		
		try(PrintWriter save = new PrintWriter(new FileWriter(file)))
		{
			// save file
			save.print(JsonUtils.PRETTY_GSON.toJson(json));
			
			// show success message
			class_5250 message = class_2561.method_43470("Saved template as ");
			class_2558 event = new class_2558(class_2558.class_2559.field_11746,
				file.getParentFile().getAbsolutePath());
			class_5250 link = class_2561.method_43470(file.getName())
				.method_27694(s -> s.method_30938(true).method_10958(event));
			message.method_10852(link);
			ChatUtils.component(message);
			
		}catch(IOException e)
		{
			e.printStackTrace();
			
			// show error message
			ChatUtils.error("File could not be saved.");
		}
		
		// disable TemplateTool
		setEnabled(false);
	}
	
	public void setFile(File file)
	{
		this.file = file;
	}
}
