/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;
import net.minecraft.class_1661;
import net.minecraft.class_1738;
import net.minecraft.class_1738.class_8051;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2378;
import net.minecraft.class_2813;
import net.minecraft.class_4059;
import net.minecraft.class_465;
import net.minecraft.class_490;
import net.minecraft.class_5455;
import net.minecraft.class_6880.class_6883;
import net.minecraft.class_746;
import net.minecraft.class_7924;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.WurstClient;
import net.wurstclient.events.PacketOutputListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;

@SearchTags({"auto armor"})
public final class AutoArmorHack extends Hack
	implements UpdateListener, PacketOutputListener
{
	private final CheckboxSetting useEnchantments = new CheckboxSetting(
		"Use enchantments",
		"Whether or not to consider the Protection enchantment when calculating armor strength.",
		true);
	
	private final CheckboxSetting swapWhileMoving = new CheckboxSetting(
		"Swap while moving",
		"Whether or not to swap armor pieces while the player is moving.\n\n"
			+ "\u00a7c\u00a7lWARNING:\u00a7r This would not be possible without cheats. It may raise suspicion.",
		false);
	
	private final SliderSetting delay = new SliderSetting("Delay",
		"Amount of ticks to wait before swapping the next piece of armor.", 2,
		0, 20, 1, ValueDisplay.INTEGER);
	
	private int timer;
	
	public AutoArmorHack()
	{
		super("AutoArmor");
		setCategory(Category.COMBAT);
		addSetting(useEnchantments);
		addSetting(swapWhileMoving);
		addSetting(delay);
	}
	
	@Override
	protected void onEnable()
	{
		timer = 0;
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(PacketOutputListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(PacketOutputListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		// wait for timer
		if(timer > 0)
		{
			timer--;
			return;
		}
		
		// check screen
		if(MC.field_1755 instanceof class_465
			&& !(MC.field_1755 instanceof class_490))
			return;
		
		class_746 player = MC.field_1724;
		class_1661 inventory = player.method_31548();
		
		if(!swapWhileMoving.isChecked() && (player.field_3913.field_3905 != 0
			|| player.field_3913.field_3907 != 0))
			return;
		
		// store slots and values of best armor pieces
		int[] bestArmorSlots = new int[4];
		int[] bestArmorValues = new int[4];
		
		// initialize with currently equipped armor
		for(int type = 0; type < 4; type++)
		{
			bestArmorSlots[type] = -1;
			
			class_1799 stack = inventory.method_7372(type);
			if(!(stack.method_7909() instanceof class_1738 item)
				|| item instanceof class_4059)
				continue;
			
			bestArmorValues[type] = getArmorValue(item, stack);
		}
		
		// search inventory for better armor
		for(int slot = 0; slot < 36; slot++)
		{
			class_1799 stack = inventory.method_5438(slot);
			
			if(!(stack.method_7909() instanceof class_1738 item)
				|| item instanceof class_4059)
				continue;
			
			int armorType = item.method_7685().method_5927();
			int armorValue = getArmorValue(item, stack);
			
			if(armorValue > bestArmorValues[armorType])
			{
				bestArmorSlots[armorType] = slot;
				bestArmorValues[armorType] = armorValue;
			}
		}
		
		// equip better armor in random order
		ArrayList<Integer> types = new ArrayList<>(Arrays.asList(0, 1, 2, 3));
		Collections.shuffle(types);
		for(int type : types)
		{
			// check if better armor was found
			int slot = bestArmorSlots[type];
			if(slot == -1)
				continue;
				
			// check if armor can be swapped
			// needs 1 free slot where it can put the old armor
			class_1799 oldArmor = inventory.method_7372(type);
			if(!oldArmor.method_7960() && inventory.method_7376() == -1)
				continue;
			
			// hotbar fix
			if(slot < 9)
				slot += 36;
			
			// swap armor
			if(!oldArmor.method_7960())
				IMC.getInteractionManager().windowClick_QUICK_MOVE(8 - type);
			IMC.getInteractionManager().windowClick_QUICK_MOVE(slot);
			
			break;
		}
	}
	
	@Override
	public void onSentPacket(PacketOutputEvent event)
	{
		if(event.getPacket() instanceof class_2813)
			timer = delay.getValueI();
	}
	
	private int getArmorValue(class_1738 item, class_1799 stack)
	{
		int armorPoints = item.method_7687();
		int prtPoints = 0;
		int armorToughness = (int)item.method_26353();
		int armorType = item.method_7686().comp_349().method_48403(class_8051.field_41936);
		
		if(useEnchantments.isChecked())
		{
			class_5455 drm =
				WurstClient.MC.field_1687.method_30349();
			class_2378<class_1887> registry = drm.method_30530(class_7924.field_41265);
			
			Optional<class_6883<class_1887>> protection =
				registry.method_40264(class_1893.field_9111);
			int prtLvl = protection
				.map(entry -> class_1890.method_8225(entry, stack))
				.orElse(0);
			
			// ClientPlayerEntity player = MC.player;
			// DamageSource dmgSource =
			// player.getDamageSources().playerAttack(player);
			// prtPoints = protection.getProtectionAmount(prtLvl, dmgSource);
			
			// Only the server can calculate protection amount as of
			// 24w18a (1.21). Related bug: MC-196250
			prtPoints = prtLvl;
		}
		
		return armorPoints * 5 + prtPoints * 3 + armorToughness + armorType;
	}
}
