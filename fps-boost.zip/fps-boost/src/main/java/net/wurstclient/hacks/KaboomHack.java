/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Collectors;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5819;
import net.wurstclient.Category;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.util.BlockBreaker;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.RotationUtils;

public final class KaboomHack extends Hack implements UpdateListener
{
	private final SliderSetting power =
		new SliderSetting("Power", "description.wurst.setting.kaboom.power",
			128, 32, 512, 32, ValueDisplay.INTEGER);
	
	private final CheckboxSetting sound = new CheckboxSetting("Sound",
		"description.wurst.setting.kaboom.sound", true);
	
	private final CheckboxSetting particles = new CheckboxSetting("Particles",
		"description.wurst.setting.kaboom.particles", true);
	
	private final class_5819 random = class_5819.method_43047();
	
	public KaboomHack()
	{
		super("Kaboom");
		setCategory(Category.BLOCKS);
		addSetting(power);
		addSetting(sound);
		addSetting(particles);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		// Abort if flying to prevent getting kicked
		if(!MC.field_1724.method_31549().field_7477 && !MC.field_1724.method_24828())
			return;
		
		double x = MC.field_1724.method_23317();
		double y = MC.field_1724.method_23318();
		double z = MC.field_1724.method_23321();
		
		// Do explosion effect
		if(sound.isChecked())
		{
			float soundPitch =
				(1F + (random.method_43057() - random.method_43057()) * 0.2F) * 0.7F;
			MC.field_1687.method_8486(x, y, z,
				class_3417.field_15152.comp_349(),
				class_3419.field_15245, 4, soundPitch, false);
		}
		if(particles.isChecked())
			MC.field_1687.method_8406(class_2398.field_11221, x, y, z, 1, 0,
				0);
		
		// Break all blocks
		ArrayList<class_2338> blocks = getBlocksByDistanceReversed();
		for(int i = 0; i < power.getValueI(); i++)
			BlockBreaker.breakBlocksWithPacketSpam(blocks);
		
		setEnabled(false);
	}
	
	private ArrayList<class_2338> getBlocksByDistanceReversed()
	{
		class_243 eyesVec = RotationUtils.getEyesPos();
		class_2338 eyesBlock = class_2338.method_49638(eyesVec);
		double rangeSq = 36;
		int blockRange = 6;
		
		// farthest blocks first
		return BlockUtils.getAllInBoxStream(eyesBlock, blockRange)
			.filter(pos -> pos.method_19770(eyesVec) <= rangeSq)
			.sorted(Comparator
				.comparingDouble(pos -> -pos.method_19770(eyesVec)))
			.collect(Collectors.toCollection(ArrayList::new));
	}
}
