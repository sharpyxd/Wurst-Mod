/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.mobspawnesp;

import java.util.function.Function;
import net.minecraft.class_1299;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.wurstclient.WurstClient;
import net.wurstclient.settings.EnumSetting;
import net.wurstclient.util.text.WText;

public final class HitboxCheckSetting
	extends EnumSetting<HitboxCheckSetting.HitboxCheck>
{
	private static final class_310 MC = WurstClient.MC;
	private static final WText DESCRIPTION =
		WText.translated("description.wurst.setting.mobspawnesp.hitbox_check")
			.append(buildDescriptionSuffix());
	
	public HitboxCheckSetting()
	{
		super("Hitbox check", DESCRIPTION, HitboxCheck.values(),
			HitboxCheck.OFF);
	}
	
	public boolean isSpaceEmpty(class_2338 pos)
	{
		return getSelected().check.apply(pos);
	}
	
	private static synchronized boolean slowHitboxCheck(class_2338 pos)
	{
		return unstableHitboxCheck(pos);
	}
	
	// "unstable" because isSpaceEmpty() is not thread-safe
	private static boolean unstableHitboxCheck(class_2338 pos)
	{
		return MC.field_1687.method_18026(class_1299.field_6046
			.method_58629(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5));
	}
	
	private static WText buildDescriptionSuffix()
	{
		WText text = WText.literal("\n\n");
		HitboxCheck[] values = HitboxCheck.values();
		
		for(HitboxCheck value : values)
			text.append("\u00a7l" + value.name + "\u00a7r - ")
				.append(value.description).append("\n\n");
		
		return text;
	}
	
	public enum HitboxCheck
	{
		OFF("Off", pos -> true),
		SLOW("Slow", HitboxCheckSetting::slowHitboxCheck),
		UNSTABLE("Unstable", HitboxCheckSetting::unstableHitboxCheck);
		
		private static final String TRANSLATION_KEY_PREFIX =
			"description.wurst.setting.mobspawnesp.hitbox_check.";
		
		private final String name;
		private final WText description;
		private final Function<class_2338, Boolean> check;
		
		private HitboxCheck(String name, Function<class_2338, Boolean> check)
		{
			this.name = name;
			description =
				WText.translated(TRANSLATION_KEY_PREFIX + name().toLowerCase());
			this.check = check;
		}
		
		@Override
		public String toString()
		{
			return name;
		}
	}
}
