/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1321;
import net.minecraft.class_1646;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2304;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;

@SearchTags({"auto soup", "AutoStew", "auto stew"})
public final class AutoSoupHack extends Hack implements UpdateListener
{
	private final SliderSetting health = new SliderSetting("Health",
		"Eats a soup when your health reaches this value or falls below it.",
		6.5, 0.5, 9.5, 0.5, ValueDisplay.DECIMAL);
	
	private int oldSlot = -1;
	
	public AutoSoupHack()
	{
		super("AutoSoup");
		
		setCategory(Category.COMBAT);
		addSetting(health);
	}
	
	@Override
	protected void onEnable()
	{
		WURST.getHax().autoEatHack.setEnabled(false);
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		stopIfEating();
	}
	
	@Override
	public void onUpdate()
	{
		// sort empty bowls
		for(int i = 0; i < 36; i++)
		{
			// filter out non-bowl items and empty bowl slot
			class_1799 stack = MC.field_1724.method_31548().method_5438(i);
			if(stack == null || stack.method_7909() != class_1802.field_8428 || i == 9)
				continue;
			
			// check if empty bowl slot contains a non-bowl item
			class_1799 emptyBowlStack = MC.field_1724.method_31548().method_5438(9);
			boolean swap = !emptyBowlStack.method_7960()
				&& emptyBowlStack.method_7909() != class_1802.field_8428;
			
			// place bowl in empty bowl slot
			IMC.getInteractionManager().windowClick_PICKUP(i < 9 ? 36 + i : i);
			IMC.getInteractionManager().windowClick_PICKUP(9);
			
			// place non-bowl item from empty bowl slot in current slot
			if(swap)
				IMC.getInteractionManager()
					.windowClick_PICKUP(i < 9 ? 36 + i : i);
		}
		
		// search soup in hotbar
		int soupInHotbar = findSoup(0, 9);
		
		// check if any soup was found
		if(soupInHotbar != -1)
		{
			// check if player should eat soup
			if(!shouldEatSoup())
			{
				stopIfEating();
				return;
			}
			
			// save old slot
			if(oldSlot == -1)
				oldSlot = MC.field_1724.method_31548().field_7545;
			
			// set slot
			MC.field_1724.method_31548().field_7545 = soupInHotbar;
			
			// eat soup
			MC.field_1690.field_1904.method_23481(true);
			IMC.getInteractionManager().rightClickItem();
			
			return;
		}
		
		stopIfEating();
		
		// search soup in inventory
		int soupInInventory = findSoup(9, 36);
		
		// move soup in inventory to hotbar
		if(soupInInventory != -1)
			IMC.getInteractionManager().windowClick_QUICK_MOVE(soupInInventory);
	}
	
	private int findSoup(int startSlot, int endSlot)
	{
		List<class_1792> stews = List.of(class_1802.field_8208, class_1802.field_8308,
			class_1802.field_8515);
		
		for(int i = startSlot; i < endSlot; i++)
		{
			class_1799 stack = MC.field_1724.method_31548().method_5438(i);
			
			if(stack != null && stews.contains(stack.method_7909()))
				return i;
		}
		
		return -1;
	}
	
	private boolean shouldEatSoup()
	{
		// check health
		if(MC.field_1724.method_6032() > health.getValueF() * 2F)
			return false;
		
		// check for clickable objects
		if(isClickable(MC.field_1765))
			return false;
		
		return true;
	}
	
	private boolean isClickable(class_239 hitResult)
	{
		if(hitResult == null)
			return false;
		
		if(hitResult instanceof class_3966)
		{
			class_1297 entity = ((class_3966)MC.field_1765).method_17782();
			return entity instanceof class_1646
				|| entity instanceof class_1321;
		}
		
		if(hitResult instanceof class_3965)
		{
			class_2338 pos = ((class_3965)MC.field_1765).method_17777();
			if(pos == null)
				return false;
			
			class_2248 block = MC.field_1687.method_8320(pos).method_26204();
			return block instanceof class_2237
				|| block instanceof class_2304;
		}
		
		return false;
	}
	
	private void stopIfEating()
	{
		// check if eating
		if(oldSlot == -1)
			return;
		
		// stop eating
		MC.field_1690.field_1904.method_23481(false);
		
		// reset slot
		MC.field_1724.method_31548().field_7545 = oldSlot;
		oldSlot = -1;
	}
}
