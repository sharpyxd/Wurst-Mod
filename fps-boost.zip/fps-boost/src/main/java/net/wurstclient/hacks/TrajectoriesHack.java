/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.awt.Color;
import java.util.ArrayList;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1306;
import net.minecraft.class_1675;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1811;
import net.minecraft.class_1823;
import net.minecraft.class_1835;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4537;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.minecraft.item.*;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.RenderListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.ColorSetting;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.EntityUtils;
import net.wurstclient.util.RenderUtils;
import net.wurstclient.util.RotationUtils;

@SearchTags({"ArrowTrajectories", "ArrowPrediction", "aim assist",
	"arrow trajectories", "bow trajectories"})
public final class TrajectoriesHack extends Hack implements RenderListener
{
	private final ColorSetting missColor = new ColorSetting("Miss Color",
		"Color of the trajectory when it doesn't hit anything.", Color.GRAY);
	
	private final ColorSetting entityHitColor =
		new ColorSetting("Entity Hit Color",
			"Color of the trajectory when it hits an entity.", Color.RED);
	
	private final ColorSetting blockHitColor =
		new ColorSetting("Block Hit Color",
			"Color of the trajectory when it hits a block.", Color.GREEN);
	
	public TrajectoriesHack()
	{
		super("Trajectories");
		setCategory(Category.RENDER);
		addSetting(missColor);
		addSetting(entityHitColor);
		addSetting(blockHitColor);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(RenderListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(RenderListener.class, this);
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		Trajectory trajectory = getTrajectory(partialTicks);
		if(trajectory.isEmpty())
			return;
		
		ColorSetting color = getColor(trajectory);
		int lineColor = color.getColorI(0xC0);
		int quadColor = color.getColorI(0x40);
		
		class_238 endBox = trajectory.getEndBox();
		ArrayList<class_243> path = trajectory.path();
		
		RenderUtils.drawSolidBox(matrixStack, endBox, quadColor, false);
		RenderUtils.drawOutlinedBox(matrixStack, endBox, lineColor, false);
		
		RenderUtils.drawCurvedLine(matrixStack, path, lineColor, false);
	}
	
	private Trajectory getTrajectory(float partialTicks)
	{
		class_746 player = MC.field_1724;
		ArrayList<class_243> path = new ArrayList<>();
		class_239.class_240 type = class_239.class_240.field_1333;
		
		// Find the hand with a throwable item
		class_1268 hand = class_1268.field_5808;
		class_1799 stack = player.method_6047();
		if(!isThrowable(stack))
		{
			hand = class_1268.field_5810;
			stack = player.method_6079();
			
			// If neither hand has a throwable item, return empty path
			if(!isThrowable(stack))
				return new Trajectory(path, type);
		}
		
		// Calculate item-specific values
		class_1792 item = stack.method_7909();
		double throwPower = getThrowPower(item);
		double gravity = getProjectileGravity(item);
		class_242 fluidHandling = getFluidHandling(item);
		
		// Prepare yaw and pitch
		double yaw = Math.toRadians(player.method_36454());
		double pitch = Math.toRadians(player.method_36455());
		
		// Calculate starting position
		class_243 arrowPos = EntityUtils.getLerpedPos(player, partialTicks)
			.method_1019(getHandOffset(hand, yaw));
		
		// Calculate starting motion
		class_243 arrowMotion = getStartingMotion(yaw, pitch, throwPower);
		
		// Build the path
		for(int i = 0; i < 1000; i++)
		{
			// Add to path
			path.add(arrowPos);
			
			// Apply motion
			arrowPos = arrowPos.method_1019(arrowMotion.method_1021(0.1));
			
			// Apply air friction
			arrowMotion = arrowMotion.method_1021(0.999);
			
			// Apply gravity
			arrowMotion = arrowMotion.method_1031(0, -gravity * 0.1, 0);
			
			class_243 lastPos = path.size() > 1 ? path.get(path.size() - 2)
				: RotationUtils.getEyesPos();
			
			// Check for block collision
			class_3965 bResult =
				BlockUtils.raycast(lastPos, arrowPos, fluidHandling);
			if(bResult.method_17783() != class_239.class_240.field_1333)
			{
				// Replace last pos with the collision point
				type = class_239.class_240.field_1332;
				path.set(path.size() - 1, bResult.method_17784());
				break;
			}
			
			// Check for entity collision
			class_238 box = new class_238(lastPos, arrowPos);
			Predicate<class_1297> predicate = e -> !e.method_7325() && e.method_5863();
			double maxDistSq = 64 * 64;
			class_3966 eResult = class_1675.method_18075(player, lastPos,
				arrowPos, box, predicate, maxDistSq);
			if(eResult != null && eResult.method_17783() != class_239.class_240.field_1333)
			{
				// Replace last pos with the collision point
				type = class_239.class_240.field_1331;
				path.set(path.size() - 1, eResult.method_17784());
				break;
			}
		}
		
		return new Trajectory(path, type);
	}
	
	private boolean isThrowable(class_1799 stack)
	{
		if(stack.method_7960())
			return false;
		
		class_1792 item = stack.method_7909();
		return item instanceof class_1811 || item instanceof class_1823
			|| item instanceof class_1771 || item instanceof class_1776
			|| item instanceof class_4537
			|| item instanceof class_1787 || item instanceof class_1835;
	}
	
	private double getThrowPower(class_1792 item)
	{
		// Use a static 1.5x for snowballs and such
		if(!(item instanceof class_1811))
			return 1.5;
		
		// Calculate bow power
		float bowPower = (72000 - MC.field_1724.method_6014()) / 20F;
		bowPower = bowPower * bowPower + bowPower * 2F;
		
		// Clamp value if fully charged or not charged at all
		if(bowPower > 3 || bowPower <= 0.3F)
			bowPower = 3;
		
		return bowPower;
	}
	
	private double getProjectileGravity(class_1792 item)
	{
		if(item instanceof class_1811)
			return 0.05;
		
		if(item instanceof class_4537)
			return 0.4;
		
		if(item instanceof class_1787)
			return 0.15;
		
		if(item instanceof class_1835)
			return 0.015;
		
		return 0.03;
	}
	
	private class_242 getFluidHandling(class_1792 item)
	{
		if(item instanceof class_1787)
			return class_242.field_1347;
		
		return class_242.field_1348;
	}
	
	private class_243 getHandOffset(class_1268 hand, double yaw)
	{
		class_1306 mainArm = MC.field_1690.method_42552().method_41753();
		
		boolean rightSide = mainArm == class_1306.field_6183 && hand == class_1268.field_5808
			|| mainArm == class_1306.field_6182 && hand == class_1268.field_5810;
		
		double sideMultiplier = rightSide ? -1 : 1;
		double handOffsetX = Math.cos(yaw) * 0.16 * sideMultiplier;
		double handOffsetY = MC.field_1724.method_5751() - 0.1;
		double handOffsetZ = Math.sin(yaw) * 0.16 * sideMultiplier;
		
		return new class_243(handOffsetX, handOffsetY, handOffsetZ);
	}
	
	private class_243 getStartingMotion(double yaw, double pitch, double throwPower)
	{
		double cosOfPitch = Math.cos(pitch);
		
		double arrowMotionX = -Math.sin(yaw) * cosOfPitch;
		double arrowMotionY = -Math.sin(pitch);
		double arrowMotionZ = Math.cos(yaw) * cosOfPitch;
		
		return new class_243(arrowMotionX, arrowMotionY, arrowMotionZ).method_1029()
			.method_1021(throwPower);
	}
	
	private ColorSetting getColor(Trajectory trajectory)
	{
		return switch(trajectory.type())
		{
			case field_1333 -> missColor;
			case field_1331 -> entityHitColor;
			case field_1332 -> blockHitColor;
		};
	}
	
	private record Trajectory(ArrayList<class_243> path, class_239.class_240 type)
	{
		public boolean isEmpty()
		{
			return path.isEmpty();
		}
		
		public class_238 getEndBox()
		{
			class_243 end = path.get(path.size() - 1);
			return new class_238(end.method_1023(0.5, 0.5, 0.5), end.method_1031(0.5, 0.5, 0.5));
		}
	}
}
