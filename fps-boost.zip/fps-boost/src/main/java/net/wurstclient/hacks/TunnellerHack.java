/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.stream.StreamSupport;
import net.minecraft.class_1268;
import net.minecraft.class_1540;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2527;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2682;
import net.minecraft.class_290;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_304;
import net.minecraft.class_315;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.wurstclient.Category;
import net.wurstclient.WurstRenderLayers;
import net.wurstclient.events.RenderListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.DontSaveState;
import net.wurstclient.hack.Hack;
import net.wurstclient.hack.HackList;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.EnumSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.settings.SwingHandSetting.SwingHand;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.EasyVertexBuffer;
import net.wurstclient.util.OverlayRenderer;
import net.wurstclient.util.RegionPos;
import net.wurstclient.util.RenderUtils;
import net.wurstclient.util.RotationUtils;

@DontSaveState
public final class TunnellerHack extends Hack
	implements UpdateListener, RenderListener
{
	private final EnumSetting<TunnelSize> size = new EnumSetting<>(
		"Tunnel size", TunnelSize.values(), TunnelSize.SIZE_3X3);
	
	private final SliderSetting limit = new SliderSetting("Limit",
		"Automatically stops once the tunnel has reached the given length.\n\n"
			+ "0 = no limit",
		0, 0, 1000, 1, ValueDisplay.INTEGER.withSuffix(" blocks")
			.withLabel(1, "1 block").withLabel(0, "disabled"));
	
	private final CheckboxSetting torches = new CheckboxSetting("Place torches",
		"Places just enough torches to prevent mobs from spawning inside the tunnel.",
		false);
	
	private final OverlayRenderer overlay = new OverlayRenderer();
	
	private class_2338 start;
	private class_2350 direction;
	private int length;
	
	private Task[] tasks;
	private EasyVertexBuffer[] vertexBuffers = new EasyVertexBuffer[5];
	
	private class_2338 currentBlock;
	private class_2338 lastTorch;
	private class_2338 nextTorch;
	
	public TunnellerHack()
	{
		super("Tunneller");
		setCategory(Category.BLOCKS);
		addSetting(size);
		addSetting(limit);
		addSetting(torches);
	}
	
	@Override
	public String getRenderName()
	{
		if(limit.getValueI() == 0)
			return getName();
		return getName() + " [" + length + "/" + limit.getValueI() + "]";
	}
	
	@Override
	protected void onEnable()
	{
		WURST.getHax().autoMineHack.setEnabled(false);
		WURST.getHax().excavatorHack.setEnabled(false);
		WURST.getHax().fightBotHack.setEnabled(false);
		WURST.getHax().followHack.setEnabled(false);
		WURST.getHax().instantBunkerHack.setEnabled(false);
		WURST.getHax().nukerHack.setEnabled(false);
		WURST.getHax().nukerLegitHack.setEnabled(false);
		WURST.getHax().protectHack.setEnabled(false);
		WURST.getHax().speedNukerHack.setEnabled(false);
		WURST.getHax().veinMinerHack.setEnabled(false);
		
		// add listeners
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(RenderListener.class, this);
		
		class_746 player = MC.field_1724;
		start = class_2338.method_49638(player.method_19538());
		direction = player.method_5735();
		length = 0;
		lastTorch = null;
		nextTorch = start;
		
		tasks = new Task[]{new DodgeLiquidTask(), new FillInFloorTask(),
			new PlaceTorchTask(), new WaitForFallingBlocksTask(),
			new DigTunnelTask(), new WalkForwardTask()};
		
		updateCyanBuffer();
	}
	
	@Override
	protected void onDisable()
	{
		// remove listeners
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		
		overlay.resetProgress();
		if(currentBlock != null)
		{
			MC.field_1761.field_3717 = true;
			MC.field_1761.method_2925();
			currentBlock = null;
		}
		
		for(int i = 0; i < vertexBuffers.length; i++)
		{
			if(vertexBuffers[i] == null)
				continue;
			
			vertexBuffers[i].close();
			vertexBuffers[i] = null;
		}
	}
	
	@Override
	public void onUpdate()
	{
		HackList hax = WURST.getHax();
		Hack[] incompatibleHax = {hax.autoSwitchHack, hax.autoToolHack,
			hax.autoWalkHack, hax.blinkHack, hax.flightHack,
			hax.scaffoldWalkHack, hax.sneakHack};
		for(Hack hack : incompatibleHax)
			hack.setEnabled(false);
		
		if(hax.freecamHack.isEnabled() || hax.remoteViewHack.isEnabled())
			return;
		
		class_315 gs = MC.field_1690;
		class_304[] bindings = {gs.field_1894, gs.field_1881, gs.field_1913,
			gs.field_1849, gs.field_1903, gs.field_1832};
		for(class_304 binding : bindings)
			binding.method_23481(false);
		
		for(Task task : tasks)
		{
			if(!task.canRun())
				continue;
			
			task.run();
			break;
		}
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		matrixStack.method_22903();
		RenderUtils.applyRegionalRenderOffset(matrixStack);
		
		for(EasyVertexBuffer buffer : vertexBuffers)
		{
			if(buffer == null)
				continue;
			
			buffer.draw(matrixStack, WurstRenderLayers.ESP_LINES);
		}
		
		matrixStack.method_22909();
		
		overlay.render(matrixStack, partialTicks, currentBlock);
	}
	
	private void updateCyanBuffer()
	{
		if(vertexBuffers[0] != null)
			vertexBuffers[0].close();
		
		RegionPos region = RenderUtils.getCameraRegion();
		class_243 offset = class_243.method_24953(start).method_1020(region.toVec3d());
		int cyan = 0x8000FFFF;
		
		class_238 nodeBox =
			new class_238(-0.25, -0.25, -0.25, 0.25, 0.25, 0.25).method_997(offset);
		class_243 dirVec = class_243.method_24954(direction.method_10163());
		class_243 arrowStart = dirVec.method_1021(0.25).method_1019(offset);
		class_243 arrowEnd = dirVec.method_1021(Math.max(0.5, length)).method_1019(offset);
		
		vertexBuffers[0] = EasyVertexBuffer.createAndUpload(class_5596.field_27377,
			class_290.field_29337, buffer -> {
				RenderUtils.drawNode(buffer, nodeBox, cyan);
				RenderUtils.drawArrow(buffer, arrowStart, arrowEnd, cyan, 0.1F);
			});
	}
	
	private class_2338 offset(class_2338 pos, class_2382 vec)
	{
		return pos.method_10079(direction.method_10160(), vec.method_10263())
			.method_10086(vec.method_10264());
	}
	
	private int getDistance(class_2338 pos1, class_2338 pos2)
	{
		return Math.abs(pos1.method_10263() - pos2.method_10263())
			+ Math.abs(pos1.method_10264() - pos2.method_10264())
			+ Math.abs(pos1.method_10260() - pos2.method_10260());
	}
	
	/**
	 * Returns all block positions in the given box, in the order that Tunneller
	 * should mine them (left to right, top to bottom, front to back).
	 */
	public ArrayList<class_2338> getAllInBox(class_2338 from, class_2338 to)
	{
		ArrayList<class_2338> blocks = new ArrayList<>();
		
		class_2350 front = direction;
		class_2350 left = front.method_10160();
		
		int fromFront =
			from.method_10263() * front.method_10148() + from.method_10260() * front.method_10165();
		int toFront =
			to.method_10263() * front.method_10148() + to.method_10260() * front.method_10165();
		int fromLeft =
			from.method_10263() * left.method_10148() + from.method_10260() * left.method_10165();
		int toLeft =
			to.method_10263() * left.method_10148() + to.method_10260() * left.method_10165();
		
		int minFront = Math.min(fromFront, toFront);
		int maxFront = Math.max(fromFront, toFront);
		int minY = Math.min(from.method_10264(), to.method_10264());
		int maxY = Math.max(from.method_10264(), to.method_10264());
		int minLeft = Math.min(fromLeft, toLeft);
		int maxLeft = Math.max(fromLeft, toLeft);
		
		for(int f = minFront; f <= maxFront; f++)
			for(int y = maxY; y >= minY; y--)
				for(int l = maxLeft; l >= minLeft; l--)
				{
					int x = f * front.method_10148() + l * left.method_10148();
					int z = f * front.method_10165() + l * left.method_10165();
					blocks.add(new class_2338(x, y, z));
				}
			
		return blocks;
	}
	
	private static abstract class Task
	{
		public abstract boolean canRun();
		
		public abstract void run();
	}
	
	private class DigTunnelTask extends Task
	{
		private int maxDistance;
		
		@Override
		public boolean canRun()
		{
			class_2338 player = class_2338.method_49638(MC.field_1724.method_19538());
			class_2338 base = start.method_10079(direction, length);
			int distance = getDistance(player, base);
			
			if(distance <= 1)
				maxDistance = size.getSelected().maxRange;
			else if(distance > size.getSelected().maxRange)
				maxDistance = 1;
			
			return distance <= maxDistance;
		}
		
		@Override
		public void run()
		{
			class_2338 player = class_2338.method_49638(MC.field_1724.method_19538());
			class_2338 base = start.method_10079(direction, length);
			class_2338 from = offset(player, size.getSelected().from);
			class_2338 to = offset(base, size.getSelected().to);
			
			ArrayList<class_2338> blocks = new ArrayList<>();
			getAllInBox(from, to).forEach(blocks::add);
			
			RegionPos region = RenderUtils.getCameraRegion();
			class_238 blockBox = new class_238(class_2338.field_10980).method_1011(0.1)
				.method_997(region.negate().toVec3d());
			
			currentBlock = null;
			ArrayList<class_238> boxes = new ArrayList<>();
			for(class_2338 pos : blocks)
			{
				if(!BlockUtils.canBeClicked(pos))
					continue;
				
				if((pos.equals(nextTorch) || pos.equals(lastTorch))
					&& BlockUtils.getBlock(pos) instanceof class_2527)
					continue;
				
				if(currentBlock == null)
					currentBlock = pos;
				
				boxes.add(blockBox.method_996(pos));
			}
			
			if(vertexBuffers[1] != null)
			{
				vertexBuffers[1].close();
				vertexBuffers[1] = null;
			}
			
			int green = 0x8000FF00;
			if(!boxes.isEmpty())
				vertexBuffers[1] = EasyVertexBuffer.createAndUpload(
					class_5596.field_27377, class_290.field_29337, buffer -> {
						for(class_238 box : boxes)
							RenderUtils.drawOutlinedBox(buffer, box, green);
					});
			
			if(currentBlock == null)
			{
				MC.field_1761.method_2925();
				overlay.resetProgress();
				
				length++;
				if(limit.getValueI() == 0 || length < limit.getValueI())
					updateCyanBuffer();
				else
				{
					ChatUtils.message("Tunnel completed.");
					setEnabled(false);
				}
				
				return;
			}
			
			WURST.getHax().autoToolHack.equipBestTool(currentBlock, false, true,
				0);
			breakBlock(currentBlock);
			
			if(MC.field_1724.method_31549().field_7477
				|| BlockUtils.getHardness(currentBlock) >= 1)
			{
				overlay.resetProgress();
				return;
			}
			
			overlay.updateProgress();
		}
	}
	
	private class WalkForwardTask extends Task
	{
		@Override
		public boolean canRun()
		{
			class_2338 player = class_2338.method_49638(MC.field_1724.method_19538());
			class_2338 base = start.method_10079(direction, length);
			
			return getDistance(player, base) > 1;
		}
		
		@Override
		public void run()
		{
			class_2338 base = start.method_10079(direction, length);
			class_243 vec = class_243.method_24953(base);
			WURST.getRotationFaker().faceVectorClientIgnorePitch(vec);
			
			MC.field_1690.field_1894.method_23481(true);
		}
	}
	
	private class FillInFloorTask extends Task
	{
		private final ArrayList<class_2338> blocks = new ArrayList<>();
		
		@Override
		public boolean canRun()
		{
			class_2338 player = class_2338.method_49638(MC.field_1724.method_19538());
			class_2338 from = offsetFloor(player, size.getSelected().from);
			class_2338 to = offsetFloor(player, size.getSelected().to);
			
			blocks.clear();
			for(class_2338 pos : BlockUtils.getAllInBox(from, to))
				if(!BlockUtils.getState(pos).method_26234(MC.field_1687, pos))
					blocks.add(pos);
				
			if(vertexBuffers[2] != null)
			{
				vertexBuffers[2].close();
				vertexBuffers[2] = null;
			}
			
			if(!blocks.isEmpty())
			{
				RegionPos region = RenderUtils.getCameraRegion();
				class_238 box = new class_238(class_2338.field_10980).method_1011(0.1)
					.method_997(region.negate().toVec3d());
				
				int yellow = 0x80FFFF00;
				vertexBuffers[2] = EasyVertexBuffer.createAndUpload(
					class_5596.field_27377, class_290.field_29337, buffer -> {
						for(class_2338 pos : blocks)
							RenderUtils.drawOutlinedBox(buffer, box.method_996(pos),
								yellow);
					});
				
				return true;
			}
			
			return false;
		}
		
		private class_2338 offsetFloor(class_2338 pos, class_2382 vec)
		{
			return pos.method_10079(direction.method_10160(), vec.method_10263())
				.method_10074();
		}
		
		@Override
		public void run()
		{
			MC.field_1690.field_1832.method_23481(true);
			class_243 velocity = MC.field_1724.method_18798();
			MC.field_1724.method_18800(0, velocity.field_1351, 0);
			
			class_243 eyes = RotationUtils.getEyesPos().method_1031(-0.5, -0.5, -0.5);
			Comparator<class_2338> comparator =
				Comparator.<class_2338> comparingDouble(
					p -> eyes.method_1025(class_243.method_24954(p)));
			
			class_2338 pos = blocks.stream().max(comparator).get();
			
			if(!equipSolidBlock(pos))
			{
				ChatUtils.error(
					"Found a hole in the tunnel's floor but don't have any blocks to fill it with.");
				setEnabled(false);
				return;
			}
			
			if(BlockUtils.getState(pos).method_45474())
				placeBlockSimple(pos);
			else
			{
				WURST.getHax().autoToolHack.equipBestTool(pos, false, true, 0);
				breakBlock(pos);
			}
		}
		
		private boolean equipSolidBlock(class_2338 pos)
		{
			for(int slot = 0; slot < 9; slot++)
			{
				// filter out non-block items
				class_1799 stack = MC.field_1724.method_31548().method_5438(slot);
				if(stack.method_7960() || !(stack.method_7909() instanceof class_1747))
					continue;
				
				class_2248 block = class_2248.method_9503(stack.method_7909());
				
				// filter out non-solid blocks
				class_2680 state = block.method_9564();
				if(!state.method_26234(class_2682.field_12294, class_2338.field_10980))
					continue;
				
				// filter out blocks that would fall
				if(block instanceof class_2346 && class_2346
					.method_10128(BlockUtils.getState(pos.method_10074())))
					continue;
				
				MC.field_1724.method_31548().field_7545 = slot;
				return true;
			}
			
			return false;
		}
	}
	
	private class DodgeLiquidTask extends Task
	{
		private final HashSet<class_2338> liquids = new HashSet<>();
		private int disableTimer = 60;
		
		@Override
		public boolean canRun()
		{
			if(!liquids.isEmpty())
				return true;
			
			class_2338 base = start.method_10079(direction, length);
			class_2338 from = offset(base, size.getSelected().from);
			class_2338 to = offset(base, size.getSelected().to);
			int maxY = Math.max(from.method_10264(), to.method_10264());
			
			for(class_2338 pos : BlockUtils.getAllInBox(from, to))
			{
				// check current & previous blocks
				int maxOffset = Math.min(size.getSelected().maxRange, length);
				for(int i = 0; i <= maxOffset; i++)
				{
					class_2338 pos2 = pos.method_10079(direction.method_10153(), i);
					
					if(!BlockUtils.getState(pos2).method_26227().method_15769())
						liquids.add(pos2);
				}
				
				if(BlockUtils.getState(pos).method_26234(MC.field_1687, pos))
					continue;
				
				// check next blocks
				class_2338 pos3 = pos.method_10093(direction);
				if(!BlockUtils.getState(pos3).method_26227().method_15769())
					liquids.add(pos3);
				
				// check ceiling blocks
				if(pos.method_10264() == maxY)
				{
					class_2338 pos4 = pos.method_10084();
					
					if(!BlockUtils.getState(pos4).method_26227().method_15769())
						liquids.add(pos4);
				}
			}
			
			if(liquids.isEmpty())
				return false;
			
			ChatUtils.error("The tunnel is flooded, cannot continue.");
			
			if(vertexBuffers[3] != null)
			{
				vertexBuffers[3].close();
				vertexBuffers[3] = null;
			}
			
			if(!liquids.isEmpty())
			{
				RegionPos region = RenderUtils.getCameraRegion();
				class_238 box = new class_238(class_2338.field_10980).method_1011(0.1)
					.method_997(region.negate().toVec3d());
				
				int red = 0x80FF0000;
				vertexBuffers[3] = EasyVertexBuffer.createAndUpload(
					class_5596.field_27377, class_290.field_29337, buffer -> {
						for(class_2338 pos : liquids)
							RenderUtils.drawOutlinedBox(buffer, box.method_996(pos),
								red);
					});
			}
			
			return true;
		}
		
		@Override
		public void run()
		{
			class_2338 player = class_2338.method_49638(MC.field_1724.method_19538());
			class_304 forward = MC.field_1690.field_1894;
			
			class_243 diffVec = class_243.method_24954(player.method_10059(start));
			class_243 dirVec = class_243.method_24954(direction.method_10163());
			double dotProduct = diffVec.method_1026(dirVec);
			
			class_2338 pos1 = start.method_10079(direction, (int)dotProduct);
			if(!player.equals(pos1))
			{
				WURST.getRotationFaker()
					.faceVectorClientIgnorePitch(toVec3d(pos1));
				forward.method_23481(true);
				return;
			}
			
			class_2338 pos2 = start.method_10079(direction, Math.max(0, length - 10));
			if(!player.equals(pos2))
			{
				WURST.getRotationFaker()
					.faceVectorClientIgnorePitch(toVec3d(pos2));
				forward.method_23481(true);
				MC.field_1724.method_5728(true);
				return;
			}
			
			class_2338 pos3 = start.method_10079(direction, length + 1);
			WURST.getRotationFaker().faceVectorClientIgnorePitch(toVec3d(pos3));
			forward.method_23481(false);
			MC.field_1724.method_5728(false);
			
			if(disableTimer > 0)
			{
				disableTimer--;
				return;
			}
			
			setEnabled(false);
		}
		
		private class_243 toVec3d(class_2338 pos)
		{
			return class_243.method_24953(pos);
		}
	}
	
	private class PlaceTorchTask extends Task
	{
		@Override
		public boolean canRun()
		{
			if(vertexBuffers[4] != null)
			{
				vertexBuffers[4].close();
				vertexBuffers[4] = null;
			}
			
			if(!torches.isChecked())
			{
				lastTorch = null;
				nextTorch = class_2338.method_49638(MC.field_1724.method_19538());
				return false;
			}
			
			if(BlockUtils.getBlock(nextTorch) instanceof class_2527)
				lastTorch = nextTorch;
			
			if(lastTorch != null)
				nextTorch = lastTorch.method_10079(direction,
					size.getSelected().torchDistance);
			
			RegionPos region = RenderUtils.getCameraRegion();
			class_243 torchVec =
				class_243.method_24955(nextTorch).method_1020(region.toVec3d());
			
			int yellow = 0x80FFFF00;
			vertexBuffers[4] = EasyVertexBuffer.createAndUpload(class_5596.field_27377,
				class_290.field_29337, buffer -> {
					RenderUtils.drawArrow(buffer, torchVec,
						torchVec.method_1031(0, 0.5, 0), yellow, 0.1F);
				});
			
			class_2338 player = class_2338.method_49638(MC.field_1724.method_19538());
			if(getDistance(player, nextTorch) > 4)
				return false;
			
			class_2680 state = BlockUtils.getState(nextTorch);
			if(!state.method_45474())
				return false;
			
			return class_2246.field_10336.method_9564().method_26184(MC.field_1687,
				nextTorch);
		}
		
		@Override
		public void run()
		{
			if(!equipTorch())
			{
				ChatUtils.error("Out of torches.");
				setEnabled(false);
				return;
			}
			
			MC.field_1690.field_1832.method_23481(true);
			placeBlockSimple(nextTorch);
		}
		
		private boolean equipTorch()
		{
			for(int slot = 0; slot < 9; slot++)
			{
				// filter out non-block items
				class_1799 stack = MC.field_1724.method_31548().method_5438(slot);
				if(stack.method_7960() || !(stack.method_7909() instanceof class_1747))
					continue;
				
				// filter out non-torch blocks
				class_2248 block = class_2248.method_9503(stack.method_7909());
				if(!(block instanceof class_2527))
					continue;
				
				MC.field_1724.method_31548().field_7545 = slot;
				return true;
			}
			
			return false;
		}
	}
	
	private static class WaitForFallingBlocksTask extends Task
	{
		@Override
		public boolean canRun()
		{
			// check for nearby falling blocks
			return StreamSupport
				.stream(MC.field_1687.method_18112().spliterator(), false)
				.filter(class_1540.class::isInstance)
				.anyMatch(e -> MC.field_1724.method_5858(e) < 36);
		}
		
		@Override
		public void run()
		{
			// just wait for them to land
		}
	}
	
	private void placeBlockSimple(class_2338 pos)
	{
		class_2350 side = null;
		class_2350[] sides = class_2350.values();
		
		class_243 eyesPos = RotationUtils.getEyesPos();
		class_243 posVec = class_243.method_24953(pos);
		double distanceSqPosVec = eyesPos.method_1025(posVec);
		
		class_243[] hitVecs = new class_243[sides.length];
		for(int i = 0; i < sides.length; i++)
			hitVecs[i] =
				posVec.method_1019(class_243.method_24954(sides[i].method_10163()).method_1021(0.5));
		
		for(int i = 0; i < sides.length; i++)
		{
			// check if neighbor can be right clicked
			class_2338 neighbor = pos.method_10093(sides[i]);
			if(!BlockUtils.canBeClicked(neighbor))
				continue;
			
			// check line of sight
			class_2680 neighborState = BlockUtils.getState(neighbor);
			class_265 neighborShape =
				neighborState.method_26218(MC.field_1687, neighbor);
			if(MC.field_1687.method_17745(eyesPos, hitVecs[i], neighbor,
				neighborShape, neighborState) != null)
				continue;
			
			side = sides[i];
			break;
		}
		
		if(side == null)
			for(int i = 0; i < sides.length; i++)
			{
				// check if neighbor can be right clicked
				if(!BlockUtils.canBeClicked(pos.method_10093(sides[i])))
					continue;
				
				// check if side is facing away from player
				if(distanceSqPosVec > eyesPos.method_1025(hitVecs[i]))
					continue;
				
				side = sides[i];
				break;
			}
		
		if(side == null)
			return;
		
		class_243 hitVec = hitVecs[side.ordinal()];
		
		// face block
		WURST.getRotationFaker().faceVectorPacket(hitVec);
		if(RotationUtils.getAngleToLastReportedLookVec(hitVec) > 1)
			return;
		
		// check timer
		if(MC.field_1752 > 0)
			return;
		
		// place block
		IMC.getInteractionManager().rightClickBlock(pos.method_10093(side),
			side.method_10153(), hitVec);
		
		// swing arm
		SwingHand.SERVER.swing(class_1268.field_5808);
		
		// reset timer
		MC.field_1752 = 4;
	}
	
	private boolean breakBlock(class_2338 pos)
	{
		class_2350[] sides = class_2350.values();
		
		class_243 eyesPos = RotationUtils.getEyesPos();
		class_243 relCenter = BlockUtils.getBoundingBox(pos)
			.method_989(-pos.method_10263(), -pos.method_10264(), -pos.method_10260()).method_1005();
		class_243 center = class_243.method_24954(pos).method_1019(relCenter);
		
		class_243[] hitVecs = new class_243[sides.length];
		for(int i = 0; i < sides.length; i++)
		{
			class_2382 dirVec = sides[i].method_10163();
			class_243 relHitVec = new class_243(relCenter.field_1352 * dirVec.method_10263(),
				relCenter.field_1351 * dirVec.method_10264(), relCenter.field_1350 * dirVec.method_10260());
			hitVecs[i] = center.method_1019(relHitVec);
		}
		
		double[] distancesSq = new double[sides.length];
		boolean[] linesOfSight = new boolean[sides.length];
		
		double distanceSqToCenter = eyesPos.method_1025(center);
		for(int i = 0; i < sides.length; i++)
		{
			distancesSq[i] = eyesPos.method_1025(hitVecs[i]);
			
			// no need to raytrace the rear sides,
			// they can't possibly have line of sight
			if(distancesSq[i] >= distanceSqToCenter)
				continue;
			
			linesOfSight[i] = BlockUtils.hasLineOfSight(eyesPos, hitVecs[i]);
		}
		
		class_2350 side = sides[0];
		for(int i = 1; i < sides.length; i++)
		{
			int bestSide = side.ordinal();
			
			// prefer sides with LOS
			if(!linesOfSight[bestSide] && linesOfSight[i])
			{
				side = sides[i];
				continue;
			}
			
			// then pick the closest side
			if(distancesSq[i] < distancesSq[bestSide])
				side = sides[i];
		}
		
		// face block
		WURST.getRotationFaker().faceVectorPacket(hitVecs[side.ordinal()]);
		
		// damage block
		if(!MC.field_1761.method_2902(pos, side))
			return false;
		
		// swing arm
		SwingHand.SERVER.swing(class_1268.field_5808);
		
		return true;
	}
	
	private enum TunnelSize
	{
		SIZE_1X2("1x2", new class_2382(0, 1, 0), new class_2382(0, 0, 0), 4, 13),
		SIZE_1X3("1x3", new class_2382(0, 2, 0), new class_2382(0, 0, 0), 4, 13),
		SIZE_1X4("1x4", new class_2382(0, 3, 0), new class_2382(0, 0, 0), 4, 13),
		SIZE_1X5("1x5", new class_2382(0, 4, 0), new class_2382(0, 0, 0), 3, 13),
		
		SIZE_2X2("2x2", new class_2382(1, 1, 0), new class_2382(0, 0, 0), 4, 11),
		SIZE_2X3("2x3", new class_2382(1, 2, 0), new class_2382(0, 0, 0), 4, 11),
		SIZE_2X4("2x4", new class_2382(1, 3, 0), new class_2382(0, 0, 0), 4, 11),
		SIZE_2X5("2x5", new class_2382(1, 4, 0), new class_2382(0, 0, 0), 3, 11),
		
		SIZE_3X2("3x2", new class_2382(1, 1, 0), new class_2382(-1, 0, 0), 4, 11),
		SIZE_3X3("3x3", new class_2382(1, 2, 0), new class_2382(-1, 0, 0), 4, 11),
		SIZE_3X4("3x4", new class_2382(1, 3, 0), new class_2382(-1, 0, 0), 4, 11),
		SIZE_3X5("3x5", new class_2382(1, 4, 0), new class_2382(-1, 0, 0), 3, 11),
		
		SIZE_4X2("4x2", new class_2382(2, 1, 0), new class_2382(-1, 0, 0), 4, 9),
		SIZE_4X3("4x3", new class_2382(2, 2, 0), new class_2382(-1, 0, 0), 4, 9),
		SIZE_4X4("4x4", new class_2382(2, 3, 0), new class_2382(-1, 0, 0), 4, 9),
		SIZE_4X5("4x5", new class_2382(2, 4, 0), new class_2382(-1, 0, 0), 3, 9),
		
		SIZE_5X2("5x2", new class_2382(2, 1, 0), new class_2382(-2, 0, 0), 4, 9),
		SIZE_5X3("5x3", new class_2382(2, 2, 0), new class_2382(-2, 0, 0), 4, 9),
		SIZE_5X4("5x4", new class_2382(2, 3, 0), new class_2382(-2, 0, 0), 4, 9),
		SIZE_5X5("5x5", new class_2382(2, 4, 0), new class_2382(-2, 0, 0), 3, 9);
		
		private final String name;
		private final class_2382 from;
		private final class_2382 to;
		private final int maxRange;
		private final int torchDistance;
		
		private TunnelSize(String name, class_2382 from, class_2382 to, int maxRange,
			int torchDistance)
		{
			this.name = name;
			this.from = from;
			this.to = to;
			this.maxRange = maxRange;
			this.torchDistance = torchDistance;
		}
		
		@Override
		public String toString()
		{
			return name;
		}
	}
}
