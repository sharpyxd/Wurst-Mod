/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_746;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.EnumSetting;
import net.wurstclient.settings.FacingSetting;
import net.wurstclient.settings.FacingSetting.Facing;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.settings.SwingHandSetting;
import net.wurstclient.settings.SwingHandSetting.SwingHand;
import net.wurstclient.settings.filterlists.CrystalAuraFilterList;
import net.wurstclient.settings.filterlists.EntityFilterList;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.FakePlayerEntity;
import net.wurstclient.util.InventoryUtils;
import net.wurstclient.util.RotationUtils;

@SearchTags({"crystal aura"})
public final class CrystalAuraHack extends Hack implements UpdateListener
{
	private final SliderSetting range = new SliderSetting("Range",
		"Determines how far CrystalAura will reach to place and detonate crystals.",
		6, 1, 6, 0.05, ValueDisplay.DECIMAL);
	
	private final CheckboxSetting autoPlace = new CheckboxSetting(
		"Auto-place crystals",
		"When enabled, CrystalAura will automatically place crystals near valid entities.\n"
			+ "When disabled, CrystalAura will only detonate manually placed crystals.",
		true);
	
	private final FacingSetting faceBlocks =
		FacingSetting.withPacketSpam("Face crystals",
			"Whether or not CrystalAura should face the correct direction when"
				+ " placing and left-clicking end crystals.\n\n"
				+ "Slower but can help with anti-cheat plugins.",
			Facing.OFF);
	
	private final CheckboxSetting checkLOS = new CheckboxSetting(
		"Check line of sight",
		"Ensures that you don't reach through blocks when placing or left-clicking end crystals.\n\n"
			+ "Slower but can help with anti-cheat plugins.",
		false);
	
	private final SwingHandSetting swingHand =
		new SwingHandSetting(this, SwingHand.CLIENT);
	
	private final EnumSetting<TakeItemsFrom> takeItemsFrom =
		new EnumSetting<>("Take items from", "Where to look for end crystals.",
			TakeItemsFrom.values(), TakeItemsFrom.INVENTORY);
	
	private final EntityFilterList entityFilters =
		CrystalAuraFilterList.create();
	
	public CrystalAuraHack()
	{
		super("CrystalAura");
		
		setCategory(Category.COMBAT);
		addSetting(range);
		addSetting(autoPlace);
		addSetting(faceBlocks);
		addSetting(checkLOS);
		addSetting(swingHand);
		addSetting(takeItemsFrom);
		
		entityFilters.forEach(this::addSetting);
	}
	
	@Override
	protected void onEnable()
	{
		// disable other killauras
		WURST.getHax().aimAssistHack.setEnabled(false);
		WURST.getHax().clickAuraHack.setEnabled(false);
		WURST.getHax().fightBotHack.setEnabled(false);
		WURST.getHax().killauraHack.setEnabled(false);
		WURST.getHax().killauraLegitHack.setEnabled(false);
		WURST.getHax().multiAuraHack.setEnabled(false);
		WURST.getHax().protectHack.setEnabled(false);
		WURST.getHax().triggerBotHack.setEnabled(false);
		WURST.getHax().tpAuraHack.setEnabled(false);
		
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		ArrayList<class_1297> crystals = getNearbyCrystals();
		
		if(!crystals.isEmpty())
		{
			detonate(crystals);
			return;
		}
		
		if(!autoPlace.isChecked())
			return;
		
		if(InventoryUtils.indexOf(class_1802.field_8301,
			takeItemsFrom.getSelected().maxInvSlot) == -1)
			return;
		
		ArrayList<class_1297> targets = getNearbyTargets();
		placeCrystalsNear(targets);
	}
	
	private ArrayList<class_2338> placeCrystalsNear(ArrayList<class_1297> targets)
	{
		ArrayList<class_2338> newCrystals = new ArrayList<>();
		
		boolean shouldSwing = false;
		for(class_1297 target : targets)
		{
			ArrayList<class_2338> freeBlocks = getFreeBlocksNear(target);
			
			for(class_2338 pos : freeBlocks)
				if(placeCrystal(pos))
				{
					shouldSwing = true;
					newCrystals.add(pos);
					
					// TODO optional speed limit(?)
					break;
				}
		}
		
		if(shouldSwing)
			swingHand.swing(class_1268.field_5808);
		
		return newCrystals;
	}
	
	private void detonate(ArrayList<class_1297> crystals)
	{
		for(class_1297 e : crystals)
		{
			faceBlocks.getSelected().face(e.method_5829().method_1005());
			MC.field_1761.method_2918(MC.field_1724, e);
		}
		
		if(!crystals.isEmpty())
			swingHand.swing(class_1268.field_5808);
	}
	
	private boolean placeCrystal(class_2338 pos)
	{
		class_243 eyesPos = RotationUtils.getEyesPos();
		double rangeSq = Math.pow(range.getValue(), 2);
		class_243 posVec = class_243.method_24953(pos);
		double distanceSqPosVec = eyesPos.method_1025(posVec);
		
		for(class_2350 side : class_2350.values())
		{
			class_2338 neighbor = pos.method_10093(side);
			
			// check if neighbor can be right clicked
			if(!isClickableNeighbor(neighbor))
				continue;
			
			class_243 dirVec = class_243.method_24954(side.method_10163());
			class_243 hitVec = posVec.method_1019(dirVec.method_1021(0.5));
			
			// check if hitVec is within range
			if(eyesPos.method_1025(hitVec) > rangeSq)
				continue;
			
			// check if side is visible (facing away from player)
			if(distanceSqPosVec > eyesPos.method_1025(posVec.method_1019(dirVec)))
				continue;
			
			if(checkLOS.isChecked()
				&& !BlockUtils.hasLineOfSight(eyesPos, hitVec))
				continue;
			
			InventoryUtils.selectItem(class_1802.field_8301,
				takeItemsFrom.getSelected().maxInvSlot);
			if(!MC.field_1724.method_24518(class_1802.field_8301))
				return false;
			
			faceBlocks.getSelected().face(hitVec);
			
			// place block
			IMC.getInteractionManager().rightClickBlock(neighbor,
				side.method_10153(), hitVec);
			
			return true;
		}
		
		return false;
	}
	
	private ArrayList<class_1297> getNearbyCrystals()
	{
		class_746 player = MC.field_1724;
		double rangeSq = Math.pow(range.getValue(), 2);
		
		Comparator<class_1297> furthestFromPlayer = Comparator
			.<class_1297> comparingDouble(e -> MC.field_1724.method_5858(e))
			.reversed();
		
		return StreamSupport.stream(MC.field_1687.method_18112().spliterator(), true)
			.filter(class_1511.class::isInstance)
			.filter(e -> !e.method_31481())
			.filter(e -> player.method_5858(e) <= rangeSq)
			.sorted(furthestFromPlayer)
			.collect(Collectors.toCollection(ArrayList::new));
	}
	
	private ArrayList<class_1297> getNearbyTargets()
	{
		double rangeSq = Math.pow(range.getValue(), 2);
		
		Comparator<class_1297> furthestFromPlayer = Comparator
			.<class_1297> comparingDouble(e -> MC.field_1724.method_5858(e))
			.reversed();
		
		Stream<class_1297> stream =
			StreamSupport.stream(MC.field_1687.method_18112().spliterator(), false)
				.filter(e -> !e.method_31481())
				.filter(e -> e instanceof class_1309
					&& ((class_1309)e).method_6032() > 0)
				.filter(e -> e != MC.field_1724)
				.filter(e -> !(e instanceof FakePlayerEntity))
				.filter(
					e -> !WURST.getFriends().contains(e.method_5477().getString()))
				.filter(e -> MC.field_1724.method_5858(e) <= rangeSq);
		
		stream = entityFilters.applyTo(stream);
		
		return stream.sorted(furthestFromPlayer)
			.collect(Collectors.toCollection(ArrayList::new));
	}
	
	private ArrayList<class_2338> getFreeBlocksNear(class_1297 target)
	{
		class_243 eyesVec = RotationUtils.getEyesPos().method_1023(0.5, 0.5, 0.5);
		double rangeD = range.getValue();
		double rangeSq = Math.pow(rangeD + 0.5, 2);
		int rangeI = 2;
		
		class_2338 center = target.method_24515();
		class_2338 min = center.method_10069(-rangeI, -rangeI, -rangeI);
		class_2338 max = center.method_10069(rangeI, rangeI, rangeI);
		class_238 targetBB = target.method_5829();
		
		class_243 targetEyesVec =
			target.method_19538().method_1031(0, target.method_18381(target.method_18376()), 0);
		
		Comparator<class_2338> closestToTarget =
			Comparator.<class_2338> comparingDouble(
				pos -> targetEyesVec.method_1025(class_243.method_24953(pos)));
		
		return BlockUtils.getAllInBoxStream(min, max)
			.filter(pos -> eyesVec.method_1025(class_243.method_24954(pos)) <= rangeSq)
			.filter(this::isReplaceable).filter(this::hasCrystalBase)
			.filter(pos -> !targetBB.method_994(new class_238(pos)))
			.sorted(closestToTarget)
			.collect(Collectors.toCollection(ArrayList::new));
	}
	
	private boolean isReplaceable(class_2338 pos)
	{
		return BlockUtils.getState(pos).method_45474();
	}
	
	private boolean hasCrystalBase(class_2338 pos)
	{
		class_2248 block = BlockUtils.getBlock(pos.method_10074());
		return block == class_2246.field_9987 || block == class_2246.field_10540;
	}
	
	private boolean isClickableNeighbor(class_2338 pos)
	{
		return BlockUtils.canBeClicked(pos)
			&& !BlockUtils.getState(pos).method_45474();
	}
	
	private enum TakeItemsFrom
	{
		HOTBAR("Hotbar", 9),
		
		INVENTORY("Inventory", 36);
		
		private final String name;
		private final int maxInvSlot;
		
		private TakeItemsFrom(String name, int maxInvSlot)
		{
			this.name = name;
			this.maxInvSlot = maxInvSlot;
		}
		
		@Override
		public String toString()
		{
			return name;
		}
	}
}
