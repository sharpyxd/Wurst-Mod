/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_1802;
import net.minecraft.class_2828.class_5911;
import net.minecraft.class_746;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;

@SearchTags({"no fall"})
public final class NoFallHack extends Hack implements UpdateListener
{
	private final CheckboxSetting allowElytra = new CheckboxSetting(
		"Allow elytra", "description.wurst.setting.nofall.allow_elytra", false);
	
	private final CheckboxSetting pauseForMace =
		new CheckboxSetting("Pause for mace",
			"description.wurst.setting.nofall.pause_for_mace", false);
	
	public NoFallHack()
	{
		super("NoFall");
		setCategory(Category.MOVEMENT);
		addSetting(allowElytra);
		addSetting(pauseForMace);
	}
	
	@Override
	public String getRenderName()
	{
		class_746 player = MC.field_1724;
		if(player == null)
			return getName();
		
		if(player.method_6128() && !allowElytra.isChecked())
			return getName() + " (paused)";
		
		if(player.method_7337())
			return getName() + " (paused)";
		
		if(pauseForMace.isChecked() && isHoldingMace(player))
			return getName() + " (paused)";
		
		return getName();
	}
	
	@Override
	protected void onEnable()
	{
		WURST.getHax().antiHungerHack.setEnabled(false);
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		// do nothing in creative mode, since there is no fall damage anyway
		class_746 player = MC.field_1724;
		if(player.method_7337())
			return;
		
		// pause when flying with elytra, unless allowed
		boolean fallFlying = player.method_6128();
		if(fallFlying && !allowElytra.isChecked())
			return;
		
		// pause when holding a mace, if enabled
		if(pauseForMace.isChecked() && isHoldingMace(player))
			return;
		
		// attempt to fix elytra weirdness, if allowed
		if(fallFlying && player.method_5715()
			&& !isFallingFastEnoughToCauseDamage(player))
			return;
		
		// send packet to stop fall damage
		player.field_3944.method_52787(new class_5911(true));
	}
	
	private boolean isHoldingMace(class_746 player)
	{
		return player.method_6047().method_31574(class_1802.field_49814);
	}
	
	private boolean isFallingFastEnoughToCauseDamage(class_746 player)
	{
		return player.method_18798().field_1351 < -0.5;
	}
}
