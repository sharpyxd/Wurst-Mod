/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_238;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.RenderListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.util.RenderUtils;

@SearchTags({"prophunt esp"})
public final class ProphuntEspHack extends Hack implements RenderListener
{
	private static final class_238 FAKE_BLOCK_BOX =
		new class_238(-0.5, 0, -0.5, 0.5, 1, 0.5);
	
	public ProphuntEspHack()
	{
		super("ProphuntESP");
		setCategory(Category.RENDER);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(RenderListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(RenderListener.class, this);
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		// set color
		float alpha = 0.5F + 0.25F * class_3532
			.method_15374(System.currentTimeMillis() % 1000 / 500F * class_3532.field_29844);
		int color = RenderUtils.toIntColor(new float[]{1, 0, 0}, alpha);
		
		// draw boxes
		ArrayList<class_238> boxes = new ArrayList<>();
		for(class_1297 entity : MC.field_1687.method_18112())
		{
			if(!(entity instanceof class_1308))
				continue;
			
			if(!entity.method_5767())
				continue;
			
			if(MC.field_1724.method_5858(entity) < 0.25)
				continue;
			
			boxes.add(FAKE_BLOCK_BOX.method_997(entity.method_19538()));
		}
		
		RenderUtils.drawSolidBoxes(matrixStack, boxes, color, false);
		RenderUtils.drawOutlinedBoxes(matrixStack, boxes, color, false);
	}
}
