/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_1304;
import net.minecraft.class_1770;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2848;
import net.minecraft.class_3532;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;

@SearchTags({"EasyElytra", "extra elytra", "easy elytra"})
public final class ExtraElytraHack extends Hack implements UpdateListener
{
	private final CheckboxSetting instantFly = new CheckboxSetting(
		"Instant fly", "Jump to fly, no weird double-jump needed!", true);
	
	private final CheckboxSetting speedCtrl = new CheckboxSetting(
		"Speed control", "Control your speed with the Forward and Back keys.\n"
			+ "(default: W and S)\n" + "No fireworks needed!",
		true);
	
	private final CheckboxSetting heightCtrl =
		new CheckboxSetting("Height control",
			"Control your height with the Jump and Sneak keys.\n"
				+ "(default: Spacebar and Shift)\n" + "No fireworks needed!",
			false);
	
	private final CheckboxSetting stopInWater =
		new CheckboxSetting("Stop flying in water", true);
	
	private int jumpTimer;
	
	public ExtraElytraHack()
	{
		super("ExtraElytra");
		setCategory(Category.MOVEMENT);
		addSetting(instantFly);
		addSetting(speedCtrl);
		addSetting(heightCtrl);
		addSetting(stopInWater);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
		jumpTimer = 0;
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(jumpTimer > 0)
			jumpTimer--;
		
		class_1799 chest = MC.field_1724.method_6118(class_1304.field_6174);
		if(chest.method_7909() != class_1802.field_8833)
			return;
		
		if(MC.field_1724.method_6128())
		{
			if(stopInWater.isChecked() && MC.field_1724.method_5799())
			{
				sendStartStopPacket();
				return;
			}
			
			controlSpeed();
			controlHeight();
			return;
		}
		
		if(class_1770.method_7804(chest) && MC.field_1690.field_1903.method_1434())
			doInstantFly();
	}
	
	private void sendStartStopPacket()
	{
		class_2848 packet = new class_2848(MC.field_1724,
			class_2848.class_2849.field_12982);
		MC.field_1724.field_3944.method_52787(packet);
	}
	
	private void controlHeight()
	{
		if(!heightCtrl.isChecked())
			return;
		
		class_243 v = MC.field_1724.method_18798();
		
		if(MC.field_1690.field_1903.method_1434())
			MC.field_1724.method_18800(v.field_1352, v.field_1351 + 0.08, v.field_1350);
		else if(MC.field_1690.field_1832.method_1434())
			MC.field_1724.method_18800(v.field_1352, v.field_1351 - 0.04, v.field_1350);
	}
	
	private void controlSpeed()
	{
		if(!speedCtrl.isChecked())
			return;
		
		float yaw = (float)Math.toRadians(MC.field_1724.method_36454());
		class_243 forward = new class_243(-class_3532.method_15374(yaw) * 0.05, 0,
			class_3532.method_15362(yaw) * 0.05);
		
		class_243 v = MC.field_1724.method_18798();
		
		if(MC.field_1690.field_1894.method_1434())
			MC.field_1724.method_18799(v.method_1019(forward));
		else if(MC.field_1690.field_1881.method_1434())
			MC.field_1724.method_18799(v.method_1020(forward));
	}
	
	private void doInstantFly()
	{
		if(!instantFly.isChecked())
			return;
		
		if(jumpTimer <= 0)
		{
			jumpTimer = 20;
			MC.field_1724.method_6100(false);
			MC.field_1724.method_5728(true);
			MC.field_1724.method_6043();
		}
		
		sendStartStopPacket();
	}
}
