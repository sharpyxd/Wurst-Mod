/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_238;
import net.minecraft.class_2828;
import net.minecraft.class_634;
import net.minecraft.class_746;
import net.wurstclient.Category;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.EnumSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.util.BlockUtils;

public final class StepHack extends Hack implements UpdateListener
{
	private final EnumSetting<Mode> mode = new EnumSetting<>("Mode",
		"\u00a7lSimple\u00a7r mode can step up multiple blocks (enables Height slider).\n"
			+ "\u00a7lLegit\u00a7r mode can bypass NoCheat+.",
		Mode.values(), Mode.LEGIT);
	
	private final SliderSetting height =
		new SliderSetting("Height", "Only works in \u00a7lSimple\u00a7r mode.",
			1, 1, 10, 1, ValueDisplay.INTEGER);
	
	public StepHack()
	{
		super("Step");
		setCategory(Category.MOVEMENT);
		addSetting(mode);
		addSetting(height);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(mode.getSelected() == Mode.SIMPLE)
			return;
		
		class_746 player = MC.field_1724;
		if(!player.field_5976)
			return;
		
		if(!player.method_24828() || player.method_6101()
			|| player.method_5799() || player.method_5771())
			return;
		
		if(player.field_3913.field_3905 == 0
			&& player.field_3913.field_3907 == 0)
			return;
		
		if(player.field_3913.field_3904)
			return;
		
		class_238 box = player.method_5829().method_989(0, 0.05, 0).method_1014(0.05);
		if(!MC.field_1687.method_8587(player, box.method_989(0, 1, 0)))
			return;
		
		double stepHeight = BlockUtils.getBlockCollisions(box)
			.mapToDouble(bb -> bb.field_1325).max().orElse(Double.NEGATIVE_INFINITY);
		
		stepHeight -= player.method_23318();
		
		if(stepHeight < 0 || stepHeight > 1)
			return;
		
		class_634 netHandler = player.field_3944;
		
		netHandler.method_52787(new class_2828.class_2829(
			player.method_23317(), player.method_23318() + 0.42 * stepHeight, player.method_23321(),
			player.method_24828()));
		
		netHandler.method_52787(new class_2828.class_2829(
			player.method_23317(), player.method_23318() + 0.753 * stepHeight, player.method_23321(),
			player.method_24828()));
		
		player.method_5814(player.method_23317(), player.method_23318() + stepHeight,
			player.method_23321());
	}
	
	public float adjustStepHeight(float stepHeight)
	{
		if(isEnabled() && mode.getSelected() == Mode.SIMPLE)
			return height.getValueF();
		
		return stepHeight;
	}
	
	public boolean isAutoJumpAllowed()
	{
		return !isEnabled() && !WURST.getCmds().goToCmd.isActive();
	}
	
	private enum Mode
	{
		SIMPLE("Simple"),
		LEGIT("Legit");
		
		private final String name;
		
		private Mode(String name)
		{
			this.name = name;
		}
		
		@Override
		public String toString()
		{
			return name;
		}
	}
}
