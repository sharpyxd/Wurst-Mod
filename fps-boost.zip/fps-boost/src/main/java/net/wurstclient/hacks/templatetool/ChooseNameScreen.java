/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.templatetool;

import java.nio.file.Path;

import org.lwjgl.glfw.GLFW;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.wurstclient.WurstClient;

public final class ChooseNameScreen extends class_437
{
	private static final WurstClient WURST = WurstClient.INSTANCE;
	
	private class_342 nameField;
	private class_4185 doneButton;
	private class_4185 cancelButton;
	
	public ChooseNameScreen()
	{
		super(class_5244.field_39003);
	}
	
	@Override
	public void method_25426()
	{
		class_327 tr = field_22787.field_1772;
		int middleX = field_22789 / 2;
		int middleY = field_22790 / 2;
		
		nameField = new class_342(tr, middleX - 99, middleY + 16, 198, 16,
			class_2561.method_43473());
		nameField.method_1858(false);
		nameField.method_1880(32);
		nameField.method_25365(true);
		nameField.method_1868(0xFFFFFF);
		method_25429(nameField);
		method_25395(nameField);
		
		doneButton = class_4185.method_46430(class_2561.method_43470("Done"), b -> done())
			.method_46434(middleX - 75, middleY + 38, 150, 20).method_46431();
		method_37063(doneButton);
		
		cancelButton =
			class_4185.method_46430(class_2561.method_43470("Cancel"), b -> cancel())
				.method_46434(middleX - 50, middleY + 62, 100, 15).method_46431();
		method_37063(cancelButton);
	}
	
	private void done()
	{
		field_22787.method_1507(null);
		WURST.getHax().templateToolHack.saveFile();
	}
	
	private void cancel()
	{
		field_22787.method_1507(null);
		WURST.getHax().templateToolHack.setEnabled(false);
	}
	
	@Override
	public void method_25393()
	{
		if(nameField.method_1882().isEmpty())
			return;
		
		Path folder = WURST.getHax().autoBuildHack.getFolder();
		Path file = folder.resolve(nameField.method_1882() + ".json");
		WURST.getHax().templateToolHack.setFile(file.toFile());
	}
	
	@Override
	public boolean method_25404(int keyCode, int scanCode, int modifiers)
	{
		switch(keyCode)
		{
			case GLFW.GLFW_KEY_ESCAPE:
			cancelButton.method_25306();
			break;
			
			case GLFW.GLFW_KEY_ENTER:
			doneButton.method_25306();
			break;
		}
		
		return super.method_25404(keyCode, scanCode, modifiers);
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		// super.render(context, mouseX, mouseY, partialTicks);
		method_57734(partialTicks);
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
		
		// middle
		int middleX = field_22789 / 2;
		int middleY = field_22790 / 2;
		
		// background positions
		int x1 = middleX - 100;
		int y1 = middleY + 15;
		int x2 = middleX + 100;
		int y2 = middleY + 26;
		
		// background
		context.method_25294(x1, y1, x2, y2, 0x80000000);
		
		// name field
		nameField.method_25394(context, mouseX, mouseY, partialTicks);
	}
	
	@Override
	public boolean method_25421()
	{
		return false;
	}
	
	@Override
	public boolean method_25422()
	{
		return false;
	}
}
