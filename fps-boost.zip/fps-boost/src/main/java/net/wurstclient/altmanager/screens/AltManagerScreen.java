/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.altmanager.screens;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.StringJoiner;

import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import com.google.gson.JsonObject;

import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_3544;
import net.minecraft.class_364;
import net.minecraft.class_403;
import net.minecraft.class_4068;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import net.minecraft.class_4280;
import net.minecraft.class_437;
import net.minecraft.class_5348;
import net.wurstclient.WurstClient;
import net.wurstclient.altmanager.*;
import net.wurstclient.mixinterface.IMinecraftClient;
import net.wurstclient.util.MultiProcessingUtils;
import net.wurstclient.util.json.JsonException;
import net.wurstclient.util.json.JsonUtils;
import net.wurstclient.util.json.WsonObject;

public final class AltManagerScreen extends class_437
{
	private static final HashSet<Alt> failedLogins = new HashSet<>();
	
	private final class_437 prevScreen;
	private final AltManager altManager;
	
	private ListGui listGui;
	private boolean shouldAsk = true;
	private int errorTimer;
	
	private class_4185 useButton;
	private class_4185 starButton;
	private class_4185 editButton;
	private class_4185 deleteButton;
	
	private class_4185 importButton;
	private class_4185 exportButton;
	private class_4185 logoutButton;
	
	public AltManagerScreen(class_437 prevScreen, AltManager altManager)
	{
		super(class_2561.method_43470("Alt Manager"));
		this.prevScreen = prevScreen;
		this.altManager = altManager;
	}
	
	@Override
	public void method_25426()
	{
		listGui = new ListGui(field_22787, this, altManager.getList());
		method_25429(listGui);
		
		WurstClient wurst = WurstClient.INSTANCE;
		
		Exception folderException = altManager.getFolderException();
		if(folderException != null && shouldAsk)
		{
			class_2561 title = class_2561.method_43470(
				wurst.translate("gui.wurst.altmanager.folder_error.title"));
			class_2561 message = class_2561.method_43470(wurst.translate(
				"gui.wurst.altmanager.folder_error.message", folderException));
			class_2561 buttonText = class_2561.method_43471("gui.done");
			
			// This just sets shouldAsk to false and closes the message.
			Runnable action = () -> confirmGenerate(false);
			
			class_403 screen =
				new class_403(action, title, message, buttonText, false);
			field_22787.method_1507(screen);
			
		}else if(altManager.getList().isEmpty() && shouldAsk)
		{
			class_2561 title = class_2561
				.method_43470(wurst.translate("gui.wurst.altmanager.empty.title"));
			class_2561 message = class_2561
				.method_43470(wurst.translate("gui.wurst.altmanager.empty.message"));
			BooleanConsumer callback = this::confirmGenerate;
			
			class_410 screen = new class_410(callback, title, message);
			field_22787.method_1507(screen);
		}
		
		method_37063(useButton =
			class_4185.method_46430(class_2561.method_43470("Login"), b -> pressLogin())
				.method_46434(field_22789 / 2 - 154, field_22790 - 52, 100, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Direct Login"),
				b -> field_22787.method_1507(new DirectLoginScreen(this)))
			.method_46434(field_22789 / 2 - 50, field_22790 - 52, 100, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Add"),
				b -> field_22787.method_1507(new AddAltScreen(this, altManager)))
			.method_46434(field_22789 / 2 + 54, field_22790 - 52, 100, 20).method_46431());
		
		method_37063(starButton =
			class_4185.method_46430(class_2561.method_43470("Favorite"), b -> pressFavorite())
				.method_46434(field_22789 / 2 - 154, field_22790 - 28, 75, 20).method_46431());
		
		method_37063(editButton =
			class_4185.method_46430(class_2561.method_43470("Edit"), b -> pressEdit())
				.method_46434(field_22789 / 2 - 76, field_22790 - 28, 74, 20).method_46431());
		
		method_37063(deleteButton =
			class_4185.method_46430(class_2561.method_43470("Delete"), b -> pressDelete())
				.method_46434(field_22789 / 2 + 2, field_22790 - 28, 74, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Cancel"), b -> field_22787.method_1507(prevScreen))
			.method_46434(field_22789 / 2 + 80, field_22790 - 28, 75, 20).method_46431());
		
		method_37063(importButton =
			class_4185.method_46430(class_2561.method_43470("Import"), b -> pressImportAlts())
				.method_46434(8, 8, 50, 20).method_46431());
		
		method_37063(exportButton =
			class_4185.method_46430(class_2561.method_43470("Export"), b -> pressExportAlts())
				.method_46434(58, 8, 50, 20).method_46431());
		
		method_37063(logoutButton =
			class_4185.method_46430(class_2561.method_43470("Logout"), b -> pressLogout())
				.method_46434(field_22789 - 50 - 8, 8, 50, 20).method_46431());
		
		updateAltButtons();
		boolean windowMode = !field_22787.field_1690.method_42447().method_41753();
		importButton.field_22763 = windowMode;
		exportButton.field_22763 = windowMode;
	}
	
	private void updateAltButtons()
	{
		boolean altSelected = listGui.method_25334() != null;
		useButton.field_22763 = altSelected;
		starButton.field_22763 = altSelected;
		editButton.field_22763 = altSelected;
		deleteButton.field_22763 = altSelected;
		
		logoutButton.field_22763 =
			((IMinecraftClient)field_22787).getWurstSession() != null;
	}
	
	@Override
	public boolean method_25404(int keyCode, int scanCode, int modifiers)
	{
		if(keyCode == GLFW.GLFW_KEY_ENTER)
			useButton.method_25306();
		
		return super.method_25404(keyCode, scanCode, modifiers);
	}
	
	@Override
	public boolean method_25402(double mouseX, double mouseY, int button)
	{
		if(button == GLFW.GLFW_MOUSE_BUTTON_4)
		{
			method_25419();
			return true;
		}
		
		return super.method_25402(mouseX, mouseY, button);
	}
	
	private void pressLogin()
	{
		Alt alt = listGui.getSelectedAlt();
		if(alt == null)
			return;
		
		try
		{
			altManager.login(alt);
			failedLogins.remove(alt);
			field_22787.method_1507(prevScreen);
			
		}catch(LoginException e)
		{
			errorTimer = 8;
			failedLogins.add(alt);
		}
	}
	
	private void pressLogout()
	{
		((IMinecraftClient)field_22787).setWurstSession(null);
		updateAltButtons();
	}
	
	private void pressFavorite()
	{
		Alt alt = listGui.getSelectedAlt();
		if(alt == null)
			return;
		
		altManager.toggleFavorite(alt);
		listGui.setSelected(null);
	}
	
	private void pressEdit()
	{
		Alt alt = listGui.getSelectedAlt();
		if(alt == null)
			return;
		
		field_22787.method_1507(new EditAltScreen(this, altManager, alt));
	}
	
	private void pressDelete()
	{
		Alt alt = listGui.getSelectedAlt();
		if(alt == null)
			return;
		
		class_2561 text = class_2561.method_43470("Are you sure you want to remove this alt?");
		
		String altName = alt.getDisplayName();
		class_2561 message = class_2561.method_43470(
			"\"" + altName + "\" will be lost forever! (A long time!)");
		
		class_410 screen = new class_410(this::confirmRemove, text,
			message, class_2561.method_43470("Delete"), class_2561.method_43470("Cancel"));
		field_22787.method_1507(screen);
	}
	
	private void pressImportAlts()
	{
		try
		{
			Process process = MultiProcessingUtils.startProcessWithIO(
				ImportAltsFileChooser.class,
				WurstClient.INSTANCE.getWurstFolder().toString());
			
			Path path = getFileChooserPath(process);
			process.waitFor();
			
			if(path.getFileName().toString().endsWith(".json"))
				importAsJSON(path);
			else
				importAsTXT(path);
			
		}catch(IOException | InterruptedException | JsonException e)
		{
			e.printStackTrace();
		}
	}
	
	private void importAsJSON(Path path) throws IOException, JsonException
	{
		WsonObject wson = JsonUtils.parseFileToObject(path);
		ArrayList<Alt> alts = AltsFile.parseJson(wson);
		altManager.addAll(alts);
	}
	
	private void importAsTXT(Path path) throws IOException
	{
		List<String> lines = Files.readAllLines(path);
		ArrayList<Alt> alts = new ArrayList<>();
		
		for(String line : lines)
		{
			String[] data = line.split(":");
			
			switch(data.length)
			{
				case 1:
				alts.add(new CrackedAlt(data[0]));
				break;
				
				case 2:
				alts.add(new MojangAlt(data[0], data[1]));
				break;
			}
		}
		
		altManager.addAll(alts);
	}
	
	private void pressExportAlts()
	{
		try
		{
			Process process = MultiProcessingUtils.startProcessWithIO(
				ExportAltsFileChooser.class,
				WurstClient.INSTANCE.getWurstFolder().toString());
			
			Path path = getFileChooserPath(process);
			
			process.waitFor();
			
			if(path.getFileName().toString().endsWith(".json"))
				exportAsJSON(path);
			else
				exportAsTXT(path);
			
		}catch(IOException | InterruptedException | JsonException e)
		{
			e.printStackTrace();
		}
	}
	
	private Path getFileChooserPath(Process process) throws IOException
	{
		try(BufferedReader bf =
			new BufferedReader(new InputStreamReader(process.getInputStream(),
				StandardCharsets.UTF_8)))
		{
			String response = bf.readLine();
			
			if(response == null)
				throw new IOException("No response from FileChooser");
			
			try
			{
				return Paths.get(response);
				
			}catch(InvalidPathException e)
			{
				throw new IOException(
					"Response from FileChooser is not a valid path");
			}
		}
	}
	
	private void exportAsJSON(Path path) throws IOException, JsonException
	{
		JsonObject json = AltsFile.createJson(altManager);
		JsonUtils.toJson(json, path);
	}
	
	private void exportAsTXT(Path path) throws IOException
	{
		List<String> lines = new ArrayList<>();
		
		for(Alt alt : altManager.getList())
			lines.add(alt.exportAsTXT());
		
		Files.write(path, lines);
	}
	
	private void confirmGenerate(boolean confirmed)
	{
		if(confirmed)
		{
			ArrayList<Alt> alts = new ArrayList<>();
			for(int i = 0; i < 8; i++)
				alts.add(new CrackedAlt(NameGenerator.generateName()));
			
			altManager.addAll(alts);
		}
		
		shouldAsk = false;
		field_22787.method_1507(this);
	}
	
	private void confirmRemove(boolean confirmed)
	{
		Alt alt = listGui.getSelectedAlt();
		if(alt == null)
			return;
		
		if(confirmed)
			altManager.remove(alt);
		
		field_22787.method_1507(this);
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		method_25420(context, mouseX, mouseY, partialTicks);
		listGui.method_25394(context, mouseX, mouseY, partialTicks);
		
		// skin preview
		Alt alt = listGui.getSelectedAlt();
		if(alt != null)
		{
			AltRenderer.drawAltBack(context, alt.getName(),
				(field_22789 / 2 - 125) / 2 - 32, field_22790 / 2 - 64 - 9, 64, 128);
			AltRenderer.drawAltBody(context, alt.getName(),
				field_22789 - (field_22789 / 2 - 140) / 2 - 32, field_22790 / 2 - 64 - 9, 64,
				128);
		}
		
		// title text
		context.method_25300(field_22793, "Alt Manager",
			field_22789 / 2, 4, 16777215);
		context.method_25300(field_22793,
			"Alts: " + altManager.getList().size(), field_22789 / 2, 14, 10526880);
		context.method_25300(
			field_22793, "premium: " + altManager.getNumPremium()
				+ ", cracked: " + altManager.getNumCracked(),
			field_22789 / 2, 24, 10526880);
		
		// red flash for errors
		if(errorTimer > 0)
		{
			int alpha = (int)(Math.min(1, errorTimer / 16F) * 255);
			int color = 0xFF0000 | alpha << 24;
			context.method_25294(0, 0, field_22789, field_22790, color);
			errorTimer--;
		}
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
		
		renderButtonTooltip(context, mouseX, mouseY);
		renderAltTooltip(context, mouseX, mouseY);
	}
	
	private void renderAltTooltip(class_332 context, int mouseX, int mouseY)
	{
		if(!listGui.method_25405(mouseX, mouseY))
			return;
		
		Entry hoveredEntry = listGui.getHoveredEntry(mouseX, mouseY);
		if(hoveredEntry == null)
			return;
		
		int hoveredIndex = listGui.method_25396().indexOf(hoveredEntry);
		int itemX = mouseX - listGui.method_25342();
		int itemY = mouseY - 36 + (int)listGui.method_25341() - 4
			- hoveredIndex * 30;
		
		if(itemX < 31 || itemY < 15 || itemY >= 25)
			return;
		
		Alt alt = hoveredEntry.alt;
		ArrayList<class_2561> tooltip = new ArrayList<>();
		
		if(itemX >= 31 + field_22793.method_1727(hoveredEntry.getBottomText()))
			return;
		
		if(alt.isCracked())
			addTooltip(tooltip, "cracked");
		else
		{
			addTooltip(tooltip, "premium");
			
			if(failedLogins.contains(alt))
				addTooltip(tooltip, "failed");
			
			if(alt.isCheckedPremium())
				addTooltip(tooltip, "checked");
			else
				addTooltip(tooltip, "unchecked");
		}
		
		if(alt.isFavorite())
			addTooltip(tooltip, "favorite");
		
		context.method_51434(field_22793, tooltip, mouseX, mouseY);
	}
	
	private void renderButtonTooltip(class_332 context, int mouseX,
		int mouseY)
	{
		for(class_339 button : Screens.getButtons(this))
		{
			if(!button.method_25367())
				continue;
			
			if(button != importButton && button != exportButton)
				continue;
			
			ArrayList<class_2561> tooltip = new ArrayList<>();
			addTooltip(tooltip, "window");
			
			if(field_22787.field_1690.method_42447().method_41753())
				addTooltip(tooltip, "fullscreen");
			else
				addTooltip(tooltip, "window_freeze");
			
			context.method_51434(field_22793, tooltip, mouseX, mouseY);
			break;
		}
	}
	
	private void addTooltip(ArrayList<class_2561> tooltip, String trKey)
	{
		// translate
		String translated = WurstClient.INSTANCE
			.translate("description.wurst.altmanager." + trKey);
		
		// line-wrap
		StringJoiner joiner = new StringJoiner("\n");
		field_22793.method_27527().method_27498(translated, 200, class_2583.field_24360)
			.stream().map(class_5348::getString)
			.forEach(s -> joiner.add(s));
		String wrapped = joiner.toString();
		
		// add to tooltip
		for(String line : wrapped.split("\n"))
			tooltip.add(class_2561.method_43470(line));
	}
	
	@Override
	public void method_25419()
	{
		field_22787.method_1507(prevScreen);
	}
	
	private final class Entry
		extends class_4280.class_4281<AltManagerScreen.Entry>
	{
		private final Alt alt;
		private long lastClickTime;
		
		public Entry(Alt alt)
		{
			this.alt = Objects.requireNonNull(alt);
		}
		
		@Override
		public class_2561 method_37006()
		{
			return class_2561.method_43469("narrator.select", "Alt " + alt + ", "
				+ class_3544.method_15440(getBottomText()));
		}
		
		@Override
		public boolean method_25402(double mouseX, double mouseY,
			int mouseButton)
		{
			if(mouseButton != GLFW.GLFW_MOUSE_BUTTON_LEFT)
				return false;
			
			long timeSinceLastClick = class_156.method_658() - lastClickTime;
			lastClickTime = class_156.method_658();
			
			if(timeSinceLastClick < 250)
				pressLogin();
			
			return true;
		}
		
		@Override
		public void method_25343(class_332 context, int index, int y, int x,
			int entryWidth, int entryHeight, int mouseX, int mouseY,
			boolean hovered, float tickDelta)
		{
			// green glow when logged in
			if(field_22787.method_1548().method_1676().equals(alt.getName()))
			{
				float opacity =
					0.3F - Math.abs(class_3532.method_15374(System.currentTimeMillis()
						% 10000L / 10000F * (float)Math.PI * 2.0F) * 0.15F);
				
				int color = 0x00FF00 | (int)(opacity * 255) << 24;
				context.method_25294(x - 2, y - 2, x + 218, y + 28, color);
			}
			
			// face
			AltRenderer.drawAltFace(context, alt.getName(), x + 1, y + 1, 24,
				24, listGui.method_25334() == this);
			
			class_327 tr = field_22787.field_1772;
			
			// name / email
			context.method_51433(tr, "Name: " + alt.getDisplayName(), x + 31, y + 3,
				0xA0A0A0, false);
			
			// status
			context.method_51433(tr, getBottomText(), x + 31, y + 15, 10526880,
				false);
		}
		
		private String getBottomText()
		{
			String text = alt.isCracked() ? "\u00a78cracked" : "\u00a72premium";
			
			if(alt.isFavorite())
				text += "\u00a7r, \u00a7efavorite";
			
			if(failedLogins.contains(alt))
				text += "\u00a7r, \u00a7cwrong password?";
			else if(alt.isUncheckedPremium())
				text += "\u00a7r, \u00a7cunchecked";
			
			return text;
		}
	}
	
	private final class ListGui
		extends class_4280<AltManagerScreen.Entry>
	{
		public ListGui(class_310 minecraft, AltManagerScreen screen,
			List<Alt> list)
		{
			super(minecraft, screen.field_22789, screen.field_22790 - 96, 36, 30);
			
			list.stream().map(AltManagerScreen.Entry::new)
				.forEach(this::method_25321);
		}
		
		@Override
		public void setSelected(@Nullable AltManagerScreen.Entry entry)
		{
			super.method_25313(entry);
			updateAltButtons();
		}
		
		// This method sets selected to null without calling setSelected().
		@Override
		protected void method_25339()
		{
			super.method_25339();
			updateAltButtons();
		}
		
		/**
		 * @return The selected Alt, or null if no Alt is selected.
		 */
		public Alt getSelectedAlt()
		{
			AltManagerScreen.Entry selected = method_25334();
			return selected != null ? selected.alt : null;
		}
		
		/**
		 * @return The hovered Entry, or null if no Entry is hovered.
		 */
		public AltManagerScreen.Entry getHoveredEntry(double mouseX,
			double mouseY)
		{
			Optional<class_364> hovered = method_19355(mouseX, mouseY);
			return hovered.map(e -> ((AltManagerScreen.Entry)e)).orElse(null);
		}
	}
}
