/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.ai;

import java.util.ArrayList;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.wurstclient.util.RotationUtils;

public class FlyPathProcessor extends PathProcessor
{
	private final boolean creativeFlying;
	
	public FlyPathProcessor(ArrayList<PathPos> path, boolean creativeFlying)
	{
		super(path);
		this.creativeFlying = creativeFlying;
	}
	
	@Override
	public void process()
	{
		// get positions
		class_2338 pos = class_2338.method_49638(MC.field_1724.method_19538());
		class_243 posVec = MC.field_1724.method_19538();
		class_2338 nextPos = path.get(index);
		int posIndex = path.indexOf(pos);
		class_238 nextBox = new class_238(nextPos.method_10263() + 0.3, nextPos.method_10264(),
			nextPos.method_10260() + 0.3, nextPos.method_10263() + 0.7, nextPos.method_10264() + 0.2,
			nextPos.method_10260() + 0.7);
		
		if(posIndex == -1)
			ticksOffPath++;
		else
			ticksOffPath = 0;
		
		// update index
		if(posIndex > index
			|| posVec.field_1352 >= nextBox.field_1323 && posVec.field_1352 <= nextBox.field_1320
				&& posVec.field_1351 >= nextBox.field_1322 && posVec.field_1351 <= nextBox.field_1325
				&& posVec.field_1350 >= nextBox.field_1321 && posVec.field_1350 <= nextBox.field_1324)
		{
			if(posIndex > index)
				index = posIndex + 1;
			else
				index++;
			
			// stop when changing directions
			if(creativeFlying)
			{
				class_243 v = MC.field_1724.method_18798();
				
				MC.field_1724.method_18800(v.field_1352 / Math.max(Math.abs(v.field_1352) * 50, 1),
					v.field_1351 / Math.max(Math.abs(v.field_1351) * 50, 1),
					v.field_1350 / Math.max(Math.abs(v.field_1350) * 50, 1));
			}
			
			if(index >= path.size())
				done = true;
			
			return;
		}
		
		lockControls();
		MC.field_1724.method_31549().field_7479 = creativeFlying;
		boolean x = posVec.field_1352 < nextBox.field_1323 || posVec.field_1352 > nextBox.field_1320;
		boolean y = posVec.field_1351 < nextBox.field_1322 || posVec.field_1351 > nextBox.field_1325;
		boolean z = posVec.field_1350 < nextBox.field_1321 || posVec.field_1350 > nextBox.field_1324;
		boolean horizontal = x || z;
		
		// face next position
		if(horizontal)
		{
			facePosition(nextPos);
			if(Math.abs(class_3532.method_15393(RotationUtils
				.getHorizontalAngleToLookVec(class_243.method_24953(nextPos)))) > 1)
				return;
		}
		
		// skip mid-air nodes
		class_2382 offset = nextPos.method_10059(pos);
		while(index < path.size() - 1
			&& path.get(index).method_10081(offset).equals(path.get(index + 1)))
			index++;
		
		if(creativeFlying)
		{
			class_243 v = MC.field_1724.method_18798();
			
			if(!x)
				MC.field_1724.method_18800(v.field_1352 / Math.max(Math.abs(v.field_1352) * 50, 1),
					v.field_1351, v.field_1350);
			if(!y)
				MC.field_1724.method_18800(v.field_1352,
					v.field_1351 / Math.max(Math.abs(v.field_1351) * 50, 1), v.field_1350);
			if(!z)
				MC.field_1724.method_18800(v.field_1352, v.field_1351,
					v.field_1350 / Math.max(Math.abs(v.field_1350) * 50, 1));
		}
		
		class_243 vecInPos = new class_243(nextPos.method_10263() + 0.5, nextPos.method_10264() + 0.1,
			nextPos.method_10260() + 0.5);
		
		// horizontal movement
		if(horizontal)
		{
			if(!creativeFlying && MC.field_1724.method_19538().method_1022(
				vecInPos) <= WURST.getHax().flightHack.horizontalSpeed
					.getValue())
			{
				MC.field_1724.method_5814(vecInPos.field_1352, vecInPos.field_1351, vecInPos.field_1350);
				return;
			}
			
			MC.field_1690.field_1894.method_23481(true);
			
			if(MC.field_1724.field_5976)
				if(posVec.field_1351 > nextBox.field_1325)
					MC.field_1690.field_1832.method_23481(true);
				else if(posVec.field_1351 < nextBox.field_1322)
					MC.field_1690.field_1903.method_23481(true);
				
			// vertical movement
		}else if(y)
		{
			if(!creativeFlying && MC.field_1724.method_19538().method_1022(
				vecInPos) <= WURST.getHax().flightHack.verticalSpeed.getValue())
			{
				MC.field_1724.method_5814(vecInPos.field_1352, vecInPos.field_1351, vecInPos.field_1350);
				return;
			}
			
			if(posVec.field_1351 < nextBox.field_1322)
				MC.field_1690.field_1903.method_23481(true);
			else
				MC.field_1690.field_1832.method_23481(true);
			
			if(MC.field_1724.field_5992)
			{
				MC.field_1690.field_1832.method_23481(false);
				MC.field_1690.field_1894.method_23481(true);
			}
		}
	}
	
	@Override
	public boolean canBreakBlocks()
	{
		return true;
	}
}
