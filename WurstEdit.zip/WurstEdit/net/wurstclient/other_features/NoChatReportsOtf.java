/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.other_features;

import net.fabricmc.fabric.api.client.networking.v1.ClientLoginConnectionEvents;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2588;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_635;
import net.minecraft.class_7469;
import net.minecraft.class_7591;
import net.minecraft.class_7591.class_7592;
import net.minecraft.class_7610;
import net.minecraft.class_7818;
import net.wurstclient.Category;
import net.wurstclient.DontBlock;
import net.wurstclient.SearchTags;
import net.wurstclient.events.ChatInputListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.other_feature.OtherFeature;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.util.ChatUtils;

@DontBlock
@SearchTags({"no chat reports", "NoEncryption", "no encryption",
	"NoChatSigning", "no chat signing"})
public final class NoChatReportsOtf extends OtherFeature
	implements UpdateListener, ChatInputListener
{
	private final CheckboxSetting disableSignatures =
		new CheckboxSetting("Disable signatures", true)
		{
			@Override
			public void update()
			{
				EVENTS.add(UpdateListener.class, NoChatReportsOtf.this);
			}
		};
	
	public NoChatReportsOtf()
	{
		super("NoChatReports", "description.wurst.other_feature.nochatreports");
		addSetting(disableSignatures);
		
		ClientLoginConnectionEvents.INIT.register(this::onLoginStart);
		EVENTS.add(ChatInputListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		class_634 netHandler = MC.method_1562();
		if(netHandler == null)
			return;
		
		if(isActive())
		{
			netHandler.field_40799 = null;
			netHandler.field_39808 = class_7610.class_7612.field_40694;
			
		}else if(netHandler.field_40799 == null)
			MC.method_43590().method_46522()
				.thenAcceptAsync(optional -> optional
					.ifPresent(profileKeys -> netHandler.field_40799 =
						class_7818.method_46273(profileKeys)),
					MC);
		
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onReceivedMessage(ChatInputEvent event)
	{
		if(!isActive())
			return;
		
		class_2561 originalText = event.getComponent();
		if(!(originalText
			.method_10851() instanceof class_2588 trContent))
			return;
		
		if(!trContent.method_11022().equals("chat.disabled.missingProfileKey"))
			return;
		
		event.cancel();
		
		class_2558 clickEvent = new class_2558(class_2558.class_2559.field_11749,
			"https://www.wurstclient.net/chat-disabled-mpk/");
		class_2568 hoverEvent = new class_2568(class_2568.class_5247.field_24342,
			class_2561.method_43470("Original message: ").method_10852(originalText));
		
		ChatUtils.component(class_2561.method_43470(
			"The server is refusing to let you chat without enabling chat reports. Click \u00a7nhere\u00a7r to learn more.")
			.method_27694(
				s -> s.method_10958(clickEvent).method_10949(hoverEvent)));
	}
	
	private void onLoginStart(class_635 handler,
		class_310 client)
	{
		EVENTS.add(UpdateListener.class, NoChatReportsOtf.this);
	}
	
	public class_7591 modifyIndicator(class_2561 message,
		class_7469 signature, class_7591 indicator)
	{
		if(!WURST.isEnabled() || MC.method_1542())
			return indicator;
		
		if(indicator != null || signature == null)
			return indicator;
		
		return new class_7591(0xE84F58, class_7592.field_39763,
			class_2561.method_43470(ChatUtils.WURST_PREFIX + "\u00a7cReportable\u00a7r - "
				+ WURST.translate(
					"description.wurst.nochatreports.message_is_reportable")),
			"Reportable");
	}
	
	@Override
	public boolean isEnabled()
	{
		return disableSignatures.isChecked();
	}
	
	public boolean isActive()
	{
		return isEnabled() && WURST.isEnabled() && !MC.method_1542();
	}
	
	@Override
	public String getPrimaryAction()
	{
		return WURST.translate("button.wurst.nochatreports."
			+ (isEnabled() ? "re-enable_signatures" : "disable_signatures"));
	}
	
	@Override
	public void doPrimaryAction()
	{
		disableSignatures.setChecked(!disableSignatures.isChecked());
	}
	
	@Override
	public Category getCategory()
	{
		return Category.CHAT;
	}
	
	// See ChatHudMixin, ClientPlayNetworkHandlerMixin.onOnServerMetadata(),
	// MinecraftClientMixin.onGetProfileKeys()
}
