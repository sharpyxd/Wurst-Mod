/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.IllegalFormatException;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_1074;
import net.minecraft.class_1078;
import net.minecraft.class_2477;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_4013;
import com.google.common.collect.Lists;

public class WurstTranslator implements class_4013
{
	private final WurstClient wurst = WurstClient.INSTANCE;
	private class_1078 mcEnglish;
	
	private Map<String, String> currentLangStrings = Map.of();
	private Map<String, String> englishOnlyStrings = Map.of();
	
	@Override
	public void method_14491(class_3300 manager)
	{
		mcEnglish = class_1078.method_4675(manager,
			Lists.newArrayList("en_us"), false);
		
		HashMap<String, String> currentLangStrings = new HashMap<>();
		loadTranslations(manager, getCurrentLangCodes(),
			currentLangStrings::put);
		this.currentLangStrings =
			Collections.unmodifiableMap(currentLangStrings);
		
		HashMap<String, String> englishOnlyStrings = new HashMap<>();
		loadTranslations(manager, List.of("en_us"), englishOnlyStrings::put);
		this.englishOnlyStrings =
			Collections.unmodifiableMap(englishOnlyStrings);
	}
	
	/**
	 * Translates the given key with the given args into the current language,
	 * or into English if the "Force English" setting is enabled. Both Wurst and
	 * vanilla translations are supported.
	 */
	public String translate(String key, Object... args)
	{
		// Forced English
		if(isForcedEnglish())
			return translateEnglish(key, args);
		
		// Wurst translation
		String string = currentLangStrings.get(key);
		if(string != null)
			try
			{
				return String.format(string, args);
				
			}catch(IllegalFormatException e)
			{
				return key;
			}
		
		// Vanilla translation
		return translateMc(key, args);
	}
	
	/**
	 * Translates the given key with the given args into English, regardless of
	 * the current language. Both Wurst and vanilla translations are supported.
	 */
	public String translateEnglish(String key, Object... args)
	{
		String string = englishOnlyStrings.get(key);
		if(string == null)
			string = mcEnglish.method_48307(key);
		
		try
		{
			return String.format(string, args);
			
		}catch(IllegalFormatException e)
		{
			return key;
		}
	}
	
	/**
	 * Translates the given key with the given args into the current language,
	 * or into English if the "Force English" setting is enabled, using only
	 * Minecraft's own translations.
	 *
	 * @apiNote This method differs from
	 *          {@link class_1074#method_4662(String, Object...)} in that it does not
	 *          return "Format error" if the key contains a percent sign.
	 */
	public String translateMc(String key, Object... args)
	{
		if(class_1074.method_4663(key))
			return class_1074.method_4662(key, args);
		
		return key;
	}
	
	/**
	 * Translates the given key with the given args into English, regardless of
	 * the current language, using only Minecraft's own translations.
	 *
	 * @apiNote This method differs from
	 *          {@link class_1074#method_4662(String, Object...)} in that it does not
	 *          return "Format error" if the key contains a percent sign.
	 */
	public String translateMcEnglish(String key, Object... args)
	{
		try
		{
			return String.format(mcEnglish.method_48307(key), args);
			
		}catch(IllegalFormatException e)
		{
			return key;
		}
	}
	
	public boolean isForcedEnglish()
	{
		return wurst.getOtfs().translationsOtf.getForceEnglish().isChecked();
	}
	
	/**
	 * Returns a translation storage for Minecraft's English strings, regardless
	 * of the current language. Does not include any of Wurst's translations.
	 */
	public class_1078 getMcEnglish()
	{
		return mcEnglish;
	}
	
	public Map<String, String> getMinecraftsCurrentLanguage()
	{
		return currentLangStrings;
	}
	
	public Map<String, String> getWurstsCurrentLanguage()
	{
		return isForcedEnglish() ? englishOnlyStrings
			: getMinecraftsCurrentLanguage();
	}
	
	private ArrayList<String> getCurrentLangCodes()
	{
		// Weird bug: Some users have their language set to "en_US" instead of
		// "en_us" for some reason. Last seen in 1.21.
		String mainLangCode = class_310.method_1551().method_1526()
			.method_4669().toLowerCase();
		
		ArrayList<String> langCodes = new ArrayList<>();
		langCodes.add("en_us");
		if(!"en_us".equals(mainLangCode))
			langCodes.add(mainLangCode);
		
		return langCodes;
	}
	
	private void loadTranslations(class_3300 manager,
		Iterable<String> langCodes, BiConsumer<String, String> entryConsumer)
	{
		for(String langCode : langCodes)
		{
			String langFilePath = "translations/" + langCode + ".json";
			class_2960 langId = class_2960.method_60655("wurst", langFilePath);
			
			for(class_3298 resource : manager.method_14489(langId))
				try(InputStream stream = resource.method_14482())
				{
					class_2477.method_29425(stream, entryConsumer);
					
				}catch(IOException e)
				{
					System.out.println("Failed to load translations for "
						+ langCode + " from pack " + resource.method_14480());
					e.printStackTrace();
				}
		}
	}
}
