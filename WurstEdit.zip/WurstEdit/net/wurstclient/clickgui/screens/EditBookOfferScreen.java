/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.clickgui.screens;

import org.lwjgl.glfw.GLFW;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9636;
import net.wurstclient.hacks.autolibrarian.BookOffer;
import net.wurstclient.settings.BookOffersSetting;
import net.wurstclient.util.MathUtils;
import net.wurstclient.util.RenderUtils;

public final class EditBookOfferScreen extends class_437
{
	private final class_437 prevScreen;
	private final BookOffersSetting bookOffers;
	
	private class_342 levelField;
	private class_4185 levelPlusButton;
	private class_4185 levelMinusButton;
	
	private class_342 priceField;
	private class_4185 pricePlusButton;
	private class_4185 priceMinusButton;
	
	private class_4185 saveButton;
	private class_4185 cancelButton;
	
	private BookOffer offerToSave;
	private int index;
	private boolean alreadyAdded;
	
	public EditBookOfferScreen(class_437 prevScreen, BookOffersSetting bookOffers,
		int index)
	{
		super(class_2561.method_43470(""));
		this.prevScreen = prevScreen;
		this.bookOffers = bookOffers;
		this.index = index;
		offerToSave = bookOffers.getOffers().get(index);
	}
	
	@Override
	public void method_25426()
	{
		levelField = new class_342(field_22787.field_1772, field_22789 / 2 - 32,
			110, 28, 12, class_2561.method_43470(""));
		method_25429(levelField);
		levelField.method_1880(2);
		levelField.method_1890(t -> {
			if(t.isEmpty())
				return true;
			
			if(!MathUtils.isInteger(t))
				return false;
			
			int level = Integer.parseInt(t);
			if(level < 1 || level > 10)
				return false;
			
			if(offerToSave == null)
				return true;
			
			class_1887 enchantment = offerToSave.getEnchantment();
			return level <= enchantment.method_8183();
		});
		levelField.method_1863(t -> {
			if(!MathUtils.isInteger(t))
				return;
			
			int level = Integer.parseInt(t);
			updateLevel(level, false);
		});
		
		priceField = new class_342(field_22787.field_1772, field_22789 / 2 - 32,
			126, 28, 12, class_2561.method_43470(""));
		method_25429(priceField);
		priceField.method_1880(2);
		priceField.method_1890(t -> t.isEmpty() || MathUtils.isInteger(t)
			&& Integer.parseInt(t) >= 1 && Integer.parseInt(t) <= 64);
		priceField.method_1863(t -> {
			if(!MathUtils.isInteger(t))
				return;
			
			int price = Integer.parseInt(t);
			updatePrice(price, false);
		});
		
		method_37063(levelPlusButton =
			class_4185.method_46430(class_2561.method_43470("+"), b -> updateLevel(1, true))
				.method_46434(field_22789 / 2 + 2, 110, 20, 12).method_46431());
		levelPlusButton.field_22763 = false;
		
		method_37063(levelMinusButton =
			class_4185.method_46430(class_2561.method_43470("-"), b -> updateLevel(-1, true))
				.method_46434(field_22789 / 2 + 26, 110, 20, 12).method_46431());
		levelMinusButton.field_22763 = false;
		
		method_37063(pricePlusButton =
			class_4185.method_46430(class_2561.method_43470("+"), b -> updatePrice(1, true))
				.method_46434(field_22789 / 2 + 2, 126, 20, 12).method_46431());
		pricePlusButton.field_22763 = false;
		
		method_37063(priceMinusButton =
			class_4185.method_46430(class_2561.method_43470("-"), b -> updatePrice(-1, true))
				.method_46434(field_22789 / 2 + 26, 126, 20, 12).method_46431());
		priceMinusButton.field_22763 = false;
		
		method_37063(
			saveButton = class_4185.method_46430(class_2561.method_43470("Save"), b -> {
				if(offerToSave == null || !offerToSave.isFullyValid())
					return;
				
				bookOffers.replace(index, offerToSave);
				field_22787.method_1507(prevScreen);
			}).method_46434(field_22789 / 2 - 102, field_22790 / 3 * 2, 100, 20).method_46431());
		saveButton.field_22763 = false;
		
		method_37063(cancelButton = class_4185
			.method_46430(class_2561.method_43470("Cancel"), b -> field_22787.method_1507(prevScreen))
			.method_46434(field_22789 / 2 + 2, field_22790 / 3 * 2, 100, 20).method_46431());
		
		updateSelectedOffer(offerToSave);
	}
	
	private void updateLevel(int i, boolean offset)
	{
		if(offerToSave == null)
			return;
		
		String id = offerToSave.id();
		int level = offset ? offerToSave.level() + i : i;
		int price = offerToSave.price();
		
		class_1887 enchantment = offerToSave.getEnchantment();
		if(level < 1 || level > enchantment.method_8183())
			return;
		
		updateSelectedOffer(new BookOffer(id, level, price));
	}
	
	private void updatePrice(int i, boolean offset)
	{
		if(offerToSave == null)
			return;
		
		String id = offerToSave.id();
		int level = offerToSave.level();
		int price = offset ? offerToSave.price() + i : i;
		
		if(price < 1 || price > 64)
			return;
		
		updateSelectedOffer(new BookOffer(id, level, price));
	}
	
	private void updateSelectedOffer(BookOffer offer)
	{
		offerToSave = offer;
		alreadyAdded =
			offer != null && !offer.equals(bookOffers.getOffers().get(index))
				&& bookOffers.contains(offer);
		saveButton.field_22763 = offer != null && !alreadyAdded;
		
		if(offer == null)
		{
			if(!levelField.method_1882().isEmpty())
				levelField.method_1852("");
			
			if(!priceField.method_1882().isEmpty())
				priceField.method_1852("");
			
		}else
		{
			String level = "" + offer.level();
			if(!levelField.method_1882().equals(level))
				levelField.method_1852(level);
			
			String price = "" + offer.price();
			if(!priceField.method_1882().equals(price))
				priceField.method_1852(price);
		}
	}
	
	@Override
	public boolean method_25402(double mouseX, double mouseY, int mouseButton)
	{
		boolean childClicked = super.method_25402(mouseX, mouseY, mouseButton);
		
		levelField.method_25402(mouseX, mouseY, mouseButton);
		priceField.method_25402(mouseX, mouseY, mouseButton);
		
		if(mouseButton == GLFW.GLFW_MOUSE_BUTTON_4)
			cancelButton.method_25306();
		
		return childClicked;
	}
	
	@Override
	public boolean method_25404(int keyCode, int scanCode, int int_3)
	{
		switch(keyCode)
		{
			case GLFW.GLFW_KEY_ENTER:
			if(saveButton.field_22763)
				saveButton.method_25306();
			break;
			
			case GLFW.GLFW_KEY_ESCAPE:
			cancelButton.method_25306();
			break;
			
			default:
			break;
		}
		
		return super.method_25404(keyCode, scanCode, int_3);
	}
	
	@Override
	public void method_25393()
	{
		levelPlusButton.field_22763 = offerToSave != null
			&& offerToSave.level() < offerToSave.getEnchantment().method_8183();
		levelMinusButton.field_22763 =
			offerToSave != null && offerToSave.level() > 1;
		
		pricePlusButton.field_22763 =
			offerToSave != null && offerToSave.price() < 64;
		priceMinusButton.field_22763 =
			offerToSave != null && offerToSave.price() > 1;
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		class_4587 matrixStack = context.method_51448();
		method_25420(context, mouseX, mouseY, partialTicks);
		
		matrixStack.method_22903();
		matrixStack.method_46416(0, 0, 300);
		
		class_327 tr = field_22787.field_1772;
		String titleText = "Edit Book Offer";
		context.method_25300(tr, titleText, field_22789 / 2, 12,
			0xffffff);
		
		int x = field_22789 / 2 - 100;
		int y = 64;
		
		class_1792 item = class_7923.field_41178.method_10223(class_2960.method_60654("enchanted_book"));
		class_1799 stack = new class_1799(item);
		RenderUtils.drawItem(context, stack, x + 1, y + 1, true);
		
		BookOffer bookOffer = offerToSave;
		String name = bookOffer.getEnchantmentNameWithLevel();
		
		class_6880<class_1887> enchantment =
			bookOffer.getEnchantmentEntry().get();
		int nameColor =
			enchantment.method_40220(class_9636.field_51551) ? 0xff5555 : 0xffffff;
		context.method_25303(tr, name, x + 28, y, nameColor);
		
		context.method_51433(tr, bookOffer.id(), x + 28, y + 9, 0xa0a0a0, false);
		
		String price;
		if(bookOffer.price() >= 64)
			price = "any price";
		else
		{
			price = "max " + bookOffer.price();
			RenderUtils.drawItem(context, new class_1799(class_1802.field_8687),
				x + 28 + tr.method_1727(price), y + 16, false);
		}
		
		context.method_51433(tr, price, x + 28, y + 18, 0xa0a0a0, false);
		
		levelField.method_25394(context, mouseX, mouseY, partialTicks);
		priceField.method_25394(context, mouseX, mouseY, partialTicks);
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
		
		matrixStack.method_46416(field_22789 / 2 - 100, 112, 0);
		
		context.method_25303(tr, "Level:", 0, 0, 0xf0f0f0);
		context.method_25303(tr, "Max price:", 0, 16, 0xf0f0f0);
		
		if(alreadyAdded && offerToSave != null)
		{
			String errorText = offerToSave.getEnchantmentNameWithLevel()
				+ " is already on your list!";
			context.method_25303(tr, errorText, 0, 32, 0xff5555);
		}
		
		matrixStack.method_22909();
		
		RenderUtils.drawItem(context, new class_1799(class_1802.field_8687),
			field_22789 / 2 - 16, 126, false);
	}
	
	@Override
	public boolean method_25421()
	{
		return false;
	}
	
	@Override
	public boolean method_25422()
	{
		return false;
	}
}
