/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.clickgui.components;

import org.joml.Quaternionf;
import net.minecraft.class_1297;
import net.minecraft.class_1421;
import net.minecraft.class_1429;
import net.minecraft.class_1480;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.wurstclient.clickgui.ClickGui;
import net.wurstclient.clickgui.ClickGuiIcons;
import net.wurstclient.clickgui.Component;
import net.wurstclient.hacks.RadarHack;
import net.wurstclient.util.EntityUtils;
import net.wurstclient.util.RenderUtils;

public final class RadarComponent extends Component
{
	private final RadarHack hack;
	
	public RadarComponent(RadarHack hack)
	{
		this.hack = hack;
		setWidth(getDefaultWidth());
		setHeight(getDefaultHeight());
	}
	
	@Override
	public void render(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		// Can't make this a field because RadarComponent is initialized earlier
		// than ClickGui.
		ClickGui gui = WURST.getGui();
		
		int x1 = getX();
		int x2 = x1 + getWidth();
		int y1 = getY();
		int y2 = y1 + getHeight();
		float middleX = (x1 + x2) / 2F;
		float middleY = (y1 + y2) / 2F;
		
		// tooltip
		if(isHovering(mouseX, mouseY))
			gui.setTooltip("");
		
		// background
		context.method_25294(x1, y1, x2, y2,
			RenderUtils.toIntColor(gui.getBgColor(), gui.getOpacity()));
		
		class_4587 matrixStack = context.method_51448();
		matrixStack.method_22903();
		matrixStack.method_46416(middleX, middleY, 0);
		
		class_746 player = MC.field_1724;
		if(!hack.isRotateEnabled())
			matrixStack.method_22907(new Quaternionf().rotationZ(
				(180 + player.method_36454()) * class_3532.field_29847));
		
		// arrow
		ClickGuiIcons.drawRadarArrow(context, -2, -2, 2, 2);
		
		matrixStack.method_22909();
		class_243 lerpedPlayerPos = EntityUtils.getLerpedPos(player, partialTicks);
		
		// points
		for(class_1297 e : hack.getEntities())
		{
			class_243 lerpedEntityPos = EntityUtils.getLerpedPos(e, partialTicks);
			double diffX = lerpedEntityPos.field_1352 - lerpedPlayerPos.field_1352;
			double diffZ = lerpedEntityPos.field_1350 - lerpedPlayerPos.field_1350;
			double distance = Math.sqrt(diffX * diffX + diffZ * diffZ)
				* (getWidth() * 0.5 / hack.getRadius());
			double neededRotation = Math.toDegrees(Math.atan2(diffZ, diffX));
			double angle;
			if(hack.isRotateEnabled())
				angle = Math.toRadians(player.method_36454() - neededRotation - 90);
			else
				angle = Math.toRadians(180 - neededRotation - 90);
			double renderX = Math.sin(angle) * distance;
			double renderY = Math.cos(angle) * distance;
			
			if(Math.abs(renderX) > getWidth() / 2.0
				|| Math.abs(renderY) > getHeight() / 2.0)
				continue;
			
			float ex1 = middleX + (float)renderX - 0.5F;
			float ex2 = middleX + (float)renderX + 0.5F;
			float ey1 = middleY + (float)renderY - 0.5F;
			float ey2 = middleY + (float)renderY + 0.5F;
			RenderUtils.fill2D(context, ex1, ey1, ex2, ey2, getEntityColor(e));
		}
	}
	
	private int getEntityColor(class_1297 e)
	{
		if(WURST.getFriends().isFriend(e))
			return 0xFF0000FF;
		if(e instanceof class_1657)
			return 0xFFFF0000;
		if(e instanceof class_1569)
			return 0xFFFF8000;
		if(e instanceof class_1429 || e instanceof class_1421
			|| e instanceof class_1480)
			return 0xFF00FF00;
		return 0xFF808080;
	}
	
	@Override
	public int getDefaultWidth()
	{
		return 96;
	}
	
	@Override
	public int getDefaultHeight()
	{
		return 96;
	}
}
