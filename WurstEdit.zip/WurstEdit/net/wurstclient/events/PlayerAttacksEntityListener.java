/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.events;

import java.util.ArrayList;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_636;
import net.wurstclient.event.Event;
import net.wurstclient.event.Listener;

/**
 * Fired at the beginning of
 * {@link class_636#method_2918(class_1657, class_1297)}.
 */
public interface PlayerAttacksEntityListener extends Listener
{
	/**
	 * Fired at the beginning of
	 * {@link class_636#method_2918(class_1657, class_1297)}.
	 */
	public void onPlayerAttacksEntity(class_1297 target);
	
	/**
	 * Fired at the beginning of
	 * {@link class_636#method_2918(class_1657, class_1297)}.
	 */
	public static class PlayerAttacksEntityEvent
		extends Event<PlayerAttacksEntityListener>
	{
		private final class_1297 target;
		
		public PlayerAttacksEntityEvent(class_1297 target)
		{
			this.target = target;
		}
		
		@Override
		public void fire(ArrayList<PlayerAttacksEntityListener> listeners)
		{
			for(PlayerAttacksEntityListener listener : listeners)
				listener.onPlayerAttacksEntity(target);
		}
		
		@Override
		public Class<PlayerAttacksEntityListener> getListenerType()
		{
			return PlayerAttacksEntityListener.class;
		}
	}
}
