/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.wurstclient.WurstClient;
import net.wurstclient.mixinterface.IKeyBinding;

@Mixin(class_304.class)
public abstract class KeyBindingMixin implements IKeyBinding
{
	@Shadow
	private class_3675.class_306 boundKey;
	
	@Override
	@Unique
	@Deprecated // use IKeyBinding.resetPressedState() instead
	public void wurst_resetPressedState()
	{
		long handle = WurstClient.MC.method_22683().method_4490();
		int code = boundKey.method_1444();
		
		if(boundKey.method_1442() == class_3675.class_307.field_1672)
			setPressed(GLFW.glfwGetMouseButton(handle, code) == 1);
		else
			setPressed(class_3675.method_15987(handle, code));
	}
	
	@Override
	@Unique
	@Deprecated // use IKeyBinding.simulatePress() instead
	public void wurst_simulatePress(boolean pressed)
	{
		class_310 mc = WurstClient.MC;
		long window = mc.method_22683().method_4490();
		int action = pressed ? 1 : 0;
		
		switch(boundKey.method_1442())
		{
			case field_1668:
			mc.field_1774.method_1466(window, boundKey.method_1444(), 0, action, 0);
			break;
			
			case field_1671:
			mc.field_1774.method_1466(window, GLFW.GLFW_KEY_UNKNOWN, boundKey.method_1444(),
				action, 0);
			break;
			
			case field_1672:
			mc.field_1729.method_1601(window, boundKey.method_1444(), action, 0);
			break;
			
			default:
			System.out
				.println("Unknown keybinding type: " + boundKey.method_1442());
			break;
		}
	}
	
	@Override
	@Shadow
	public abstract void setPressed(boolean pressed);
}
