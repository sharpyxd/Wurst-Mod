/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_4267;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_642;
import net.wurstclient.WurstClient;
import net.wurstclient.mixinterface.IMultiplayerScreen;
import net.wurstclient.serverfinder.CleanUpScreen;
import net.wurstclient.serverfinder.ServerFinderScreen;
import net.wurstclient.util.LastServerRememberer;

@Mixin(class_500.class)
public class MultiplayerScreenMixin extends class_437 implements IMultiplayerScreen
{
	@Shadow
	protected class_4267 serverListWidget;
	
	private class_4185 lastServerButton;
	
	private MultiplayerScreenMixin(WurstClient wurst, class_2561 title)
	{
		super(title);
	}
	
	@Inject(at = @At("TAIL"), method = "init()V")
	private void onInit(CallbackInfo ci)
	{
		if(!WurstClient.INSTANCE.isEnabled())
			return;
		
		lastServerButton = method_37063(class_4185
			.method_46430(class_2561.method_43470("Last Server"),
				b -> LastServerRememberer
					.joinLastServer((class_500)(Object)this))
			.method_46434(field_22789 / 2 - 154, 10, 100, 20).method_46431());
		updateLastServerButton();
		
		method_37063(
			class_4185
				.method_46430(class_2561.method_43470("Server Finder"),
					b -> field_22787.method_1507(new ServerFinderScreen(
						(class_500)(Object)this)))
				.method_46434(field_22789 / 2 + 154 + 4, field_22790 - 54, 100, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Clean Up"),
				b -> field_22787.method_1507(
					new CleanUpScreen((class_500)(Object)this)))
			.method_46434(field_22789 / 2 + 154 + 4, field_22790 - 30, 100, 20).method_46431());
	}
	
	@Inject(at = @At("HEAD"),
		method = "connect(Lnet/minecraft/client/network/ServerInfo;)V")
	private void onConnect(class_642 entry, CallbackInfo ci)
	{
		LastServerRememberer.setLastServer(entry);
		updateLastServerButton();
	}
	
	@Unique
	private void updateLastServerButton()
	{
		if(lastServerButton == null)
			return;
		
		lastServerButton.field_22763 = LastServerRememberer.getLastServer() != null;
	}
	
	@Override
	public class_4267 getServerListSelector()
	{
		return serverListWidget;
	}
	
	@Override
	public void connectToServer(class_642 server)
	{
		connect(server);
	}
	
	@Shadow
	private void connect(class_642 entry)
	{
		
	}
}
