/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2846;
import net.minecraft.class_2846.class_2847;
import net.minecraft.class_2885;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_7204;
import net.minecraft.class_746;
import net.wurstclient.event.EventManager;
import net.wurstclient.events.BlockBreakingProgressListener.BlockBreakingProgressEvent;
import net.wurstclient.events.PlayerAttacksEntityListener.PlayerAttacksEntityEvent;
import net.wurstclient.events.StopUsingItemListener.StopUsingItemEvent;
import net.wurstclient.mixinterface.IClientPlayerInteractionManager;

@Mixin(class_636.class)
public abstract class ClientPlayerInteractionManagerMixin
	implements IClientPlayerInteractionManager
{
	@Shadow
	@Final
	private class_310 client;
	
	@Inject(at = @At(value = "INVOKE",
		target = "Lnet/minecraft/client/network/ClientPlayerEntity;getId()I",
		ordinal = 0),
		method = "updateBlockBreakingProgress(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/Direction;)Z")
	private void onPlayerDamageBlock(class_2338 pos, class_2350 direction,
		CallbackInfoReturnable<Boolean> cir)
	{
		EventManager.fire(new BlockBreakingProgressEvent(pos, direction));
	}
	
	@Inject(at = @At("HEAD"),
		method = "stopUsingItem(Lnet/minecraft/entity/player/PlayerEntity;)V")
	private void onStopUsingItem(class_1657 player, CallbackInfo ci)
	{
		EventManager.fire(StopUsingItemEvent.INSTANCE);
	}
	
	@Inject(at = @At("HEAD"),
		method = "attackEntity(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/entity/Entity;)V")
	private void onAttackEntity(class_1657 player, class_1297 target,
		CallbackInfo ci)
	{
		if(player != client.field_1724)
			return;
		
		EventManager.fire(new PlayerAttacksEntityEvent(target));
	}
	
	@Override
	public void windowClick_PICKUP(int slot)
	{
		clickSlot(0, slot, 0, class_1713.field_7790, client.field_1724);
	}
	
	@Override
	public void windowClick_QUICK_MOVE(int slot)
	{
		clickSlot(0, slot, 0, class_1713.field_7794, client.field_1724);
	}
	
	@Override
	public void windowClick_THROW(int slot)
	{
		clickSlot(0, slot, 1, class_1713.field_7795, client.field_1724);
	}
	
	@Override
	public void windowClick_SWAP(int from, int to)
	{
		clickSlot(0, from, to, class_1713.field_7791, client.field_1724);
	}
	
	@Override
	public void rightClickItem()
	{
		interactItem(client.field_1724, class_1268.field_5808);
	}
	
	@Override
	public void rightClickBlock(class_2338 pos, class_2350 side, class_243 hitVec)
	{
		class_3965 hitResult = new class_3965(hitVec, side, pos, false);
		class_1268 hand = class_1268.field_5808;
		interactBlock(client.field_1724, hand, hitResult);
		interactItem(client.field_1724, hand);
	}
	
	@Override
	public void sendPlayerActionC2SPacket(class_2847 action, class_2338 blockPos,
		class_2350 direction)
	{
		sendSequencedPacket(client.field_1687,
			i -> new class_2846(action, blockPos, direction, i));
	}
	
	@Override
	public void sendPlayerInteractBlockPacket(class_1268 hand,
		class_3965 blockHitResult)
	{
		sendSequencedPacket(client.field_1687,
			i -> new class_2885(hand, blockHitResult, i));
	}
	
	@Shadow
	private void sendSequencedPacket(class_638 world,
		class_7204 packetCreator)
	{
		
	}
	
	@Shadow
	public abstract class_1269 interactBlock(class_746 player,
		class_1268 hand, class_3965 hitResult);
	
	@Shadow
	public abstract class_1269 interactItem(class_1657 player, class_1268 hand);
	
	@Shadow
	public abstract void clickSlot(int syncId, int slotId, int button,
		class_1713 actionType, class_1657 player);
}
