/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_2561;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.wurstclient.WurstClient;
import net.wurstclient.event.EventManager;
import net.wurstclient.events.ChatOutputListener.ChatOutputEvent;

@Mixin(class_408.class)
public abstract class ChatScreenMixin extends class_437
{
	@Shadow
	protected class_342 chatField;
	
	private ChatScreenMixin(WurstClient wurst, class_2561 title)
	{
		super(title);
	}
	
	@Inject(at = @At("TAIL"), method = "init()V")
	protected void onInit(CallbackInfo ci)
	{
		if(WurstClient.INSTANCE.getHax().infiniChatHack.isEnabled())
			chatField.method_1880(Integer.MAX_VALUE);
	}
	
	@Inject(at = @At("HEAD"),
		method = "sendMessage(Ljava/lang/String;Z)V",
		cancellable = true)
	public void onSendMessage(String message, boolean addToHistory,
		CallbackInfo ci)
	{
		// Ignore empty messages just like vanilla
		if((message = normalize(message)).isEmpty())
			return;
		
		// Create and fire the chat output event
		ChatOutputEvent event = new ChatOutputEvent(message);
		EventManager.fire(event);
		
		// If the event hasn't been modified or cancelled,
		// let the vanilla method handle the message
		boolean cancelled = event.isCancelled();
		if(!cancelled && !event.isModified())
			return;
		
		// Otherwise, cancel the vanilla method and handle the message here
		ci.cancel();
		
		// Add the message to history, even if it was cancelled
		// Otherwise the up/down arrows won't work correctly
		String newMessage = event.getMessage();
		if(addToHistory)
			field_22787.field_1705.method_1743().method_1803(newMessage);
		
		// If the event isn't cancelled, send the modified message
		if(!cancelled)
			if(newMessage.startsWith("/"))
				field_22787.field_1724.field_3944
					.method_45730(newMessage.substring(1));
			else
				field_22787.field_1724.field_3944.method_45729(newMessage);
	}
	
	@Shadow
	public abstract String normalize(String chatText);
}
