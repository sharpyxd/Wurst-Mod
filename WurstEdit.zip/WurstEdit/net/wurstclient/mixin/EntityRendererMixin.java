/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_327.class_6415;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_897;
import net.minecraft.class_898;
import net.minecraft.class_9064;
import net.wurstclient.WurstClient;
import net.wurstclient.hacks.NameTagsHack;

@Mixin(class_897.class)
public abstract class EntityRendererMixin<T extends class_1297>
{
	@Shadow
	@Final
	protected class_898 dispatcher;
	
	@Inject(at = @At("HEAD"),
		method = "renderLabelIfPresent(Lnet/minecraft/entity/Entity;Lnet/minecraft/text/Text;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;IF)V",
		cancellable = true)
	private void onRenderLabelIfPresent(T entity, class_2561 text,
		class_4587 matrixStack, class_4597 vertexConsumerProvider,
		int i, float tickDelta, CallbackInfo ci)
	{
		// add HealthTags info
		if(entity instanceof class_1309)
			text = WurstClient.INSTANCE.getHax().healthTagsHack
				.addHealth((class_1309)entity, text);
		
		// do NameTags adjustments
		wurstRenderLabelIfPresent(entity, text, matrixStack,
			vertexConsumerProvider, i, tickDelta);
		ci.cancel();
	}
	
	/**
	 * Copy of renderLabelIfPresent() since calling the original would result in
	 * an infinite loop. Also makes it easier to modify.
	 */
	protected void wurstRenderLabelIfPresent(T entity, class_2561 text,
		class_4587 matrices, class_4597 vertexConsumers, int light,
		float tickDelta)
	{
		NameTagsHack nameTags = WurstClient.INSTANCE.getHax().nameTagsHack;
		
		// disable distance limit if configured in NameTags
		double distanceSq = dispatcher.method_23168(entity);
		if(distanceSq > 4096 && !nameTags.isUnlimitedRange())
			return;
		
		// get attachment point
		class_243 attVec = entity.method_56072().method_55675(
			class_9064.field_47745, 0, entity.method_5705(tickDelta));
		if(attVec == null)
			return;
		
		// disable sneaking changes if NameTags is enabled
		boolean notSneaky = !entity.method_21751() || nameTags.isEnabled();
		
		int labelY = "deadmau5".equals(text.getString()) ? -10 : 0;
		
		matrices.method_22903();
		matrices.method_22904(attVec.field_1352, attVec.field_1351 + 0.5, attVec.field_1350);
		matrices.method_22907(dispatcher.method_24197());
		
		// adjust scale if NameTags is enabled
		float scale = 0.025F * nameTags.getScale();
		if(nameTags.isEnabled())
		{
			double distance = WurstClient.MC.field_1724.method_5739(entity);
			if(distance > 10)
				scale *= distance / 10;
		}
		matrices.method_22905(scale, -scale, scale);
		
		Matrix4f matrix = matrices.method_23760().method_23761();
		float bgOpacity =
			WurstClient.MC.field_1690.method_19343(0.25F);
		int bgColor = (int)(bgOpacity * 255F) << 24;
		class_327 tr = getTextRenderer();
		float labelX = -tr.method_27525(text) / 2;
		
		// adjust layers if using NameTags in see-through mode
		class_6415 bgLayer = notSneaky && !nameTags.isSeeThrough()
			? class_6415.field_33994 : class_6415.field_33993;
		class_6415 textLayer = nameTags.isSeeThrough()
			? class_6415.field_33994 : class_6415.field_33993;
		
		// draw background
		tr.method_30882(text, labelX, labelY, 0x20FFFFFF, false, matrix,
			vertexConsumers, bgLayer, bgColor, light);
		
		// draw text
		if(notSneaky)
			tr.method_30882(text, labelX, labelY, 0xFFFFFFFF, false, matrix,
				vertexConsumers, textLayer, 0, light);
		
		matrices.method_22909();
	}
	
	@Shadow
	public abstract class_327 getTextRenderer();
}
