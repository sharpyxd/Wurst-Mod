/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1074;
import net.minecraft.class_2561;
import net.minecraft.class_339;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_447;
import net.wurstclient.WurstClient;

@Mixin(class_447.class)
public abstract class StatsScreenMixin extends class_437
{
	@Unique
	private class_4185 toggleWurstButton;
	
	private StatsScreenMixin(WurstClient wurst, class_2561 title)
	{
		super(title);
	}
	
	@Inject(at = @At("TAIL"), method = "createButtons()V")
	private void onCreateButtons(CallbackInfo ci)
	{
		if(WurstClient.INSTANCE.getOtfs().disableOtf.shouldHideEnableButton())
			return;
		
		toggleWurstButton = class_4185
			.method_46430(class_2561.method_43470(""), this::toggleWurst).method_46432(150).method_46431();
		
		updateWurstButtonText(toggleWurstButton);
		method_37063(toggleWurstButton);
	}
	
	@Inject(at = @At("TAIL"), method = "initTabNavigation()V")
	private void onInitTabNavigation(CallbackInfo ci)
	{
		if(toggleWurstButton == null)
			return;
		
		class_339 doneButton = wurst_getDoneButton();
		doneButton.method_46421(field_22789 / 2 + 2);
		doneButton.method_25358(150);
		
		toggleWurstButton.method_48229(field_22789 / 2 - 152, doneButton.method_46427());
	}
	
	@Unique
	private class_339 wurst_getDoneButton()
	{
		for(class_339 button : Screens.getButtons(this))
			if(button.method_25369().getString()
				.equals(class_1074.method_4662("gui.done")))
				return button;
			
		throw new IllegalStateException(
			"Can't find the done button on the statistics screen.");
	}
	
	@Unique
	private void toggleWurst(class_4185 button)
	{
		WurstClient wurst = WurstClient.INSTANCE;
		wurst.setEnabled(!wurst.isEnabled());
		
		updateWurstButtonText(button);
	}
	
	@Unique
	private void updateWurstButtonText(class_4185 button)
	{
		WurstClient wurst = WurstClient.INSTANCE;
		String text = (wurst.isEnabled() ? "Disable" : "Enable") + " Wurst";
		button.method_25355(class_2561.method_43470(text));
	}
}
