/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.wurstclient.Category;
import net.wurstclient.ai.PathFinder;
import net.wurstclient.ai.PathPos;
import net.wurstclient.ai.PathProcessor;
import net.wurstclient.commands.PathCmd;
import net.wurstclient.events.RenderListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.DontSaveState;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.AttackSpeedSliderSetting;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.PauseAttackOnContainersSetting;
import net.wurstclient.settings.SwingHandSetting;
import net.wurstclient.settings.SwingHandSetting.SwingHand;
import net.wurstclient.settings.filterlists.EntityFilterList;
import net.wurstclient.settings.filters.*;
import net.wurstclient.util.EntityUtils;
import net.wurstclient.util.FakePlayerEntity;

@DontSaveState
public final class ProtectHack extends Hack
	implements UpdateListener, RenderListener
{
	private final AttackSpeedSliderSetting speed =
		new AttackSpeedSliderSetting();
	
	private final SwingHandSetting swingHand = new SwingHandSetting(
		SwingHandSetting.genericCombatDescription(this), SwingHand.CLIENT);
	
	private final CheckboxSetting useAi =
		new CheckboxSetting("Use AI (experimental)", false);
	
	private final PauseAttackOnContainersSetting pauseOnContainers =
		new PauseAttackOnContainersSetting(true);
	
	private final EntityFilterList entityFilters =
		new EntityFilterList(FilterPlayersSetting.genericCombat(false),
			FilterSleepingSetting.genericCombat(false),
			FilterFlyingSetting.genericCombat(0),
			FilterHostileSetting.genericCombat(false),
			FilterNeutralSetting
				.genericCombat(AttackDetectingEntityFilter.Mode.OFF),
			FilterPassiveSetting.genericCombat(false),
			FilterPassiveWaterSetting.genericCombat(false),
			FilterBabiesSetting.genericCombat(false),
			FilterBatsSetting.genericCombat(false),
			FilterSlimesSetting.genericCombat(false),
			FilterPetsSetting.genericCombat(false),
			FilterVillagersSetting.genericCombat(false),
			FilterZombieVillagersSetting.genericCombat(false),
			FilterGolemsSetting.genericCombat(false),
			FilterPiglinsSetting
				.genericCombat(AttackDetectingEntityFilter.Mode.OFF),
			FilterZombiePiglinsSetting
				.genericCombat(FilterZombiePiglinsSetting.Mode.OFF),
			FilterEndermenSetting
				.genericCombat(AttackDetectingEntityFilter.Mode.OFF),
			FilterShulkersSetting.genericCombat(false),
			FilterAllaysSetting.genericCombat(false),
			FilterInvisibleSetting.genericCombat(false),
			FilterNamedSetting.genericCombat(false),
			FilterShulkerBulletSetting.genericCombat(false),
			FilterArmorStandsSetting.genericCombat(false),
			FilterCrystalsSetting.genericCombat(true));
	
	private EntityPathFinder pathFinder;
	private PathProcessor processor;
	private int ticksProcessing;
	
	private class_1297 friend;
	private class_1297 enemy;
	
	private double distanceF = 2;
	private double distanceE = 3;
	
	public ProtectHack()
	{
		super("Protect");
		
		setCategory(Category.COMBAT);
		addSetting(speed);
		addSetting(swingHand);
		addSetting(useAi);
		addSetting(pauseOnContainers);
		
		entityFilters.forEach(this::addSetting);
	}
	
	@Override
	public String getRenderName()
	{
		if(friend != null)
			return "Protecting " + friend.method_5477().getString();
		return "Protect";
	}
	
	@Override
	protected void onEnable()
	{
		WURST.getHax().followHack.setEnabled(false);
		WURST.getHax().tunnellerHack.setEnabled(false);
		
		// disable other killauras
		WURST.getHax().aimAssistHack.setEnabled(false);
		WURST.getHax().clickAuraHack.setEnabled(false);
		WURST.getHax().crystalAuraHack.setEnabled(false);
		WURST.getHax().fightBotHack.setEnabled(false);
		WURST.getHax().killauraLegitHack.setEnabled(false);
		WURST.getHax().killauraHack.setEnabled(false);
		WURST.getHax().multiAuraHack.setEnabled(false);
		WURST.getHax().triggerBotHack.setEnabled(false);
		WURST.getHax().tpAuraHack.setEnabled(false);
		
		// set friend
		if(friend == null)
		{
			Stream<class_1297> stream = StreamSupport
				.stream(MC.field_1687.method_18112().spliterator(), true)
				.filter(class_1309.class::isInstance)
				.filter(
					e -> !e.method_31481() && ((class_1309)e).method_6032() > 0)
				.filter(e -> e != MC.field_1724)
				.filter(e -> !(e instanceof FakePlayerEntity));
			friend = stream
				.min(Comparator
					.comparingDouble(e -> MC.field_1724.method_5858(e)))
				.orElse(null);
		}
		
		pathFinder = new EntityPathFinder(friend, distanceF);
		
		speed.resetTimer();
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(RenderListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		
		pathFinder = null;
		processor = null;
		ticksProcessing = 0;
		PathProcessor.releaseControls();
		
		enemy = null;
		
		if(friend != null)
		{
			MC.field_1690.field_1894.method_23481(false);
			friend = null;
		}
	}
	
	@Override
	public void onUpdate()
	{
		speed.updateTimer();
		
		if(pauseOnContainers.shouldPause())
			return;
		
		// check if player died, friend died or disappeared
		if(friend == null || friend.method_31481()
			|| !(friend instanceof class_1309)
			|| ((class_1309)friend).method_6032() <= 0
			|| MC.field_1724.method_6032() <= 0)
		{
			friend = null;
			enemy = null;
			setEnabled(false);
			return;
		}
		
		// set enemy
		Stream<class_1297> stream = EntityUtils.getAttackableEntities()
			.filter(e -> MC.field_1724.method_5858(e) <= 36)
			.filter(e -> e != friend);
		
		stream = entityFilters.applyTo(stream);
		
		enemy = stream
			.min(
				Comparator.comparingDouble(e -> MC.field_1724.method_5858(e)))
			.orElse(null);
		
		class_1297 target =
			enemy == null || MC.field_1724.method_5858(friend) >= 24 * 24
				? friend : enemy;
		
		double distance = target == enemy ? distanceE : distanceF;
		
		if(useAi.isChecked())
		{
			// reset pathfinder
			if((processor == null || processor.isDone() || ticksProcessing >= 10
				|| !pathFinder.isPathStillValid(processor.getIndex()))
				&& (pathFinder.isDone() || pathFinder.isFailed()))
			{
				pathFinder = new EntityPathFinder(target, distance);
				processor = null;
				ticksProcessing = 0;
			}
			
			// find path
			if(!pathFinder.isDone() && !pathFinder.isFailed())
			{
				PathProcessor.lockControls();
				WURST.getRotationFaker()
					.faceVectorClient(target.method_5829().method_1005());
				pathFinder.think();
				pathFinder.formatPath();
				processor = pathFinder.getProcessor();
			}
			
			// process path
			if(!processor.isDone())
			{
				processor.process();
				ticksProcessing++;
			}
		}else
		{
			// jump if necessary
			if(MC.field_1724.field_5976 && MC.field_1724.method_24828())
				MC.field_1724.method_6043();
			
			// swim up if necessary
			if(MC.field_1724.method_5799() && MC.field_1724.method_23318() < target.method_23318())
				MC.field_1724.method_5762(0, 0.04, 0);
			
			// control height if flying
			if(!MC.field_1724.method_24828()
				&& (MC.field_1724.method_31549().field_7479
					|| WURST.getHax().flightHack.isEnabled())
				&& MC.field_1724.method_5649(target.method_23317(), MC.field_1724.method_23318(),
					target.method_23321()) <= MC.field_1724.method_5649(
						MC.field_1724.method_23317(), target.method_23318(), MC.field_1724.method_23321()))
			{
				if(MC.field_1724.method_23318() > target.method_23318() + 1D)
					MC.field_1690.field_1832.method_23481(true);
				else if(MC.field_1724.method_23318() < target.method_23318() - 1D)
					MC.field_1690.field_1903.method_23481(true);
			}else
			{
				MC.field_1690.field_1832.method_23481(false);
				MC.field_1690.field_1903.method_23481(false);
			}
			
			// follow target
			WURST.getRotationFaker()
				.faceVectorClient(target.method_5829().method_1005());
			MC.field_1690.field_1894.method_23481(MC.field_1724.method_5739(
				target) > (target == friend ? distanceF : distanceE));
		}
		
		if(target == enemy)
		{
			WURST.getHax().autoSwordHack.setSlot(enemy);
			
			// check cooldown
			if(!speed.isTimeToAttack())
				return;
			
			// attack enemy
			MC.field_1761.method_2918(MC.field_1724, enemy);
			swingHand.swing(class_1268.field_5808);
			speed.resetTimer();
		}
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		if(!useAi.isChecked())
			return;
		
		PathCmd pathCmd = WURST.getCmds().pathCmd;
		pathFinder.renderPath(matrixStack, pathCmd.isDebugMode(),
			pathCmd.isDepthTest());
	}
	
	public void setFriend(class_1297 friend)
	{
		this.friend = friend;
	}
	
	private class EntityPathFinder extends PathFinder
	{
		private final class_1297 entity;
		private double distanceSq;
		
		public EntityPathFinder(class_1297 entity, double distance)
		{
			super(class_2338.method_49638(entity.method_19538()));
			this.entity = entity;
			distanceSq = distance * distance;
			setThinkTime(1);
		}
		
		@Override
		protected boolean checkDone()
		{
			return done =
				entity.method_5707(class_243.method_24953(current)) <= distanceSq;
		}
		
		@Override
		public ArrayList<PathPos> formatPath()
		{
			if(!done)
				failed = true;
			
			return super.formatPath();
		}
	}
}
