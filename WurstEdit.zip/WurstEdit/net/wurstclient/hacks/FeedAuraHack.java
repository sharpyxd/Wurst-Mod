/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1321;
import net.minecraft.class_1429;
import net.minecraft.class_1496;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3966;
import net.minecraft.class_4587;
import net.minecraft.class_636;
import net.minecraft.class_746;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.HandleInputListener;
import net.wurstclient.events.RenderListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.settings.filters.FilterBabiesSetting;
import net.wurstclient.util.EntityUtils;
import net.wurstclient.util.RenderUtils;
import net.wurstclient.util.RotationUtils;

@SearchTags({"feed aura", "BreedAura", "breed aura", "AutoBreeder",
	"auto breeder"})
public final class FeedAuraHack extends Hack
	implements UpdateListener, HandleInputListener, RenderListener
{
	private final SliderSetting range = new SliderSetting("Range",
		"Determines how far FeedAura will reach to feed animals.\n"
			+ "Anything that is further away than the specified value will not be fed.",
		5, 1, 10, 0.05, ValueDisplay.DECIMAL);
	
	private final FilterBabiesSetting filterBabies =
		new FilterBabiesSetting("Won't feed baby animals.\n"
			+ "Saves food, but doesn't speed up baby growth.", true);
	
	private final CheckboxSetting filterUntamed =
		new CheckboxSetting("Filter untamed",
			"Won't feed tameable animals that haven't been tamed yet.", false);
	
	private final CheckboxSetting filterHorses = new CheckboxSetting(
		"Filter horse-like animals",
		"Won't feed horses, llamas, donkeys, etc.\n"
			+ "Recommended in Minecraft versions before 1.20.3 due to MC-233276,"
			+ "which causes these animals to consume items indefinitely.",
		false);
	
	private final Random random = new Random();
	private class_1429 target;
	private class_1429 renderTarget;
	
	public FeedAuraHack()
	{
		super("FeedAura");
		setCategory(Category.OTHER);
		addSetting(range);
		addSetting(filterBabies);
		addSetting(filterUntamed);
		addSetting(filterHorses);
	}
	
	@Override
	protected void onEnable()
	{
		// disable other auras
		WURST.getHax().clickAuraHack.setEnabled(false);
		WURST.getHax().fightBotHack.setEnabled(false);
		WURST.getHax().killauraLegitHack.setEnabled(false);
		WURST.getHax().multiAuraHack.setEnabled(false);
		WURST.getHax().protectHack.setEnabled(false);
		WURST.getHax().triggerBotHack.setEnabled(false);
		WURST.getHax().tpAuraHack.setEnabled(false);
		
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(HandleInputListener.class, this);
		EVENTS.add(RenderListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(HandleInputListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		
		target = null;
		renderTarget = null;
	}
	
	@Override
	public void onUpdate()
	{
		class_746 player = MC.field_1724;
		class_1799 heldStack = player.method_31548().method_7391();
		
		double rangeSq = range.getValueSq();
		Stream<class_1429> stream = EntityUtils.getValidAnimals()
			.filter(e -> player.method_5858(e) <= rangeSq)
			.filter(e -> e.method_6481(heldStack))
			.filter(class_1429::method_6482);
		
		if(filterBabies.isChecked())
			stream = stream.filter(filterBabies);
		
		if(filterUntamed.isChecked())
			stream = stream.filter(e -> !isUntamed(e));
		
		if(filterHorses.isChecked())
			stream = stream.filter(e -> !(e instanceof class_1496));
		
		// convert targets to list
		ArrayList<class_1429> targets =
			stream.collect(Collectors.toCollection(ArrayList::new));
		
		// pick a target at random
		target = targets.isEmpty() ? null
			: targets.get(random.nextInt(targets.size()));
		
		renderTarget = target;
		if(target == null)
			return;
		
		WURST.getRotationFaker()
			.faceVectorPacket(target.method_5829().method_1005());
	}
	
	@Override
	public void onHandleInput()
	{
		if(target == null)
			return;
		
		class_636 im = MC.field_1761;
		class_746 player = MC.field_1724;
		class_1268 hand = class_1268.field_5808;
		
		if(im.method_2923() || player.method_3144())
			return;
		
		// create realistic hit result
		class_238 box = target.method_5829();
		class_243 start = RotationUtils.getEyesPos();
		class_243 end = box.method_1005();
		class_243 hitVec = box.method_992(start, end).orElse(start);
		class_3966 hitResult = new class_3966(target, hitVec);
		
		class_1269 actionResult =
			im.method_2917(player, target, hitResult, hand);
		
		if(!actionResult.method_23665())
			actionResult = im.method_2905(player, target, hand);
		
		if(actionResult.method_23665() && actionResult.method_23666())
			player.method_6104(hand);
		
		target = null;
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		if(renderTarget == null)
			return;
		
		float p = 1;
		if(renderTarget.method_6063() > 1e-5)
			p = renderTarget.method_6032() / renderTarget.method_6063();
		float green = p * 2F;
		float red = 2 - green;
		float[] rgb = {red, green, 0};
		int quadColor = RenderUtils.toIntColor(rgb, 0.25F);
		int lineColor = RenderUtils.toIntColor(rgb, 0.5F);
		
		class_238 box = EntityUtils.getLerpedBox(renderTarget, partialTicks);
		if(p < 1)
			box = box.method_35580((1 - p) * 0.5 * box.method_17939(),
				(1 - p) * 0.5 * box.method_17940(),
				(1 - p) * 0.5 * box.method_17941());
		
		RenderUtils.drawSolidBox(matrixStack, box, quadColor, false);
		RenderUtils.drawOutlinedBox(matrixStack, box, lineColor, false);
	}
	
	private boolean isUntamed(class_1429 e)
	{
		if(e instanceof class_1496 horse && !horse.method_6727())
			return true;
		
		if(e instanceof class_1321 tame && !tame.method_6181())
			return true;
		
		return false;
	}
}
