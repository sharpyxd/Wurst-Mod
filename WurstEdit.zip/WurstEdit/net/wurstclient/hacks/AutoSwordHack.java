/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1831;
import net.minecraft.class_1835;
import net.minecraft.class_239;
import net.minecraft.class_3966;
import net.minecraft.class_5134;
import net.minecraft.class_9362;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.EnumSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.util.EntityUtils;
import net.wurstclient.util.ItemUtils;

@SearchTags({"auto sword"})
public final class AutoSwordHack extends Hack implements UpdateListener
{
	private final EnumSetting<Priority> priority =
		new EnumSetting<>("Priority", Priority.values(), Priority.SPEED);
	
	private final CheckboxSetting switchBack = new CheckboxSetting(
		"Switch back", "Switches back to the previously selected slot after"
			+ " \u00a7lRelease time\u00a7r has passed.",
		true);
	
	private final SliderSetting releaseTime = new SliderSetting("Release time",
		"Time until AutoSword will switch back from the weapon to the"
			+ " previously selected slot.\n\n"
			+ "Only works when \u00a7lSwitch back\u00a7r is checked.",
		10, 1, 200, 1,
		ValueDisplay.INTEGER.withSuffix(" ticks").withLabel(1, "1 tick"));
	
	private int oldSlot;
	private int timer;
	
	public AutoSwordHack()
	{
		super("AutoSword");
		setCategory(Category.COMBAT);
		
		addSetting(priority);
		addSetting(switchBack);
		addSetting(releaseTime);
	}
	
	@Override
	protected void onEnable()
	{
		oldSlot = -1;
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		resetSlot();
	}
	
	@Override
	public void onUpdate()
	{
		if(MC.field_1765 != null
			&& MC.field_1765.method_17783() == class_239.class_240.field_1331)
		{
			class_1297 entity = ((class_3966)MC.field_1765).method_17782();
			
			if(entity instanceof class_1309
				&& EntityUtils.IS_ATTACKABLE.test(entity))
				setSlot(entity);
		}
		
		// update timer
		if(timer > 0)
		{
			timer--;
			return;
		}
		
		resetSlot();
	}
	
	public void setSlot(class_1297 entity)
	{
		// check if active
		if(!isEnabled())
			return;
		
		// wait for AutoEat
		if(WURST.getHax().autoEatHack.isEating())
			return;
		
		// find best weapon
		float bestValue = Integer.MIN_VALUE;
		int bestSlot = -1;
		for(int i = 0; i < 9; i++)
		{
			// skip empty slots
			if(MC.field_1724.method_31548().method_5438(i).method_7960())
				continue;
			
			// get weapon value
			class_1799 stack = MC.field_1724.method_31548().method_5438(i);
			float value = getValue(stack, entity);
			
			// compare with previous best weapon
			if(value > bestValue)
			{
				bestValue = value;
				bestSlot = i;
			}
		}
		
		// check if any weapon was found
		if(bestSlot == -1)
			return;
		
		// save old slot
		if(oldSlot == -1)
			oldSlot = MC.field_1724.method_31548().field_7545;
		
		// set slot
		MC.field_1724.method_31548().field_7545 = bestSlot;
		
		// start timer
		timer = releaseTime.getValueI();
	}
	
	private float getValue(class_1799 stack, class_1297 entity)
	{
		class_1792 item = stack.method_7909();
		if(!(item instanceof class_1831 || item instanceof class_1835
			|| item instanceof class_9362))
			return Integer.MIN_VALUE;
		
		switch(priority.getSelected())
		{
			case SPEED:
			return (float)ItemUtils
				.getAttribute(item, class_5134.field_23723)
				.orElse(Integer.MIN_VALUE);
			
			// Client-side item-specific attack damage calculation no
			// longer exists as of 24w18a (1.21). Related bug: MC-196250
			case DAMAGE:
			// EntityType<?> group = entity.getType();
			float dmg = (float)ItemUtils
				.getAttribute(item, class_5134.field_23721)
				.orElse(Integer.MIN_VALUE);
			
			// Check for mace, get bonus damage from fall
			if(item instanceof class_9362 mace)
				dmg = mace.method_58403(MC.field_1724, dmg,
					entity.method_48923().method_48802(MC.field_1724));
			// dmg += EnchantmentHelper.getAttackDamage(stack, group);
			return dmg;
		}
		
		return Integer.MIN_VALUE;
	}
	
	private void resetSlot()
	{
		if(!switchBack.isChecked())
		{
			oldSlot = -1;
			return;
		}
		
		if(oldSlot != -1)
		{
			MC.field_1724.method_31548().field_7545 = oldSlot;
			oldSlot = -1;
		}
	}
	
	private enum Priority
	{
		SPEED("Speed (swords)"),
		DAMAGE("Damage (axes)");
		
		private final String name;
		
		private Priority(String name)
		{
			this.name = name;
		}
		
		@Override
		public String toString()
		{
			return name;
		}
	}
}
