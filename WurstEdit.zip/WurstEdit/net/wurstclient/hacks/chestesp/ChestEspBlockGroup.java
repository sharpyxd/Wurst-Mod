/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.chestesp;

import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.ColorSetting;
import net.wurstclient.util.BlockUtils;

public final class ChestEspBlockGroup extends ChestEspGroup
{
	public ChestEspBlockGroup(ColorSetting color, CheckboxSetting enabled)
	{
		super(color, enabled);
	}
	
	public void add(class_2586 be)
	{
		class_238 box = getBox(be);
		if(box == null)
			return;
		
		boxes.add(box);
	}
	
	private class_238 getBox(class_2586 be)
	{
		class_2338 pos = be.method_11016();
		
		if(!BlockUtils.canBeClicked(pos))
			return null;
		
		if(be instanceof class_2595)
			return getChestBox((class_2595)be);
		
		return BlockUtils.getBoundingBox(pos);
	}
	
	private class_238 getChestBox(class_2595 chestBE)
	{
		class_2680 state = chestBE.method_11010();
		if(!state.method_28498(class_2281.field_10770))
			return null;
		
		class_2745 chestType = state.method_11654(class_2281.field_10770);
		
		// ignore other block in double chest
		if(chestType == class_2745.field_12574)
			return null;
		
		class_2338 pos = chestBE.method_11016();
		class_238 box = BlockUtils.getBoundingBox(pos);
		
		// larger box for double chest
		if(chestType != class_2745.field_12569)
		{
			class_2338 pos2 = pos.method_10093(class_2281.method_9758(state));
			
			if(BlockUtils.canBeClicked(pos2))
			{
				class_238 box2 = BlockUtils.getBoundingBox(pos2);
				box = box.method_991(box2);
			}
		}
		
		return box;
	}
	
}
