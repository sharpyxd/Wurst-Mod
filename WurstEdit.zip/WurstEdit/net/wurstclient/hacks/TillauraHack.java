/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_1268;
import net.minecraft.class_1794;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.HandleInputListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.settings.SwingHandSetting.SwingHand;
import net.wurstclient.util.BlockBreaker;
import net.wurstclient.util.BlockBreaker.BlockBreakingParams;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.InteractionSimulator;
import net.wurstclient.util.RotationUtils;

@SearchTags({"till aura", "HoeAura", "hoe aura", "FarmlandAura",
	"farmland aura", "farm land aura", "AutoTill", "auto till", "AutoHoe",
	"auto hoe"})
public final class TillauraHack extends Hack implements HandleInputListener
{
	private final SliderSetting range = new SliderSetting("Range",
		"How far Tillaura will reach to till blocks.", 5, 1, 6, 0.05,
		ValueDisplay.DECIMAL);
	
	private final CheckboxSetting multiTill =
		new CheckboxSetting("MultiTill", "Tills multiple blocks at once.\n"
			+ "Faster, but can't bypass NoCheat+.", false);
	
	private final CheckboxSetting checkLOS =
		new CheckboxSetting("Check line of sight",
			"Prevents Tillaura from reaching through blocks.\n"
				+ "Good for NoCheat+ servers, but unnecessary in vanilla.",
			true);
	
	private final List<class_2248> tillableBlocks = List.of(class_2246.field_10219,
		class_2246.field_10194, class_2246.field_10566, class_2246.field_10253);
	
	public TillauraHack()
	{
		super("Tillaura");
		
		setCategory(Category.BLOCKS);
		addSetting(range);
		addSetting(multiTill);
		addSetting(checkLOS);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(HandleInputListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(HandleInputListener.class, this);
	}
	
	@Override
	public void onHandleInput()
	{
		// wait for right click timer
		if(MC.field_1752 > 0)
			return;
		
		// don't till while breaking or riding
		if(MC.field_1761.method_2923() || MC.field_1724.method_3144())
			return;
		
		// check held item
		if(!MC.field_1724.method_24520(stack -> stack.method_7909() instanceof class_1794))
			return;
		
		// get valid blocks
		ArrayList<class_2338> validBlocks = getValidBlocks();
		
		if(multiTill.isChecked())
		{
			boolean shouldSwing = false;
			
			// till all valid blocks
			for(class_2338 pos : validBlocks)
				if(rightClickBlockSimple(pos))
					shouldSwing = true;
				
			// swing arm
			if(shouldSwing)
				MC.field_1724.method_6104(class_1268.field_5808);
		}else
			// till next valid block
			for(class_2338 pos : validBlocks)
				if(rightClickBlockLegit(pos))
					break;
	}
	
	private ArrayList<class_2338> getValidBlocks()
	{
		class_243 eyesVec = RotationUtils.getEyesPos();
		class_2338 eyesBlock = class_2338.method_49638(eyesVec);
		double rangeSq = range.getValueSq();
		int blockRange = range.getValueCeil();
		
		return BlockUtils.getAllInBoxStream(eyesBlock, blockRange)
			.filter(pos -> pos.method_19770(eyesVec) <= rangeSq)
			.filter(this::isCorrectBlock)
			.sorted(Comparator
				.comparingDouble(pos -> pos.method_19770(eyesVec)))
			.collect(Collectors.toCollection(ArrayList::new));
	}
	
	private boolean isCorrectBlock(class_2338 pos)
	{
		if(!tillableBlocks.contains(BlockUtils.getBlock(pos)))
			return false;
		
		if(!BlockUtils.getState(pos.method_10084()).method_26215())
			return false;
		
		return true;
	}
	
	private boolean rightClickBlockLegit(class_2338 pos)
	{
		// if this block is unreachable, try the next one
		BlockBreakingParams params = BlockBreaker.getBlockBreakingParams(pos);
		if(params == null || params.distanceSq() > range.getValueSq())
			return false;
		if(checkLOS.isChecked() && !params.lineOfSight())
			return false;
		
		// face and right click the block
		MC.field_1752 = 4;
		WURST.getRotationFaker().faceVectorPacket(params.hitVec());
		InteractionSimulator.rightClickBlock(params.toHitResult());
		return true;
	}
	
	private boolean rightClickBlockSimple(class_2338 pos)
	{
		// if this block is unreachable, try the next one
		BlockBreakingParams params = BlockBreaker.getBlockBreakingParams(pos);
		if(params == null || params.distanceSq() > range.getValueSq())
			return false;
		if(checkLOS.isChecked() && !params.lineOfSight())
			return false;
		
		// right click the block
		InteractionSimulator.rightClickBlock(params.toHitResult(),
			SwingHand.OFF);
		return true;
	}
}
