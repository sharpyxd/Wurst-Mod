/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.autofish;

import java.util.Optional;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import net.minecraft.class_1661;
import net.minecraft.class_1787;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2378;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_6880.class_6883;
import net.minecraft.class_7924;
import net.minecraft.class_9701;
import net.wurstclient.WurstClient;
import net.wurstclient.hacks.AutoFishHack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.Setting;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.InventoryUtils;

public final class AutoFishRodSelector
{
	private static final class_310 MC = WurstClient.MC;
	
	private final CheckboxSetting stopWhenOutOfRods = new CheckboxSetting(
		"Stop when out of rods",
		"If enabled, AutoFish will turn itself off when it runs out of fishing rods.",
		false);
	
	private final CheckboxSetting stopWhenInvFull = new CheckboxSetting(
		"Stop when inv full",
		"If enabled, AutoFish will turn itself off when your inventory is full.",
		false);
	
	private final AutoFishHack autoFish;
	private int bestRodSlot;
	
	public AutoFishRodSelector(AutoFishHack autoFish)
	{
		this.autoFish = autoFish;
	}
	
	public Stream<Setting> getSettings()
	{
		return Stream.of(stopWhenOutOfRods, stopWhenInvFull);
	}
	
	public void reset()
	{
		bestRodSlot = -1;
	}
	
	public boolean isOutOfRods()
	{
		return bestRodSlot == -1;
	}
	
	/**
	 * Reevaluates the player's fishing rods, checks for any inventory-related
	 * issues and updates the selected rod if necessary.
	 *
	 * @return true if it's OK to proceed with fishing in the same tick
	 */
	public boolean update()
	{
		class_1661 inventory = MC.field_1724.method_31548();
		int selectedSlot = inventory.field_7545;
		class_1799 selectedStack = inventory.method_5438(selectedSlot);
		
		// evaluate selected rod (or lack thereof)
		int bestRodValue = getRodValue(selectedStack);
		bestRodSlot = bestRodValue > -1 ? selectedSlot : -1;
		
		// create a stream of all slots that we want to search
		IntStream stream = IntStream.range(0, 36);
		stream = IntStream.concat(stream, IntStream.of(40));
		
		// search inventory for better rod
		for(int slot : stream.toArray())
		{
			class_1799 stack = inventory.method_5438(slot);
			int rodValue = getRodValue(stack);
			
			if(rodValue > bestRodValue)
			{
				bestRodValue = rodValue;
				bestRodSlot = slot;
			}
		}
		
		// wait for AutoEat to finish eating
		if(WurstClient.INSTANCE.getHax().autoEatHack.isEating())
			return false;
		
		// stop if out of rods
		if(stopWhenOutOfRods.isChecked() && bestRodSlot == -1)
		{
			ChatUtils.message("AutoFish has run out of fishing rods.");
			autoFish.setEnabled(false);
			return false;
		}
		
		// stop if inventory is full
		if(stopWhenInvFull.isChecked() && inventory.method_7376() == -1)
		{
			ChatUtils.message(
				"AutoFish has stopped because your inventory is full.");
			autoFish.setEnabled(false);
			return false;
		}
		
		// check if selected rod is still the best one
		if(selectedSlot == bestRodSlot)
			return true;
		
		// change selected rod and wait until the next tick
		InventoryUtils.selectItem(bestRodSlot);
		return false;
	}
	
	private int getRodValue(class_1799 stack)
	{
		if(stack.method_7960() || !(stack.method_7909() instanceof class_1787))
			return -1;
		
		class_5455 drm = MC.field_1687.method_30349();
		class_2378<class_1887> registry = drm.method_30530(class_7924.field_41265);
		
		Optional<class_6883<class_1887>> luckOTS =
			registry.method_40264(class_1893.field_9114);
		int luckOTSLvl = luckOTS
			.map(entry -> class_1890.method_8225(entry, stack)).orElse(0);
		
		Optional<class_6883<class_1887>> lure =
			registry.method_40264(class_1893.field_9100);
		int lureLvl = lure
			.map(entry -> class_1890.method_8225(entry, stack)).orElse(0);
		
		Optional<class_6883<class_1887>> unbreaking =
			registry.method_40264(class_1893.field_9119);
		int unbreakingLvl = unbreaking
			.map(entry -> class_1890.method_8225(entry, stack)).orElse(0);
		
		Optional<class_6883<class_1887>> mending =
			registry.method_40264(class_1893.field_9101);
		int mendingBonus = mending
			.map(entry -> class_1890.method_8225(entry, stack)).orElse(0);
		
		int noVanishBonus = class_1890.method_60142(stack,
			class_9701.field_51655) ? 0 : 1;
		
		return luckOTSLvl * 9 + lureLvl * 9 + unbreakingLvl * 2 + mendingBonus
			+ noVanishBonus;
	}
}
