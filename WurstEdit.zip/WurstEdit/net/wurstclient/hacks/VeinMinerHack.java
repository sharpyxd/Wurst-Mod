/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;
import net.minecraft.class_1268;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.wurstclient.Category;
import net.wurstclient.events.LeftClickListener;
import net.wurstclient.events.RenderListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.hacks.nukers.NukerMultiIdListSetting;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.settings.SwingHandSetting;
import net.wurstclient.settings.SwingHandSetting.SwingHand;
import net.wurstclient.util.BlockBreaker;
import net.wurstclient.util.BlockBreaker.BlockBreakingParams;
import net.wurstclient.util.BlockBreakingCache;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.OverlayRenderer;
import net.wurstclient.util.RenderUtils;
import net.wurstclient.util.RotationUtils;

public final class VeinMinerHack extends Hack
	implements UpdateListener, LeftClickListener, RenderListener
{
	private static final class_238 BLOCK_BOX =
		new class_238(1 / 16.0, 1 / 16.0, 1 / 16.0, 15 / 16.0, 15 / 16.0, 15 / 16.0);
	
	private final SliderSetting range =
		new SliderSetting("Range", 5, 1, 6, 0.05, ValueDisplay.DECIMAL);
	
	private final CheckboxSetting flat = new CheckboxSetting("Flat mode",
		"Won't break any blocks below your feet.", false);
	
	private final NukerMultiIdListSetting multiIdList =
		new NukerMultiIdListSetting("The types of blocks to mine as veins.");
	
	private final SwingHandSetting swingHand = new SwingHandSetting(
		SwingHandSetting.genericMiningDescription(this), SwingHand.SERVER);
	
	private final BlockBreakingCache cache = new BlockBreakingCache();
	private final OverlayRenderer overlay = new OverlayRenderer();
	private final HashSet<class_2338> currentVein = new HashSet<>();
	private class_2338 currentBlock;
	
	private final SliderSetting maxVeinSize = new SliderSetting("Max vein size",
		"Maximum number of blocks to mine in a single vein.", 64, 1, 1000, 1,
		ValueDisplay.INTEGER);
	
	private final CheckboxSetting checkLOS = new CheckboxSetting(
		"Check line of sight",
		"Makes sure that you don't reach through walls when breaking blocks.",
		false);
	
	public VeinMinerHack()
	{
		super("VeinMiner");
		setCategory(Category.BLOCKS);
		addSetting(range);
		addSetting(flat);
		addSetting(multiIdList);
		addSetting(swingHand);
		addSetting(maxVeinSize);
		addSetting(checkLOS);
	}
	
	@Override
	protected void onEnable()
	{
		WURST.getHax().autoMineHack.setEnabled(false);
		WURST.getHax().excavatorHack.setEnabled(false);
		WURST.getHax().nukerHack.setEnabled(false);
		WURST.getHax().nukerLegitHack.setEnabled(false);
		WURST.getHax().speedNukerHack.setEnabled(false);
		WURST.getHax().tunnellerHack.setEnabled(false);
		
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(LeftClickListener.class, this);
		EVENTS.add(RenderListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(LeftClickListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		
		currentVein.clear();
		if(currentBlock != null)
		{
			MC.field_1761.field_3717 = true;
			MC.field_1761.method_2925();
			currentBlock = null;
		}
		
		cache.reset();
		overlay.resetProgress();
	}
	
	@Override
	public void onUpdate()
	{
		currentBlock = null;
		currentVein.removeIf(pos -> BlockUtils.getState(pos).method_45474());
		
		if(MC.field_1690.field_1886.method_1434())
			return;
		
		class_243 eyesVec = RotationUtils.getEyesPos();
		class_2338 eyesBlock = class_2338.method_49638(eyesVec);
		double rangeSq = range.getValueSq();
		int blockRange = range.getValueCeil();
		
		Stream<BlockBreakingParams> stream = BlockUtils
			.getAllInBoxStream(eyesBlock, blockRange)
			.filter(this::shouldBreakBlock)
			.map(BlockBreaker::getBlockBreakingParams).filter(Objects::nonNull)
			.filter(params -> params.distanceSq() <= rangeSq);
		
		if(checkLOS.isChecked())
			stream = stream.filter(BlockBreakingParams::lineOfSight);
		
		stream = stream.sorted(BlockBreaker.comparingParams());
		
		// Break all blocks in creative mode
		if(MC.field_1724.method_31549().field_7477)
		{
			MC.field_1761.method_2925();
			overlay.resetProgress();
			
			ArrayList<class_2338> blocks = cache
				.filterOutRecentBlocks(stream.map(BlockBreakingParams::pos));
			if(blocks.isEmpty())
				return;
			
			currentBlock = blocks.get(0);
			BlockBreaker.breakBlocksWithPacketSpam(blocks);
			swingHand.swing(class_1268.field_5808);
			return;
		}
		
		// Break the first valid block in survival mode
		currentBlock = stream.filter(this::breakOneBlock)
			.map(BlockBreakingParams::pos).findFirst().orElse(null);
		
		if(currentBlock == null)
		{
			MC.field_1761.method_2925();
			overlay.resetProgress();
			return;
		}
		
		overlay.updateProgress();
	}
	
	private boolean shouldBreakBlock(class_2338 pos)
	{
		if(flat.isChecked() && pos.method_10264() < MC.field_1724.method_23318())
			return false;
		
		return currentVein.contains(pos);
	}
	
	private boolean breakOneBlock(BlockBreakingParams params)
	{
		WURST.getRotationFaker().faceVectorPacket(params.hitVec());
		
		if(!MC.field_1761.method_2902(params.pos(),
			params.side()))
			return false;
		
		swingHand.swing(class_1268.field_5808);
		return true;
	}
	
	@Override
	public void onLeftClick(LeftClickEvent event)
	{
		if(!currentVein.isEmpty())
			return;
		
		if(!(MC.field_1765 instanceof class_3965 bHitResult)
			|| bHitResult.method_17783() != class_239.class_240.field_1332)
			return;
		
		if(!multiIdList.contains(BlockUtils.getBlock(bHitResult.method_17777())))
			return;
		
		buildVein(bHitResult.method_17777());
	}
	
	private void buildVein(class_2338 pos)
	{
		ArrayDeque<class_2338> queue = new ArrayDeque<>();
		class_2248 targetBlock = BlockUtils.getBlock(pos);
		int maxSize = maxVeinSize.getValueI();
		
		queue.offer(pos);
		currentVein.add(pos);
		
		while(!queue.isEmpty() && currentVein.size() < maxSize)
		{
			class_2338 current = queue.poll();
			
			for(class_2350 direction : class_2350.values())
			{
				class_2338 neighbor = current.method_10093(direction);
				if(!currentVein.contains(neighbor)
					&& BlockUtils.getBlock(neighbor) == targetBlock)
				{
					queue.offer(neighbor);
					currentVein.add(neighbor);
				}
			}
		}
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		overlay.render(matrixStack, partialTicks, currentBlock);
		if(currentVein.isEmpty())
			return;
		
		List<class_238> boxes =
			currentVein.stream().map(pos -> BLOCK_BOX.method_996(pos)).toList();
		RenderUtils.drawOutlinedBoxes(matrixStack, boxes, 0x80000000, false);
	}
}
