/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.templatetool;

import java.util.LinkedHashSet;
import java.util.TreeSet;
import net.minecraft.class_2338;
import net.minecraft.class_3532;

public final class Template
{
	private final int totalBlocks, scanSpeed;
	private float progress;
	
	private final TreeSet<class_2338> remainingBlocks;
	private final LinkedHashSet<class_2338> sortedBlocks = new LinkedHashSet<>();
	private class_2338 lastAddedBlock;
	
	public Template(class_2338 firstBlock, int blocksFound)
	{
		totalBlocks = blocksFound;
		scanSpeed = class_3532.method_15340(blocksFound / 15, 1, 1024);
		
		remainingBlocks = new TreeSet<>((o1, o2) -> {
			
			// compare distance to start pos
			int distanceDiff = Double.compare(o1.method_10262(firstBlock),
				o2.method_10262(firstBlock));
			if(distanceDiff != 0)
				return distanceDiff;
			
			// fallback in case of same distance
			return o1.method_10265(o2);
		});
	}
	
	public float getProgress()
	{
		return progress;
	}
	
	public void setProgress(float progress)
	{
		this.progress = progress;
	}
	
	public class_2338 getLastAddedBlock()
	{
		return lastAddedBlock;
	}
	
	public void setLastAddedBlock(class_2338 lastAddedBlock)
	{
		this.lastAddedBlock = lastAddedBlock;
	}
	
	public int getTotalBlocks()
	{
		return totalBlocks;
	}
	
	public int getScanSpeed()
	{
		return scanSpeed;
	}
	
	public TreeSet<class_2338> getRemainingBlocks()
	{
		return remainingBlocks;
	}
	
	public LinkedHashSet<class_2338> getSortedBlocks()
	{
		return sortedBlocks;
	}
}
