/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.autofarm;

import java.util.List;
import java.util.Set;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_290;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.wurstclient.WurstRenderLayers;
import net.wurstclient.util.EasyVertexBuffer;
import net.wurstclient.util.RegionPos;
import net.wurstclient.util.RenderUtils;

public final class AutoFarmRenderer
{
	private static final class_238 BLOCK_BOX =
		new class_238(class_2338.field_10980).method_1011(1 / 16.0);
	private static final class_238 NODE_BOX = new class_238(class_2338.field_10980).method_1011(0.25);
	
	private EasyVertexBuffer vertexBuffer;
	private RegionPos region;
	
	public void reset()
	{
		if(vertexBuffer != null)
		{
			vertexBuffer.close();
			vertexBuffer = null;
		}
	}
	
	public void render(class_4587 matrixStack)
	{
		if(vertexBuffer == null || region == null)
			return;
		
		matrixStack.method_22903();
		RenderUtils.applyRegionalRenderOffset(matrixStack, region);
		
		vertexBuffer.draw(matrixStack, WurstRenderLayers.ESP_LINES);
		
		matrixStack.method_22909();
	}
	
	public void updateVertexBuffers(List<class_2338> blocksToHarvest,
		Set<class_2338> plants, List<class_2338> blocksToReplant)
	{
		reset();
		
		if(blocksToHarvest.isEmpty() && plants.isEmpty()
			&& blocksToReplant.isEmpty())
			return;
		
		vertexBuffer = EasyVertexBuffer.createAndUpload(class_5596.field_27377,
			class_290.field_29337, buffer -> buildBuffer(buffer, blocksToHarvest,
				plants, blocksToReplant));
	}
	
	private void buildBuffer(class_4588 buffer,
		List<class_2338> blocksToHarvest, Set<class_2338> plants,
		List<class_2338> blocksToReplant)
	{
		region = RenderUtils.getCameraRegion();
		class_243 regionOffset = region.negate().toVec3d();
		
		for(class_2338 pos : blocksToHarvest)
		{
			class_238 box = BLOCK_BOX.method_996(pos).method_997(regionOffset);
			RenderUtils.drawOutlinedBox(buffer, box, 0x8000FF00);
		}
		
		for(class_2338 pos : plants)
		{
			class_238 renderNode = NODE_BOX.method_996(pos).method_997(regionOffset);
			RenderUtils.drawNode(buffer, renderNode, 0x8000FFFF);
		}
		
		for(class_2338 pos : blocksToReplant)
		{
			class_238 renderBox = BLOCK_BOX.method_996(pos).method_997(regionOffset);
			RenderUtils.drawOutlinedBox(buffer, renderBox, 0x80FF0000);
		}
	}
}
