/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.HandleBlockBreakingListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.mixinterface.IKeyBinding;
import net.wurstclient.settings.CheckboxSetting;

@SearchTags({"auto mine", "AutoBreak", "auto break"})
public final class AutoMineHack extends Hack
	implements UpdateListener, HandleBlockBreakingListener
{
	private final CheckboxSetting superFastMode =
		new CheckboxSetting("Super fast mode",
			"Breaks blocks faster than you normally could. May get detected by"
				+ " anti-cheat plugins.",
			false);
	
	public AutoMineHack()
	{
		super("AutoMine");
		setCategory(Category.BLOCKS);
		addSetting(superFastMode);
	}
	
	@Override
	protected void onEnable()
	{
		WURST.getHax().excavatorHack.setEnabled(false);
		WURST.getHax().nukerHack.setEnabled(false);
		WURST.getHax().nukerLegitHack.setEnabled(false);
		WURST.getHax().speedNukerHack.setEnabled(false);
		WURST.getHax().tunnellerHack.setEnabled(false);
		WURST.getHax().veinMinerHack.setEnabled(false);
		
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(HandleBlockBreakingListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(HandleBlockBreakingListener.class, this);
		IKeyBinding.get(MC.field_1690.field_1886).resetPressedState();
		MC.field_1761.method_2925();
	}
	
	@Override
	public void onUpdate()
	{
		class_636 im = MC.field_1761;
		
		// Ignore the attack cooldown because opening any screen
		// will set it to 10k ticks.
		
		if(MC.field_1724.method_3144())
		{
			im.method_2925();
			return;
		}
		
		class_239 hitResult = MC.field_1765;
		if(hitResult == null || hitResult.method_17783() != class_239.class_240.field_1332
			|| !(hitResult instanceof class_3965 bHitResult))
		{
			im.method_2925();
			return;
		}
		
		class_2338 pos = bHitResult.method_17777();
		class_2680 state = MC.field_1687.method_8320(pos);
		class_2350 side = bHitResult.method_17780();
		if(state.method_26215())
		{
			im.method_2925();
			return;
		}
		
		WURST.getHax().autoToolHack.equipIfEnabled(pos);
		
		if(MC.field_1724.method_6115())
			// This case doesn't cancel block breaking in vanilla Minecraft.
			return;
		
		if(!im.method_2923())
			im.method_2910(pos, side);
		
		if(im.method_2902(pos, side))
		{
			MC.field_1713.method_3054(pos, side);
			MC.field_1724.method_6104(class_1268.field_5808);
			MC.field_1690.field_1886.method_23481(true);
		}
	}
	
	@Override
	public void onHandleBlockBreaking(HandleBlockBreakingEvent event)
	{
		// Cancel vanilla block breaking so we don't send the packets twice.
		if(!superFastMode.isChecked())
			event.cancel();
	}
}
