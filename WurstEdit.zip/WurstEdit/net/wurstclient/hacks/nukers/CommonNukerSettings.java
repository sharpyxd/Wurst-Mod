/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.nukers;

import java.util.stream.Stream;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.wurstclient.WurstClient;
import net.wurstclient.events.LeftClickListener;
import net.wurstclient.hacks.nukers.NukerModeSetting.NukerMode;
import net.wurstclient.hacks.nukers.NukerShapeSetting.NukerShape;
import net.wurstclient.settings.BlockSetting;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.Setting;
import net.wurstclient.util.BlockUtils;

public final class CommonNukerSettings implements LeftClickListener
{
	private static final class_310 MC = WurstClient.MC;
	
	private final NukerShapeSetting shape = new NukerShapeSetting();
	
	private final CheckboxSetting flat = new CheckboxSetting("Flat mode",
		"Won't break any blocks below your feet.", false);
	
	private final NukerModeSetting mode = new NukerModeSetting();
	
	private final BlockSetting id =
		new BlockSetting("ID", "The type of block to break in ID mode.\n"
			+ "air = won't break anything", "minecraft:air", true);
	
	private final CheckboxSetting lockId = new CheckboxSetting("Lock ID",
		"Prevents changing the ID by clicking on blocks or restarting the hack.",
		false);
	
	private final NukerMultiIdListSetting multiIdList =
		new NukerMultiIdListSetting();
	
	public Stream<Setting> getSettings()
	{
		return Stream.of(shape, flat, mode, id, lockId, multiIdList);
	}
	
	public void reset()
	{
		if(!lockId.isChecked())
			id.setBlock(class_2246.field_10124);
	}
	
	public String getRenderNameSuffix()
	{
		return switch(mode.getSelected())
		{
			case ID -> " [ID:" + id.getShortBlockName() + "]";
			case MULTI_ID -> " [MultiID:" + multiIdList.size() + "]";
			case SMASH -> " [Smash]";
			default -> "";
		};
	}
	
	public boolean isIdModeWithAir()
	{
		return mode.getSelected() == NukerMode.ID
			&& id.getBlock() == class_2246.field_10124;
	}
	
	public boolean isSphereShape()
	{
		return shape.getSelected() == NukerShape.SPHERE;
	}
	
	public boolean shouldBreakBlock(class_2338 pos)
	{
		if(flat.isChecked() && pos.method_10264() < MC.field_1724.method_23318())
			return false;
		
		switch(mode.getSelected())
		{
			default:
			case NORMAL:
			return true;
			
			case ID:
			return BlockUtils.getName(pos).equals(id.getBlockName());
			
			case MULTI_ID:
			return multiIdList.contains(BlockUtils.getBlock(pos));
			
			case SMASH:
			return BlockUtils.getHardness(pos) >= 1;
		}
	}
	
	@Override
	public void onLeftClick(LeftClickEvent event)
	{
		if(lockId.isChecked() || mode.getSelected() != NukerMode.ID)
			return;
		
		if(!(MC.field_1765 instanceof class_3965 bHitResult)
			|| bHitResult.method_17783() != class_239.class_240.field_1332)
			return;
		
		id.setBlockName(BlockUtils.getName(bHitResult.method_17777()));
	}
}
