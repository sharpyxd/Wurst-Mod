/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.treebot;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.wurstclient.util.BlockUtils;

public enum TreeBotUtils
{
	;
	
	public static boolean isLog(class_2338 pos)
	{
		return BlockUtils.getState(pos).method_26164(class_3481.field_15475);
	}
	
	public static boolean isLeaves(class_2338 pos)
	{
		class_2680 state = BlockUtils.getState(pos);
		return state.method_26164(class_3481.field_15503)
			|| state.method_26164(class_3481.field_21954);
	}
}
