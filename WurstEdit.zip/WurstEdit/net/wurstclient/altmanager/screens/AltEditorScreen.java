/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.altmanager.screens;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import org.lwjgl.glfw.GLFW;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;
import net.wurstclient.WurstClient;
import net.wurstclient.altmanager.AltRenderer;
import net.wurstclient.altmanager.NameGenerator;
import net.wurstclient.altmanager.SkinStealer;

public abstract class AltEditorScreen extends class_437
{
	private final Path skinFolder =
		WurstClient.INSTANCE.getWurstFolder().resolve("skins");
	
	protected final class_437 prevScreen;
	
	private class_342 nameOrEmailBox;
	private class_342 passwordBox;
	
	private class_4185 doneButton;
	private class_4185 stealSkinButton;
	
	protected String message = "";
	private int errorTimer;
	
	public AltEditorScreen(class_437 prevScreen, class_2561 title)
	{
		super(title);
		this.prevScreen = prevScreen;
	}
	
	@Override
	public final void method_25426()
	{
		nameOrEmailBox = new class_342(field_22793, field_22789 / 2 - 100, 60,
			200, 20, class_2561.method_43470(""));
		nameOrEmailBox.method_1880(48);
		nameOrEmailBox.method_25365(true);
		nameOrEmailBox.method_1852(getDefaultNameOrEmail());
		method_25429(nameOrEmailBox);
		
		passwordBox = new class_342(field_22793, field_22789 / 2 - 100, 100,
			200, 20, class_2561.method_43470(""));
		passwordBox.method_1852(getDefaultPassword());
		passwordBox.method_1854((text, int_1) -> {
			String stars = "";
			for(int i = 0; i < text.length(); i++)
				stars += "*";
			return class_5481.method_30747(stars, class_2583.field_24360);
		});
		passwordBox.method_1880(256);
		method_25429(passwordBox);
		
		method_37063(doneButton = class_4185
			.method_46430(class_2561.method_43470(getDoneButtonText()), b -> pressDoneButton())
			.method_46434(field_22789 / 2 - 100, field_22790 / 4 + 72 + 12, 200, 20)
			.method_46431());
		
		method_37063(
			class_4185.method_46430(class_2561.method_43470("Cancel"), b -> method_25419())
				.method_46434(field_22789 / 2 - 100, field_22790 / 4 + 120 + 12, 200, 20)
				.method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Random Name"),
				b -> nameOrEmailBox.method_1852(NameGenerator.generateName()))
			.method_46434(field_22789 / 2 - 100, field_22790 / 4 + 96 + 12, 200, 20)
			.method_46431());
		
		method_37063(stealSkinButton = class_4185
			.method_46430(class_2561.method_43470("Steal Skin"),
				b -> message = stealSkin(getNameOrEmail()))
			.method_46434(field_22789 - (field_22789 / 2 - 100) / 2 - 64, field_22790 - 32, 128,
				20)
			.method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Open Skin Folder"), b -> openSkinFolder())
			.method_46434((field_22789 / 2 - 100) / 2 - 64, field_22790 - 32, 128, 20)
			.method_46431());
		
		method_25395(nameOrEmailBox);
	}
	
	private void openSkinFolder()
	{
		createSkinFolder();
		class_156.method_668().method_672(skinFolder.toFile());
	}
	
	private void createSkinFolder()
	{
		try
		{
			Files.createDirectories(skinFolder);
			
		}catch(IOException e)
		{
			e.printStackTrace();
			message = "\u00a74\u00a7lSkin folder could not be created.";
		}
	}
	
	@Override
	public final void method_25393()
	{
		String nameOrEmail = nameOrEmailBox.method_1882().trim();
		boolean alex = nameOrEmail.equalsIgnoreCase("Alexander01998");
		
		doneButton.field_22763 = !nameOrEmail.isEmpty()
			&& !(alex && passwordBox.method_1882().isEmpty());
		doneButton.method_25355(class_2561.method_43470(getDoneButtonText()));
		
		stealSkinButton.field_22763 = !alex;
	}
	
	/**
	 * @return the user-entered name or email. Cannot be empty when pressing the
	 *         done button. Cannot be null.
	 */
	protected final String getNameOrEmail()
	{
		return nameOrEmailBox.method_1882();
	}
	
	/**
	 * @return the user-entered password. Can be empty. Cannot be null.
	 */
	protected final String getPassword()
	{
		return passwordBox.method_1882();
	}
	
	protected String getDefaultNameOrEmail()
	{
		return field_22787.method_1548().method_1676();
	}
	
	protected String getDefaultPassword()
	{
		return "";
	}
	
	protected abstract String getDoneButtonText();
	
	protected abstract void pressDoneButton();
	
	protected final void doErrorEffect()
	{
		errorTimer = 8;
	}
	
	private final String stealSkin(String name)
	{
		createSkinFolder();
		Path path = skinFolder.resolve(name + ".png");
		
		try
		{
			URL url = SkinStealer.getSkinUrl(name);
			
			try(InputStream in = url.openStream())
			{
				Files.copy(in, path, StandardCopyOption.REPLACE_EXISTING);
			}
			
			return "\u00a7a\u00a7lSaved skin as " + name + ".png";
			
		}catch(IOException e)
		{
			e.printStackTrace();
			return "\u00a74\u00a7lSkin could not be saved.";
			
		}catch(NullPointerException e)
		{
			e.printStackTrace();
			return "\u00a74\u00a7lPlayer does not exist.";
		}
	}
	
	@Override
	public boolean method_25404(int keyCode, int scanCode, int int_3)
	{
		if(keyCode == GLFW.GLFW_KEY_ENTER)
			doneButton.method_25306();
		
		return super.method_25404(keyCode, scanCode, int_3);
	}
	
	@Override
	public boolean method_25402(double x, double y, int button)
	{
		nameOrEmailBox.method_25402(x, y, button);
		passwordBox.method_25402(x, y, button);
		
		if(nameOrEmailBox.method_25370() || passwordBox.method_25370())
			message = "";
		
		if(button == GLFW.GLFW_MOUSE_BUTTON_4)
		{
			method_25419();
			return true;
		}
		
		return super.method_25402(x, y, button);
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		method_25420(context, mouseX, mouseY, partialTicks);
		
		// skin preview
		AltRenderer.drawAltBack(context, nameOrEmailBox.method_1882(),
			(field_22789 / 2 - 100) / 2 - 64, field_22790 / 2 - 128, 128, 256);
		AltRenderer.drawAltBody(context, nameOrEmailBox.method_1882(),
			field_22789 - (field_22789 / 2 - 100) / 2 - 64, field_22790 / 2 - 128, 128, 256);
		
		String accountType = getPassword().isEmpty() ? "cracked" : "premium";
		
		// text
		context.method_25303(field_22793, "Name (for cracked alts), or",
			field_22789 / 2 - 100, 37, 10526880);
		context.method_25303(field_22793, "E-Mail (for premium alts)",
			field_22789 / 2 - 100, 47, 10526880);
		context.method_25303(field_22793, "Password (for premium alts)",
			field_22789 / 2 - 100, 87, 10526880);
		context.method_25303(field_22793, "Account type: " + accountType,
			field_22789 / 2 - 100, 127, 10526880);
		
		String[] lines = message.split("\n");
		for(int i = 0; i < lines.length; i++)
			context.method_25300(field_22793, lines[i],
				field_22789 / 2, 142 + 10 * i, 16777215);
		
		// text boxes
		nameOrEmailBox.method_25394(context, mouseX, mouseY, partialTicks);
		passwordBox.method_25394(context, mouseX, mouseY, partialTicks);
		
		// red flash for errors
		if(errorTimer > 0)
		{
			int alpha = (int)(Math.min(1, errorTimer / 16F) * 255);
			int color = 0xFF0000 | alpha << 24;
			context.method_25294(0, 0, field_22789, field_22790, color);
			errorTimer--;
		}
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
	}
	
	@Override
	public final void method_25419()
	{
		field_22787.method_1507(prevScreen);
	}
}
