/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.options;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.wurstclient.WurstClient;
import net.wurstclient.other_features.ZoomOtf;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;

public class ZoomManagerScreen extends class_437 implements PressAKeyCallback
{
	private class_437 prevScreen;
	private class_4185 scrollButton;
	
	public ZoomManagerScreen(class_437 par1GuiScreen)
	{
		super(class_2561.method_43470(""));
		prevScreen = par1GuiScreen;
	}
	
	@Override
	public void method_25426()
	{
		WurstClient wurst = WurstClient.INSTANCE;
		ZoomOtf zoom = wurst.getOtfs().zoomOtf;
		SliderSetting level = zoom.getLevelSetting();
		CheckboxSetting scroll = zoom.getScrollSetting();
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Back"), b -> field_22787.method_1507(prevScreen))
			.method_46434(field_22789 / 2 - 100, field_22790 / 4 + 144 - 16, 200, 20)
			.method_46431());
		
		method_37063(class_4185
			.method_46430(
				class_2561.method_43470("Zoom Key: ")
					.method_10852(zoom.getTranslatedKeybindName()),
				b -> field_22787.method_1507(new PressAKeyScreen(this)))
			.method_46434(field_22789 / 2 - 79, field_22790 / 4 + 24 - 16, 158, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("More"), b -> level.increaseValue())
			.method_46434(field_22789 / 2 - 79, field_22790 / 4 + 72 - 16, 50, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Less"), b -> level.decreaseValue())
			.method_46434(field_22789 / 2 - 25, field_22790 / 4 + 72 - 16, 50, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Default"),
				b -> level.setValue(level.getDefaultValue()))
			.method_46434(field_22789 / 2 + 29, field_22790 / 4 + 72 - 16, 50, 20).method_46431());
		
		method_37063(
			scrollButton = class_4185
				.method_46430(
					class_2561.method_43470(
						"Use Mouse Wheel: " + onOrOff(scroll.isChecked())),
					b -> toggleScroll())
				.method_46434(field_22789 / 2 - 79, field_22790 / 4 + 96 - 16, 158, 20)
				.method_46431());
	}
	
	private void toggleScroll()
	{
		ZoomOtf zoom = WurstClient.INSTANCE.getOtfs().zoomOtf;
		CheckboxSetting scroll = zoom.getScrollSetting();
		
		scroll.setChecked(!scroll.isChecked());
		scrollButton.method_25355(
			class_2561.method_43470("Use Mouse Wheel: " + onOrOff(scroll.isChecked())));
	}
	
	private String onOrOff(boolean on)
	{
		return on ? "ON" : "OFF";
	}
	
	@Override
	public void method_25419()
	{
		field_22787.method_1507(prevScreen);
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		ZoomOtf zoom = WurstClient.INSTANCE.getOtfs().zoomOtf;
		SliderSetting level = zoom.getLevelSetting();
		
		method_25420(context, mouseX, mouseY, partialTicks);
		context.method_25300(field_22793, "Zoom Manager",
			field_22789 / 2, 40, 0xffffff);
		context.method_25303(field_22793,
			"Zoom Level: " + level.getValueString(), field_22789 / 2 - 75,
			field_22790 / 4 + 44, 0xcccccc);
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
	}
	
	@Override
	public void setKey(String key)
	{
		WurstClient.INSTANCE.getOtfs().zoomOtf.setBoundKey(key);
		// Button text updates automatically because going back to this screen
		// calls init(). Might be different in older MC versions.
	}
}
