package com.example.augmentx.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Stores and manages all active AugmentX modules.
 * Use ModuleManager.register(new MyModule()) in your mod main class.
 * Use ModuleManager.getModules() to list all modules, e.g. for the GUI.
 */
public class ModuleManager {
    // List to hold all your modules
    private static final List<Module> modules = new ArrayList<>();

    /**
     * Registers a module.
     * Call this once for each module, usually in your main mod init.
     */
    public static void register(Module module) {
        modules.add(module);
    }

    /**
     * Returns a read-only list of all registered modules.
     */
    public static List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    /**
     * Find a module by name (case-insensitive).
     */
    public static Module getByName(String name) {
        for (Module module : modules) {
            if (module.getName().equalsIgnoreCase(name)) {
                return module;
            }
        }
        return null;
    }

    /**
     * Call this every tick—runs the onTick of all enabled modules.
     * Should be hooked from your client tick event.
     */
    public static void onTick() {
        for (Module module : modules) {
            if (module.isEnabled()) {
                module.onTick();
            }
        }
    }
}
