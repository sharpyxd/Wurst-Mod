package com.example.augmentx.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Manages all registered AugmentX modules.
 * Registers, updates, and provides access to them.
 */
public class ModuleManager {

    // Master list storing module instances
    private static final List<Module> modules = new ArrayList<>();

    /**
     * Register a module to the manager.
     * Call this during mod initialization.
     */
    public static void register(Module module) {
        if (!modules.contains(module)) {
            modules.add(module);
        }
    }

    /**
     * Returns all registered modules.
     * Use this for GUIs, keybinding, etc.
     */
    public static List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    /**
     * Returns a module by its name (case-insensitive).
     */
    public static Module getByName(String name) {
        for (Module module : modules) {
            if (module.getName().equalsIgnoreCase(name)) {
                return module;
            }
        }
        return null;
    }

    /**
     * Should be called every tick from the main client loop.
     * Runs logic on enabled modules.
     */
    public static void onTick() {
        for (Module module : modules) {
            if (module.isEnabled()) {
                module.onTick();
            }
        }
    }

    /**
     * Toggles a module by name. Useful for scripting or CLI.
     */
    public static void toggle(String name) {
        Module module = getByName(name);
        if (module != null) {
            module.toggle();
        }
    }

    /**
     * Returns true if the module with the given name is active.
     */
    public static boolean isEnabled(String name) {
        Module module = getByName(name);
        return module != null && module.isEnabled();
    }
}
