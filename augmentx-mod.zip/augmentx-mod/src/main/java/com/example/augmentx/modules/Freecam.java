package com.example.augmentx.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Freecam extends Module {

    private ArmorStandEntity fakePlayer;
    private Vec3d savedPosition;
    private float savedYaw;
    private float savedPitch;
    private boolean wasFlying;
    private boolean allowFlying;

    public Freecam() {
        super("Freecam");
    }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;

        if (player == null || world == null) return;

        // Save player's current position and rotation
        savedPosition = player.getPos();
        savedYaw = player.getYaw();
        savedPitch = player.getPitch();
        wasFlying = player.getAbilities().flying;
        allowFlying = player.getAbilities().allowFlying;

        // Create a fake entity to represent the body
        fakePlayer = new ArmorStandEntity(world, savedPosition.x, savedPosition.y, savedPosition.z);
        fakePlayer.setInvisible(true);
        fakePlayer.setNoGravity(true);
        fakePlayer.setCustomName(player.getName());
        fakePlayer.setCustomNameVisible(false);
        world.addEntity(fakePlayer);

        // Enable flight controls
        player.getAbilities().allowFlying = true;
        player.getAbilities().flying = true;
        player.sendAbilitiesUpdate();
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;

        if (player == null || world == null) return;

        // Restore player position and abilities
        if (savedPosition != null) {
            player.updatePosition(savedPosition.x, savedPosition.y, savedPosition.z);
            player.setYaw(savedYaw);
            player.setPitch(savedPitch);
        }

        player.getAbilities().flying = wasFlying;
        player.getAbilities().allowFlying = allowFlying;
        player.sendAbilitiesUpdate();

        // Remove the fake player
        if (fakePlayer != null) {
            fakePlayer.remove(Entity.RemovalReason.DISCARDED);
            fakePlayer = null;
        }
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && !mc.player.getAbilities().flying) {
            mc.player.getAbilities().flying = true;
            mc.player.sendAbilitiesUpdate();
        }

        // You can add more control overrides here, such as movement speed
    }
}
