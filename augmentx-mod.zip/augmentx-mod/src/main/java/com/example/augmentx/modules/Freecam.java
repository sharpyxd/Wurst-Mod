package com.example.augmentx.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Freecam extends Module {
    private Vec3d originalPosition;
    private float originalYaw, originalPitch;
    private boolean wasFlying;
    private boolean active = false;

    public Freecam() {
        super("Freecam");
    }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        // Save original position and orientation
        originalPosition = mc.player.getPos();
        originalYaw = mc.player.getYaw();
        originalPitch = mc.player.getPitch();
        wasFlying = mc.player.getAbilities().flying;

        // Enable flying for freecam movement
        mc.player.getAbilities().allowFlying = true;
        mc.player.getAbilities().flying = true;
        mc.player.sendAbilitiesUpdate();
        active = true;
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || originalPosition == null) return;

        // Restore original position and orientation
        mc.player.updatePosition(originalPosition.x, originalPosition.y, originalPosition.z);
        mc.player.setYaw(originalYaw);
        mc.player.setPitch(originalPitch);

        // Restore flying state
        mc.player.getAbilities().flying = wasFlying;
        mc.player.getAbilities().allowFlying = wasFlying || mc.player.getAbilities().creativeMode;
        mc.player.sendAbilitiesUpdate();
        active = false;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!active || mc.player == null) return;

        // Freeze player motion (prevents server position updates)
        mc.player.setVelocity(0, 0, 0);
        if (!mc.player.getAbilities().flying)
            mc.player.getAbilities().flying = true;
    }
}
