package com.example.augmentx.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;

public class Fullbright extends Module {

    private double originalGamma = 1.0;

    public Fullbright() {
        super("Fullbright");
    }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.options != null) {
            // Save the player's current gamma setting
            originalGamma = mc.options.getGamma().getValue();
            // Set gamma to a very high value for full brightness
            mc.options.getGamma().setValue(16.0); // Max brightness
        }
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.options != null) {
            // Restore the player's original gamma setting
            mc.options.getGamma().setValue(originalGamma);
        }
    }
}
