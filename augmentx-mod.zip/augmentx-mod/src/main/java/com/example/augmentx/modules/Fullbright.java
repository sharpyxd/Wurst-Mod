package com.example.augmentx.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.options.GameOptions;

public class Fullbright extends Module {

    // Store the previous gamma value so we can restore it later
    private double previousGamma = 1.0;

    public Fullbright() {
        super("Fullbright");
    }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.options != null) {
            GameOptions options = mc.options;
            previousGamma = options.getGamma().getValue();
            options.getGamma().setValue(16.0); // Super-bright!
        }
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.options != null) {
            // Restore previous gamma value
            mc.options.getGamma().setValue(previousGamma);
        }
    }
}
