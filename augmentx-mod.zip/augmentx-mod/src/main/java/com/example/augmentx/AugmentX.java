package com.example.augmentx;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.example.augmentx.modules.ModuleManager;
import com.example.augmentx.modules.ToggleSprint;
import com.example.augmentx.modules.Freecam;
import com.example.augmentx.modules.ESP;
import com.example.augmentx.modules.KillAura;
import com.example.augmentx.modules.Fullbright;
import com.example.augmentx.modules.AutoClick;

import com.example.augmentx.gui.ClickGuiScreen;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

/**
 * Main mod initializer for AugmentX client
 */
public class AugmentXMod implements ModInitializer {
    public static final String MOD_ID = "augmentx";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Keybind to open the in-game Click GUI
    private static KeyBinding openGuiKey;

    @Override
    public void onInitialize() {
        // Register modules (add more as you expand)
        ModuleManager.register(new ToggleSprint());
        ModuleManager.register(new Freecam());
        ModuleManager.register(new ESP());
        ModuleManager.register(new KillAura());
        ModuleManager.register(new Fullbright());
        ModuleManager.register(new AutoClick());

        // Register per-module toggle keybinds
        KeybindManager.registerModuleKeybinds();

        // Register GUI opening key (e.g., Right Shift)
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.augmentx.opengui",
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "AugmentX"
        ));

        // Register tick handler for in-game updates
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openGuiKey.wasPressed()) {
                client.setScreen(new ClickGuiScreen());
            }
            KeybindManager.handleKeybinds();
            ModuleManager.onTick();
        });

        LOGGER.info("[AugmentX] Mod initialized.");
    }
}
