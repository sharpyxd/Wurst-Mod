package com.example.augmentx;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.example.augmentx.modules.ModuleManager;
import com.example.augmentx.modules.ToggleSprint;
import com.example.augmentx.modules.Freecam;
import com.example.augmentx.modules.ESP;
import com.example.augmentx.modules.KillAura;
import com.example.augmentx.modules.Fullbright;
import com.example.augmentx.modules.AutoClick;

import com.example.augmentx.gui.ClickGuiScreen;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

public class AugmentXMod implements ModInitializer {
    public static final String MOD_ID = "augmentx";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static KeyBinding openGuiKey;

    @Override
    public void onInitialize() {
        // Log startup info
        LOGGER.info("[AugmentX] Initializing...");

        // Register your hack modules
        ModuleManager.register(new ToggleSprint());
        ModuleManager.register(new Freecam());
        ModuleManager.register(new ESP());
        ModuleManager.register(new KillAura());
        ModuleManager.register(new Fullbright());
        ModuleManager.register(new AutoClick());

        // Register module toggle keybinds (should be after all modules are registered)
        KeybindManager.registerModuleKeybinds();

        // Register GUI-open keybind (Right Shift by default)
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.augmentx.opengui",
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            "key.categories.augmentx"
        ));

        // Register a tick event handler: updates logic and handles GUI keybind
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openGuiKey.wasPressed()) {
                client.setScreen(new ClickGuiScreen());
            }
            // Process per-module keybinds and module onTick routines
            KeybindManager.handleKeybinds();
            ModuleManager.onTick();
        });

        LOGGER.info("[AugmentX] Initialized successfully.");
    }
}
