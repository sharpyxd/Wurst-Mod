package com.example.augmentx;

import com.example.augmentx.modules.Module;
import com.example.augmentx.modules.ModuleManager;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/**
 * Handles keybinding (per-module toggling and GUI open).
 * - Call KeybindManager.handleKeybinds() every tick (from your main mod/tick event).
 * - Gives each module its own toggle key (default: NONE, but can be set per-module).
 */
public class KeybindManager {

    // Map: module name -> keybinding
    private static final Map<Module, KeyBinding> moduleKeybinds = new HashMap<>();

    // (Optional) You can make this public static for settings GUI
    public static KeyBinding getKeybindFor(Module module) {
        return moduleKeybinds.get(module);
    }

    /**
     * Register a keybind for each module (call in your mod init, after all modules are registered).
     * Default: no key. Customize defaults as you wish.
     */
    public static void registerModuleKeybinds() {
        for (Module module : ModuleManager.getModules()) {
            // Example: You can hard-code default keys for some modules if you like, or use NONE for all
            int defaultKey = GLFW.GLFW_KEY_UNKNOWN;  // Default: not bound to any key

            // Optionally set defaults (example: ToggleSprint is bound to "G" by default, others are unbound)
            if (module.getName().equalsIgnoreCase("ToggleSprint")) {
                defaultKey = GLFW.GLFW_KEY_G;
            }

            KeyBinding keybind = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                    "key.augmentx." + module.getName().toLowerCase(),
                    defaultKey,
                    "key.categories.augmentx"
            ));

            moduleKeybinds.put(module, keybind);
        }
    }

    /**
     * Call this every client tick!
     * Will toggle modules when their keybinds are pressed.
     */
    public static void handleKeybinds() {
        for (Map.Entry<Module, KeyBinding> entry : moduleKeybinds.entrySet()) {
            Module module = entry.getKey();
            KeyBinding key = entry.getValue();
            if (key.wasPressed()) {
                module.toggle();
            }
        }
    }
}
