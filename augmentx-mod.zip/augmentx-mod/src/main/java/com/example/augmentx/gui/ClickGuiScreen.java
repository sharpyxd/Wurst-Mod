package com.example.augmentx.gui;

import com.example.augmentx.modules.Module;
import com.example.augmentx.modules.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;

public class ClickGuiScreen extends Screen {
    // Used to keep GUI size and module list placement consistent
    private static final int LEFT = 40;
    private static final int TOP = 40;
    private static final int WIDTH = 140;
    private static final int HEIGHT_PER = 26;

    public ClickGuiScreen() {
        super(Text.of("AugmentX GUI"));
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        // Draw background
        this.renderBackground(matrices);

        // Title
        drawCenteredText(matrices, this.textRenderer, "AugmentX Modules", this.width / 2, 18, 0xFFFFFFAA);

        int y = TOP;
        for (Module mod : ModuleManager.getModules()) {
            int color = mod.isEnabled() ? 0x8800FF00 : 0xAA222222; // Green when ON, gray when OFF
            // Draw module button background
            fill(matrices, LEFT, y, LEFT + WIDTH, y + HEIGHT_PER, color);

            // Draw module name
            this.textRenderer.draw(matrices, mod.getName(), LEFT + 8, y + 9, 0xFFFFFFFF);

            // Draw ON/OFF indicator text
            drawRightAlignedText(
                matrices, 
                this.textRenderer, 
                mod.isEnabled() ? "ON" : "OFF", 
                LEFT + WIDTH - 8, 
                y + 9, 
                mod.isEnabled() ? 0xFF44FF44 : 0xFFFF5555);

            y += HEIGHT_PER + 6;
        }

        super.render(matrices, mouseX, mouseY, delta);
    }

    /**
     * Handle mouse click: toggle the module if a module row is clicked!
     */
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int y = TOP;
        int idx = 0;
        for (Module mod : ModuleManager.getModules()) {
            int minX = LEFT;
            int maxX = LEFT + WIDTH;
            int minY = y;
            int maxY = y + HEIGHT_PER;

            if (mouseX >= minX && mouseX <= maxX && mouseY >= minY && mouseY <= maxY) {
                mod.toggle();
                // Optional: make a sound on toggle
                MinecraftClient.getInstance().player.playSound(
                    mod.isEnabled() ? net.minecraft.sound.SoundEvents.UI_BUTTON_CLICK.value() : net.minecraft.sound.SoundEvents.UI_BUTTON_CLICK.value(),
                    0.8f,  // volume
                    mod.isEnabled() ? 1.3f : 0.8f // pitch
                );
                return true;
            }
            y += HEIGHT_PER + 6;
            idx++;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    /**
     * Helper for right-aligned text (for ON/OFF indicator)
     */
    private static void drawRightAlignedText(MatrixStack matrices, net.minecraft.client.font.TextRenderer renderer, String str, int x, int y, int color) {
        renderer.draw(matrices, str, x - renderer.getWidth(str), y, color);
    }

    /**
     * Close GUI with ESC
     */
    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        this.client.setScreen(null);
    }
}
