package com.example.augmentx.gui;

import com.example.augmentx.modules.Module;
import com.example.augmentx.modules.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class ClickGuiScreen extends Screen {

    private static final int LEFT = 40;
    private static final int TOP = 40;
    private static final int WIDTH = 140;
    private static final int HEIGHT_PER = 26;

    public ClickGuiScreen() {
        super(Text.of("AugmentX GUI"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Draw background
        renderBackground(context);

        // Title
        context.drawCenteredTextWithShadow(this.textRenderer, Text.of("AugmentX Modules"), this.width / 2, 20, 0xFFFFFF);

        int y = TOP;

        for (Module mod : ModuleManager.getModules()) {
            boolean isHovered = isMouseOver(mouseX, mouseY, LEFT, y, WIDTH, HEIGHT_PER);
            int color = mod.isEnabled() ? 0x8800FF00 : 0xAA222222;

            // Highlight when hovered
            if (isHovered) {
                color = mod.isEnabled() ? 0xAA44FF44 : 0xAA444444;
            }

            // Draw background box
            context.fill(LEFT, y, LEFT + WIDTH, y + HEIGHT_PER, color);

            // Module Name
            context.drawTextWithShadow(this.textRenderer, Text.of(mod.getName()), LEFT + 8, y + 8, 0xFFFFFF);

            // ON/OFF text right side
            String state = mod.isEnabled() ? "ON" : "OFF";
            int stateColor = mod.isEnabled() ? 0x44FF44 : 0xFF5555;
            drawRightAlignedText(context, state, LEFT + WIDTH - 8, y + 8, stateColor);

            y += HEIGHT_PER + 6;
        }

        super.render(context, mouseX, mouseY, delta);
    }

    private boolean isMouseOver(int mouseX, int mouseY, int x, int y, int w, int h) {
        return mouseX >= x && mouseX <= x + w &&
               mouseY >= y && mouseY <= y + h;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int y = TOP;

        for (Module mod : ModuleManager.getModules()) {
            if (isMouseOver((int) mouseX, (int) mouseY, LEFT, y, WIDTH, HEIGHT_PER)) {
                mod.toggle();

                // Optional: play a click sound
                MinecraftClient.getInstance().player.playSound(
                    net.minecraft.sound.SoundEvents.UI_BUTTON_CLICK.value(),
                    1.0F, 1.0F
                );

                return true;
            }

            y += HEIGHT_PER + 6;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void drawRightAlignedText(DrawContext context, String text, int rightX, int y, int color) {
        int width = this.textRenderer.getWidth(text);
        context.drawTextWithShadow(this.textRenderer, text, rightX - width, y, color);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        this.client.setScreen(null);
    }
}
