package com.example.augmentx.modules;

/**
 * The base class for all AugmentX modules.
 * Extend this to create a new feature or hack!
 */
public abstract class Module {
    private final String name;
    private boolean enabled = false;

    public Module(String name) {
        this.name = name;
    }

    // Basic info
    public String getName() {
        return name;
    }

    public boolean isEnabled() {
        return enabled;
    }

    // Enable/Disable logic
    public void setEnabled(boolean enabled) {
        if (this.enabled != enabled) {
            this.enabled = enabled;
            if (enabled) {
                onEnable();
            } else {
                onDisable();
            }
        }
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    // Override these in your modules if needed
    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {} // Called every tick if enabled

    // Optionally, you can add settings (as shown before)
    // Use: protected final java.util.Map<String,Object> settings = new HashMap<>();
}
