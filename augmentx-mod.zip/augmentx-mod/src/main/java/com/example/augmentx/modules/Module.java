package com.example.augmentx.modules;

/**
 * Base class for all AugmentX modules.
 * Each module can be toggled on/off and updated every tick.
 */
public abstract class Module {
    private final String name;
    private boolean enabled = false;

    public Module(String name) {
        this.name = name;
    }

    /**
     * Returns the name of the module.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns whether the module is currently enabled.
     */
    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Enables the module.
     * Override this for startup logic.
     */
    public void onEnable() {
        // Optional: implement in subclasses
    }

    /**
     * Disables the module.
     * Override this for cleanup logic.
     */
    public void onDisable() {
        // Optional: implement in subclasses
    }

    /**
     * Called once every client tick while the module is enabled.
     * Override this to implement module logic.
     */
    public void onTick() {
        // Optional: implement in subclasses
    }

    /**
     * Toggles the current enabled state.
     */
    public void toggle() {
        enabled = !enabled;
        if (enabled) {
            onEnable();
        } else {
            onDisable();
        }
    }

    /**
     * Sets module state directly (true = enable, false = disable).
     */
    public void setEnabled(boolean state) {
        if (this.enabled != state) {
            toggle();
        }
    }
}
