package com.example.augmentx.modules;

import net.minecraft.client.MinecraftClient;

public class ToggleSprint extends Module {

    public ToggleSprint() {
        super("ToggleSprint");
    }

    @Override
    public void onEnable() {
        System.out.println("[AugmentX] ToggleSprint enabled");
    }

    @Override
    public void onDisable() {
        System.out.println("[AugmentX] ToggleSprint disabled");

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.setSprinting(false);
        }
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player != null && mc.player.input != null) {
            // Only sprint when moving forward, not sneaking, and hunger > 6
            if (mc.player.input.movementForward > 0 &&
                !mc.player.isSneaking() &&
                mc.player.getHungerManager().getFoodLevel() > 6 &&
                !mc.player.hasVehicle()) {

                mc.player.setSprinting(true);
            } else {
                mc.player.setSprinting(false);
            }
        }
    }
}
