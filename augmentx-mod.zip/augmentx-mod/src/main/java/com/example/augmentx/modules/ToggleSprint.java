package com.example.augmentx.modules;

import net.minecraft.client.MinecraftClient;

public class ToggleSprint extends Module {

    public ToggleSprint() {
        super("ToggleSprint");
    }

    @Override
    public void onEnable() {
        // Optional: notify the player or log when enabled
        System.out.println("[AugmentX] ToggleSprint enabled");
    }

    @Override
    public void onDisable() {
        // Optional: notify the player or log when disabled
        System.out.println("[AugmentX] ToggleSprint disabled");
        // Optionally reset sprint state if needed
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.setSprinting(false);
        }
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.setSprinting(true);
        }
    }
}
