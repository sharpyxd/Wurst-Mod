package com.example.augmentx.modules;

import net.minecraft.client.MinecraftClient;

public class AutoClick extends Module {

    // Click every X ticks (increase to slow, decrease to speed up)
    private int clickDelay = 2; // e.g. 2 = up to 10 clicks/sec on 20TPS server
    private int tickCounter = 0;

    public AutoClick() {
        super("AutoClick");
    }

    @Override
    public void onEnable() {
        tickCounter = 0;
    }

    @Override
    public void onDisable() {
        tickCounter = 0;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        tickCounter++;
        if (tickCounter >= clickDelay) {
            // Only attack when the attack key is held (feels more legit; comment this if always autoclick)
            if (mc.options.attackKey.isPressed()) {
                mc.interactionManager.attackEntity(mc.player, mc.crosshairTarget.getEntity());
                mc.player.swingHand(mc.player.getActiveHand());
            }
            tickCounter = 0;
        }
    }
}
