package com.example.augmentx.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.Hand;

public class AutoClick extends Module {

    private int tickDelay = 2;  // Click every 2 ticks (~10 CPS)
    private int tickCounter = 0;

    public AutoClick() {
        super("AutoClick");
    }

    @Override
    public void onEnable() {
        tickCounter = 0;
    }

    @Override
    public void onDisable() {
        tickCounter = 0;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.crosshairTarget == null) {
            return;
        }

        KeyBinding attackKey = mc.options.attackKey;

        tickCounter++;
        if (tickCounter >= tickDelay) {
            if (attackKey.isPressed()) {
                simulateLeftClick(mc);
                tickCounter = 0;
            }
        }
    }

    private void simulateLeftClick(MinecraftClient mc) {
        HitResult hit = mc.crosshairTarget;

        // If entity is targeted, attack it
        if (hit.getType() == HitResult.Type.ENTITY && hit instanceof EntityHitResult entityHit) {
            mc.interactionManager.attackEntity(mc.player, entityHit.getEntity());
        } else {
            // Else, swing at nothing or block
            mc.interactionManager.attackBlock(hit.getBlockPos(), hit.getSide());
        }

        // Always play animation
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
