package com.example.augmentx.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

import java.util.Comparator;

public class KillAura extends Module {

    // You can expose this as a setting for user control
    private final double attackRange = 6.0;

    // Attack cooldown (in ticks)
    private int ticksSinceLastAttack = 0;
    private final int attackCooldown = 6; // Attack about every 6 ticks

    public KillAura() {
        super("KillAura");
    }

    @Override
    public void onTick() {
        if (!isEnabled()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        ticksSinceLastAttack++;
        if (ticksSinceLastAttack < attackCooldown) return;

        // Find nearest living entity within range (excluding self)
        LivingEntity target = mc.world.getEntities()
            .stream()
            .filter(e -> e instanceof LivingEntity)
            .map(e -> (LivingEntity) e)
            .filter(e -> e != mc.player)
            .filter(e -> mc.player.squaredDistanceTo(e) <= attackRange * attackRange)
            .min(Comparator.comparingDouble(e -> mc.player.squaredDistanceTo(e)))
            .orElse(null);

        if (target != null) {
            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(mc.player.getActiveHand());
            ticksSinceLastAttack = 0;
        }
    }

    @Override
    public void onEnable() {
        ticksSinceLastAttack = 0;
    }
}
