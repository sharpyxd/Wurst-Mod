package com.example.augmentx.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Comparator;
import java.util.Optional;
import java.util.stream.StreamSupport;

public class KillAura extends Module {

    private final double attackRange = 5.8; // Blocks
    private final int attackDelayTicks = 6; // Cooldown between attacks
    private int tickCounter = 0;

    public KillAura() {
        super("KillAura");
    }

    @Override
    public void onEnable() {
        tickCounter = 0;
    }

    @Override
    public void onDisable() {
        tickCounter = 0;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null || mc.world == null || mc.interactionManager == null) {
            return;
        }

        tickCounter++;

        if (tickCounter < attackDelayTicks) {
            return;
        }

        ClientPlayerEntity player = mc.player;

        // Find nearest valid target
        Optional<LivingEntity> target = StreamSupport.stream(mc.world.getEntities().spliterator(), false)
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(e -> e.isAlive() && e != player)
                .filter(e -> player.squaredDistanceTo(e) <= attackRange * attackRange)
                .sorted(Comparator.comparingDouble(player::squaredDistanceTo))
                .findFirst();

        if (target.isPresent()) {
            LivingEntity entity = target.get();

            mc.interactionManager.attackEntity(player, entity);
            player.swingHand(player.getActiveHand());

            tickCounter = 0; // Reset cooldown
        }
    }
}
