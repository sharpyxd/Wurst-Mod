package com.example.augmentx.modules;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

public class ESP extends Module {
    private boolean registered = false;

    public ESP() {
        super("ESP");
    }

    @Override
    public void onEnable() {
        if (!registered) {
            WorldRenderEvents.AFTER_ENTITIES.register(this::onWorldRender);
            registered = true;
        }
    }

    @Override
    public void onDisable() {
        // No unregister in basic API, so simply ignore rendering if disabled
    }

    private void onWorldRender(WorldRenderEvents.AfterEntitiesContext ctx) {
        if (!isEnabled()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        MatrixStack matrices = ctx.matrixStack();
        for (Entity entity : mc.world.getEntities()) {
            if (entity instanceof LivingEntity && entity != mc.player) {
                // Placeholder: Replace with your own drawing logic (e.g., box, outline, glow)
                // Example (pseudocode):
                // RenderUtil.drawBoxAroundEntity(matrices, entity, 0xFF00FF00);
            }
        }
    }
}
