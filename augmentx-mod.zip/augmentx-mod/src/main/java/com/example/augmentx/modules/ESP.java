package com.example.augmentx.modules;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.GameRenderer;

import org.joml.Matrix4f;

public class ESP extends Module {
    private boolean isHooked = false;

    public ESP() {
        super("ESP");
    }

    @Override
    public void onEnable() {
        if (!isHooked) {
            WorldRenderEvents.AFTER_ENTITIES.register(this::onWorldRender);
            isHooked = true;
        }
    }

    @Override
    public void onDisable() {
        // Fabric currently doesn't support unregistering from render events directly,
        // so just check isEnabled() during rendering.
    }

    private void onWorldRender(net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
        if (!isEnabled()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        MatrixStack matrices = context.matrixStack();

        Vec3d cameraPos = mc.gameRenderer.getCamera().getPos();
        matrices.push();

        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof LivingEntity) || entity == mc.player) continue;

            // Calculate interpolated position
            double x = entity.prevX + (entity.getX() - entity.prevX);
            double y = entity.prevY + (entity.getY() - entity.prevY);
            double z = entity.prevZ + (entity.getZ() - entity.prevZ);

            // Entity bounding box
            Box box = entity.getBoundingBox().offset(-cameraPos.x, -cameraPos.y, -cameraPos.z);

            drawBox(matrices, box, 1.0f, 0.0f, 0.0f, 1.0f); // Red Boxes
        }

        matrices.pop();
    }

    private void drawBox(MatrixStack matrices, Box box, float r, float g, float b, float a) {
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.getBuffer();

        buffer.begin(VertexFormats.LINES, VertexFormats.LINES);

        // Draw box edges (12 lines total to form a cube)
        drawLine(buffer, matrix, box.minX, box.minY, box.minZ, box.minX, box.minY, box.maxZ, r, g, b, a);
        drawLine(buffer, matrix, box.minX, box.minY, box.minZ, box.minX, box.maxY, box.minZ, r, g, b, a);
        drawLine(buffer, matrix, box.minX, box.minY, box.maxZ, box.minX, box.maxY, box.maxZ, r, g, b, a);
        drawLine(buffer, matrix, box.minX, box.maxY, box.minZ, box.minX, box.maxY, box.maxZ, r, g, b, a);

        drawLine(buffer, matrix, box.maxX, box.minY, box.minZ, box.maxX, box.minY, box.maxZ, r, g, b, a);
        drawLine(buffer, matrix, box.maxX, box.minY, box.minZ, box.maxX, box.maxY, box.minZ, r, g, b, a);
        drawLine(buffer, matrix, box.maxX, box.minY, box.maxZ, box.maxX, box.maxY, box.maxZ, r, g, b, a);
        drawLine(buffer, matrix, box.maxX, box.maxY, box.minZ, box.maxX, box.maxY, box.maxZ, r, g, b, a);

        drawLine(buffer, matrix, box.minX, box.minY, box.minZ, box.maxX, box.minY, box.minZ, r, g, b, a);
        drawLine(buffer, matrix, box.minX, box.minY, box.maxZ, box.maxX, box.minY, box.maxZ, r, g, b, a);
        drawLine(buffer, matrix, box.minX, box.maxY, box.minZ, box.maxX, box.maxY, box.minZ, r, g, b, a);
        drawLine(buffer, matrix, box.minX, box.maxY, box.maxZ, box.maxX, box.maxY, box.maxZ, r, g, b, a);

        tessellator.draw();
    }

    private void drawLine(BufferBuilder buffer, Matrix4f matrix, double x1, double y1, double z1, double x2, double y2, double z2, float r, float g, float b, float a) {
        buffer.vertex(matrix, (float) x1, (float) y1, (float) z1).color(r, g, b, a).next();
        buffer.vertex(matrix, (float) x2, (float) y2, (float) z2).color(r, g, b, a).next();
    }
}
