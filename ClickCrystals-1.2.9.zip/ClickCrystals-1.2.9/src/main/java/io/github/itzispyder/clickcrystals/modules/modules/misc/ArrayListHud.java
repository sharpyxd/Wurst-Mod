package io.github.itzispyder.clickcrystals.modules.modules.misc;

import io.github.itzispyder.clickcrystals.modules.Categories;
import io.github.itzispyder.clickcrystals.modules.modules.DummyModule;

public class ArrayListHud extends DummyModule {

    public ArrayListHud() {
        super("array-list", Categories.MISC, "Shows the enabled modules on screen");
    }
}
