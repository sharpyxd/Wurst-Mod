package io.github.itzispyder.clickcrystals.interfaces;

public interface MinecraftClientAccessor {

    void inputAttack();

    void inputUse();
}
