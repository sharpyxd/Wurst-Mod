package io.github.itzispyder.clickcrystals.interfaces;

public interface KeyboardAccessor {

    void pressKey(int key, int scan);
}
