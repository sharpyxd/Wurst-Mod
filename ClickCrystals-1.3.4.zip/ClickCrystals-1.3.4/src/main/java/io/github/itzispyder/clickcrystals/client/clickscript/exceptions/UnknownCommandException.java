package io.github.itzispyder.clickcrystals.client.clickscript.exceptions;

public class UnknownCommandException extends RuntimeException {

    public UnknownCommandException(String msg) {
        super(msg);
    }
}
