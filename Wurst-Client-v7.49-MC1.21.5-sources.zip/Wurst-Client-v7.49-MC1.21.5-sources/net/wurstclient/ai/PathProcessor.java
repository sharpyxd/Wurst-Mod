/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.ai;

import java.util.ArrayList;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.wurstclient.WurstClient;
import net.wurstclient.mixinterface.IKeyBinding;

public abstract class PathProcessor
{
	protected static final WurstClient WURST = WurstClient.INSTANCE;
	protected static final class_310 MC = WurstClient.MC;
	
	private static final class_304[] CONTROLS =
		{MC.field_1690.field_1894, MC.field_1690.field_1881, MC.field_1690.field_1849,
			MC.field_1690.field_1913, MC.field_1690.field_1903, MC.field_1690.field_1832};
	
	protected final ArrayList<PathPos> path;
	protected int index;
	protected boolean done;
	protected int ticksOffPath;
	
	public PathProcessor(ArrayList<PathPos> path)
	{
		if(path.isEmpty())
			throw new IllegalStateException("There is no path!");
		
		this.path = path;
	}
	
	public abstract void process();
	
	public abstract boolean canBreakBlocks();
	
	public final int getIndex()
	{
		return index;
	}
	
	public final boolean isDone()
	{
		return done;
	}
	
	public final int getTicksOffPath()
	{
		return ticksOffPath;
	}
	
	protected final void facePosition(class_2338 pos)
	{
		WURST.getRotationFaker()
			.faceVectorClientIgnorePitch(class_243.method_24953(pos));
	}
	
	public static final void lockControls()
	{
		// disable keys
		for(class_304 key : CONTROLS)
			key.method_23481(false);
		
		// disable sprinting
		MC.field_1724.method_5728(false);
	}
	
	public static final void releaseControls()
	{
		// reset keys
		for(class_304 key : CONTROLS)
			IKeyBinding.get(key).resetPressedState();
	}
}
