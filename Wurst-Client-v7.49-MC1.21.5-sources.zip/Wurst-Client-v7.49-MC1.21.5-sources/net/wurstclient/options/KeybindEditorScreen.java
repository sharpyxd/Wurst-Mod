/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.options;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.wurstclient.WurstClient;

public final class KeybindEditorScreen extends class_437
	implements PressAKeyCallback
{
	private final class_437 prevScreen;
	
	private String key;
	private final String oldKey;
	private final String oldCommands;
	
	private class_342 commandField;
	
	public KeybindEditorScreen(class_437 prevScreen)
	{
		super(class_2561.method_43470(""));
		this.prevScreen = prevScreen;
		
		key = "NONE";
		oldKey = null;
		oldCommands = null;
	}
	
	public KeybindEditorScreen(class_437 prevScreen, String key, String commands)
	{
		super(class_2561.method_43470(""));
		this.prevScreen = prevScreen;
		
		this.key = key;
		oldKey = key;
		oldCommands = commands;
	}
	
	@Override
	public void method_25426()
	{
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Change Key"),
				b -> field_22787.method_1507(new PressAKeyScreen(this)))
			.method_46434(field_22789 / 2 - 100, 60, 200, 20).method_46431());
		
		method_37063(class_4185.method_46430(class_2561.method_43470("Save"), b -> save())
			.method_46434(field_22789 / 2 - 100, field_22790 / 4 + 72, 200, 20).method_46431());
		
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Cancel"), b -> field_22787.method_1507(prevScreen))
			.method_46434(field_22789 / 2 - 100, field_22790 / 4 + 96, 200, 20).method_46431());
		
		commandField = new class_342(field_22793, field_22789 / 2 - 100, 100,
			200, 20, class_2561.method_43470(""));
		commandField.method_1880(65536);
		method_25429(commandField);
		method_25395(commandField);
		commandField.method_25365(true);
		
		if(oldCommands != null)
			commandField.method_1852(oldCommands);
	}
	
	private void save()
	{
		if(oldKey != null)
			WurstClient.INSTANCE.getKeybinds().remove(oldKey);
		
		WurstClient.INSTANCE.getKeybinds().add(key, commandField.method_1882());
		field_22787.method_1507(prevScreen);
	}
	
	@Override
	public boolean method_25402(double mouseX, double mouseY, int mouseButton)
	{
		commandField.method_25402(mouseX, mouseY, mouseButton);
		return super.method_25402(mouseX, mouseY, mouseButton);
	}
	
	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		method_25420(context, mouseX, mouseY, partialTicks);
		
		context.method_25300(field_22793,
			(oldKey != null ? "Edit" : "Add") + " Keybind", field_22789 / 2, 20,
			0xffffff);
		
		context.method_25303(field_22793,
			"Key: " + key.replace("key.keyboard.", ""), field_22789 / 2 - 100, 47,
			0xa0a0a0);
		context.method_25303(field_22793, "Commands (separated by ';')",
			field_22789 / 2 - 100, 87, 0xa0a0a0);
		
		commandField.method_25394(context, mouseX, mouseY, partialTicks);
		
		for(class_4068 drawable : field_33816)
			drawable.method_25394(context, mouseX, mouseY, partialTicks);
	}
	
	@Override
	public void method_25419()
	{
		field_22787.method_1507(prevScreen);
	}
	
	@Override
	public void setKey(String key)
	{
		this.key = key;
	}
}
