/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.navigator;

import java.awt.Color;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeMap;

import org.lwjgl.glfw.GLFW;

import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1109;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_4587;
import net.wurstclient.Feature;
import net.wurstclient.WurstClient;
import net.wurstclient.clickgui.ClickGui;
import net.wurstclient.clickgui.Component;
import net.wurstclient.clickgui.Window;
import net.wurstclient.command.Command;
import net.wurstclient.hack.Hack;
import net.wurstclient.hacks.TooManyHaxHack;
import net.wurstclient.keybinds.Keybind;
import net.wurstclient.keybinds.PossibleKeybind;
import net.wurstclient.settings.Setting;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.RenderUtils;

public final class NavigatorFeatureScreen extends NavigatorScreen
{
	private Feature feature;
	private NavigatorMainScreen parent;
	private ButtonData activeButton;
	private class_4185 primaryButton;
	private String text;
	private ArrayList<ButtonData> buttonDatas = new ArrayList<>();
	
	private Window window = new Window("");
	private int windowComponentY;
	
	public NavigatorFeatureScreen(Feature feature, NavigatorMainScreen parent)
	{
		this.feature = feature;
		this.parent = parent;
		hasBackground = false;
		
		for(Setting setting : feature.getSettings().values())
		{
			Component c = setting.getComponent();
			
			if(c != null)
				window.add(c);
		}
		
		window.setWidth(308);
		window.setFixedWidth(true);
		window.pack();
	}
	
	@Override
	protected void onResize()
	{
		buttonDatas.clear();
		
		// primary button
		String primaryAction = feature.getPrimaryAction();
		boolean hasPrimaryAction = !primaryAction.isEmpty();
		if(hasPrimaryAction)
		{
			primaryButton =
				class_4185.method_46430(class_2561.method_43470(primaryAction), b -> {
					TooManyHaxHack tooManyHax =
						WurstClient.INSTANCE.getHax().tooManyHaxHack;
					if(tooManyHax.isEnabled() && tooManyHax.isBlocked(feature))
					{
						ChatUtils.error(
							feature.getName() + " is blocked by TooManyHax.");
						return;
					}
					
					feature.doPrimaryAction();
					
					primaryButton
						.method_25355(class_2561.method_43470(feature.getPrimaryAction()));
					WurstClient.INSTANCE.getNavigator()
						.addPreference(feature.getName());
				}).method_46434(field_22789 / 2 - 151, field_22790 - 65, 302, 18).method_46431();
			method_37063(primaryButton);
		}
		
		// type
		text = "Type: ";
		if(feature instanceof Hack)
			text += "Hack";
		else if(feature instanceof Command)
			text += "Command";
		else
			text += "Other Feature";
		
		// category
		if(feature.getCategory() != null)
			text += ", Category: " + feature.getCategory().getName();
		
		// description
		String description = feature.getWrappedDescription(300);
		if(!description.isEmpty())
			text += "\n\nDescription:\n" + description;
		
		// area
		Rectangle area = new Rectangle(middleX - 154, 60, 308, field_22790 - 103);
		
		// settings
		Collection<Setting> settings = feature.getSettings().values();
		if(!settings.isEmpty())
		{
			text += "\n\nSettings:";
			windowComponentY = getStringHeight(text) + 2;
			
			for(int i = 0; i < Math.ceil(window.getInnerHeight() / 9.0); i++)
				text += "\n";
		}
		
		// keybinds
		Set<PossibleKeybind> possibleKeybinds = feature.getPossibleKeybinds();
		if(!possibleKeybinds.isEmpty())
		{
			// heading
			text += "\n\nKeybinds:";
			
			// add keybind button
			ButtonData addKeybindButton =
				new ButtonData(area.x + area.width - 16,
					area.y + getStringHeight(text) - 7, 12, 8, "+", 0x00ff00)
				{
					@Override
					public void press()
					{
						// add keybind
						WurstClient.MC.method_1507(new NavigatorNewKeybindScreen(
							possibleKeybinds, NavigatorFeatureScreen.this));
					}
				};
			buttonDatas.add(addKeybindButton);
			
			// keybind list
			HashMap<String, String> possibleKeybindsMap = new HashMap<>();
			for(PossibleKeybind possibleKeybind : possibleKeybinds)
				possibleKeybindsMap.put(possibleKeybind.getCommand(),
					possibleKeybind.getDescription());
			TreeMap<String, PossibleKeybind> existingKeybinds = new TreeMap<>();
			boolean noKeybindsSet = true;
			for(Keybind keybind : WurstClient.INSTANCE.getKeybinds()
				.getAllKeybinds())
			{
				String commands = keybind.getCommands();
				commands = commands.replace(";", "\u00a7")
					.replace("\u00a7\u00a7", ";");
				for(String command : commands.split("\u00a7"))
				{
					command = command.trim();
					String keybindDescription =
						possibleKeybindsMap.get(command);
					
					if(keybindDescription != null)
					{
						if(noKeybindsSet)
							noKeybindsSet = false;
						text +=
							"\n" + keybind.getKey().replace("key.keyboard.", "")
								+ ": " + keybindDescription;
						existingKeybinds.put(keybind.getKey(),
							new PossibleKeybind(command, keybindDescription));
						
					}else if(feature instanceof Hack
						&& command.equalsIgnoreCase(feature.getName()))
					{
						if(noKeybindsSet)
							noKeybindsSet = false;
						text +=
							"\n" + keybind.getKey().replace("key.keyboard.", "")
								+ ": " + "Toggle " + feature.getName();
						existingKeybinds.put(keybind.getKey(),
							new PossibleKeybind(command,
								"Toggle " + feature.getName()));
					}
				}
			}
			if(noKeybindsSet)
				text += "\nNone";
			else
			{
				// remove keybind button
				buttonDatas.add(new ButtonData(addKeybindButton.x,
					addKeybindButton.y, addKeybindButton.width,
					addKeybindButton.height, "-", 0xff0000)
				{
					@Override
					public void press()
					{
						// remove keybind
						field_22787.method_1507(new NavigatorRemoveKeybindScreen(
							existingKeybinds, NavigatorFeatureScreen.this));
					}
				});
				addKeybindButton.x -= 16;
			}
		}
		
		// text height
		setContentHeight(getStringHeight(text));
	}
	
	@Override
	protected void onKeyPress(int keyCode, int scanCode, int int_3)
	{
		if(keyCode == GLFW.GLFW_KEY_ESCAPE
			|| keyCode == GLFW.GLFW_KEY_BACKSPACE)
			goBack();
	}
	
	@Override
	protected void onMouseClick(double x, double y, int button)
	{
		// popups
		if(WurstClient.INSTANCE.getGui().handleNavigatorPopupClick(x, y,
			button))
			return;
		
		// back button
		if(button == GLFW.GLFW_MOUSE_BUTTON_4)
		{
			goBack();
			return;
		}
		
		boolean noButtons = Screens.getButtons(this).isEmpty();
		Rectangle area = new Rectangle(field_22789 / 2 - 154, 60, 308,
			field_22790 - 60 - (noButtons ? 43 : 67));
		if(!area.contains(x, y))
			return;
		
		// buttons
		if(activeButton != null)
		{
			field_22787.method_1483().method_4873(
				class_1109.method_47978(class_3417.field_15015, 1));
			activeButton.press();
			WurstClient.INSTANCE.getNavigator()
				.addPreference(feature.getName());
			return;
		}
		
		// component settings
		WurstClient.INSTANCE.getGui().handleNavigatorMouseClick(
			x - middleX + 154, y - 60 - scroll - windowComponentY, button,
			window);
	}
	
	private void goBack()
	{
		parent.setExpanding(false);
		field_22787.method_1507(parent);
	}
	
	@Override
	protected void onMouseDrag(double mouseX, double mouseY, int button,
		double double_3, double double_4)
	{
		
	}
	
	@Override
	protected void onMouseRelease(double x, double y, int button)
	{
		WurstClient.INSTANCE.getGui().handleMouseRelease(x, y, button);
	}
	
	@Override
	protected void onUpdate()
	{
		if(primaryButton != null)
			primaryButton.method_25355(class_2561.method_43470(feature.getPrimaryAction()));
	}
	
	@Override
	protected void onRender(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		class_4587 matrixStack = context.method_51448();
		ClickGui gui = WurstClient.INSTANCE.getGui();
		int txtColor = gui.getTxtColor();
		
		// title bar
		context.method_25300(field_22787.field_1772,
			feature.getName(), middleX, 32, txtColor);
		
		// background
		int bgx1 = middleX - 154;
		window.setX(bgx1);
		int bgx2 = middleX + 154;
		int bgy1 = 60;
		int bgy2 = field_22790 - 43;
		boolean noButtons = Screens.getButtons(this).isEmpty();
		int bgy3 = bgy2 - (noButtons ? 0 : 24);
		int windowY1 = bgy1 + scroll + windowComponentY;
		int windowY2 = windowY1 + window.getInnerHeight();
		
		context.method_25294(bgx1, bgy1, bgx2, class_3532.method_15340(windowY1, bgy1, bgy3),
			getBackgroundColor());
		context.method_25294(bgx1, class_3532.method_15340(windowY2, bgy1, bgy3), bgx2, bgy2,
			getBackgroundColor());
		RenderUtils.drawBoxShadow2D(context, bgx1, bgy1, bgx2, bgy2);
		
		context.method_44379(bgx1, bgy1, bgx2, bgy3);
		
		// settings
		gui.setTooltip("");
		window.validate();
		
		window.setY(windowY1 - 13);
		matrixStack.method_22903();
		matrixStack.method_46416(bgx1, windowY1, 0);
		
		{
			int x1 = 0;
			int y1 = -13;
			int x2 = x1 + window.getWidth();
			int y2 = y1 + window.getHeight();
			int y3 = y1 + 13;
			int x3 = x1 + 2;
			int x5 = x2 - 2;
			
			// window background
			// left & right
			int bgColor = getBackgroundColor();
			context.method_25294(x1, y3, x3, y2, bgColor);
			context.method_25294(x5, y3, x2, y2, bgColor);
			
			// window background
			// between children
			int xc1 = 2;
			int xc2 = x5 - x1;
			for(int i = 0; i < window.countChildren(); i++)
			{
				int yc1 = window.getChild(i).getY();
				int yc2 = yc1 - 2;
				if(yc1 < bgy1 - windowY1)
					continue;
				if(yc2 > bgy3 - windowY1)
					break;
				
				context.method_25294(xc1, yc1, xc2, yc2, bgColor);
			}
			
			// window background
			// bottom
			int yc1;
			if(window.countChildren() == 0)
				yc1 = 0;
			else
			{
				Component lastChild =
					window.getChild(window.countChildren() - 1);
				yc1 = lastChild.getY() + lastChild.getHeight();
			}
			int yc2 = yc1 + 2;
			context.method_25294(xc1, yc1, xc2, yc2, bgColor);
		}
		
		for(int i = 0; i < window.countChildren(); i++)
		{
			Component child = window.getChild(i);
			if(child.getY() + child.getHeight() < bgy1 - windowY1)
				continue;
			if(child.getY() > bgy3 - windowY1)
				break;
			
			child.render(context, mouseX - bgx1, mouseY - windowY1,
				partialTicks);
		}
		matrixStack.method_22909();
		
		// buttons
		activeButton = null;
		for(ButtonData buttonData : buttonDatas)
		{
			// positions
			int x1 = buttonData.x;
			int x2 = x1 + buttonData.width;
			int y1 = buttonData.y + scroll;
			int y2 = y1 + buttonData.height;
			
			// color
			float alpha;
			if(buttonData.isLocked())
				alpha = 0.25F;
			else if(mouseX >= x1 && mouseX <= x2 && mouseY >= y1
				&& mouseY <= y2)
			{
				alpha = 0.75F;
				activeButton = buttonData;
			}else
				alpha = 0.375F;
			float[] rgb = buttonData.color.getColorComponents(null);
			
			// button
			drawBox(context, x1, y1, x2, y2,
				RenderUtils.toIntColor(rgb, alpha));
			
			// text
			context.method_25300(field_22787.field_1772,
				buttonData.buttonText, (x1 + x2) / 2,
				y1 + (buttonData.height - 10) / 2 + 1,
				buttonData.isLocked() ? 0xaaaaaa : buttonData.textColor);
		}
		
		// text
		int textY = bgy1 + scroll + 2;
		for(String line : text.split("\n"))
		{
			context.method_51433(field_22787.field_1772, line, bgx1 + 2, textY,
				txtColor, false);
			textY += field_22787.field_1772.field_2000;
		}
		
		context.method_44380();
		
		// buttons below scissor box
		for(class_339 button : Screens.getButtons(this))
		{
			// positions
			int x1 = button.method_46426();
			int x2 = x1 + button.method_25368();
			int y1 = button.method_46427();
			int y2 = y1 + 18;
			
			// color
			boolean hovering =
				mouseX >= x1 && mouseX <= x2 && mouseY >= y1 && mouseY <= y2;
			int buttonColor;
			if(feature.isEnabled() && button == primaryButton)
				buttonColor = hovering ? 0x4000FF00 : 0x4000E000;
			else
				buttonColor = hovering ? 0x40606060 : 0x40404040;
			
			// button
			drawBox(context, x1, y1, x2, y2, buttonColor);
			
			// text
			String buttonText = button.method_25369().getString();
			context.method_51433(field_22787.field_1772, buttonText,
				(x1 + x2 - field_22787.field_1772.method_1727(buttonText)) / 2,
				y1 + 5, txtColor, false);
		}
		
		// popups & tooltip
		gui.renderPopups(context, mouseX, mouseY);
		gui.renderTooltip(context, mouseX, mouseY);
	}
	
	@Override
	public void method_25419()
	{
		window.close();
		WurstClient.INSTANCE.getGui().handleMouseClick(Integer.MIN_VALUE,
			Integer.MIN_VALUE, 0);
	}
	
	public Feature getFeature()
	{
		return feature;
	}
	
	public int getMiddleX()
	{
		return middleX;
	}
	
	public void addText(String text)
	{
		this.text += text;
	}
	
	public int getTextHeight()
	{
		return getStringHeight(text);
	}
	
	public abstract static class ButtonData extends Rectangle
	{
		public String buttonText;
		public Color color;
		public int textColor = 0xffffff;
		
		public ButtonData(int x, int y, int width, int height,
			String buttonText, int color)
		{
			super(x, y, width, height);
			this.buttonText = buttonText;
			this.color = new Color(color);
		}
		
		public abstract void press();
		
		public boolean isLocked()
		{
			return false;
		}
	}
}
