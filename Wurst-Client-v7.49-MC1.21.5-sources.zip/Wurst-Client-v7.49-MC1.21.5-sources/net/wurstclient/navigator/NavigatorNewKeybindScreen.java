/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.navigator;

import java.util.Set;
import java.util.function.Supplier;

import org.lwjgl.glfw.GLFW;

import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.wurstclient.WurstClient;
import net.wurstclient.clickgui.ClickGui;
import net.wurstclient.keybinds.PossibleKeybind;

public class NavigatorNewKeybindScreen extends NavigatorScreen
{
	private Set<PossibleKeybind> possibleKeybinds;
	private NavigatorFeatureScreen parent;
	private PossibleKeybind hoveredCommand;
	private PossibleKeybind selectedCommand;
	private String selectedKey = "key.keyboard.unknown";
	private String text = "";
	private class_4185 okButton;
	private boolean choosingKey;
	
	public NavigatorNewKeybindScreen(Set<PossibleKeybind> possibleKeybinds,
		NavigatorFeatureScreen parent)
	{
		this.possibleKeybinds = possibleKeybinds;
		this.parent = parent;
	}
	
	@Override
	protected void onResize()
	{
		// OK button
		okButton = new class_4185(field_22789 / 2 - 151, field_22790 - 65, 149, 18,
			class_2561.method_43470("OK"), b -> {
				if(choosingKey)
				{
					String newCommands = selectedCommand.getCommand();
					
					String oldCommands = WurstClient.INSTANCE.getKeybinds()
						.getCommands(selectedKey);
					if(oldCommands != null)
						newCommands = oldCommands + " ; " + newCommands;
					
					WurstClient.INSTANCE.getKeybinds().add(selectedKey,
						newCommands);
					
					WurstClient.INSTANCE.getNavigator()
						.addPreference(parent.getFeature().getName());
					field_22787.method_1507(parent);
				}else
				{
					choosingKey = true;
					okButton.field_22763 = false;
				}
			}, Supplier::get)
		{
			@Override
			public boolean method_25404(int keyCode, int scanCode, int modifiers)
			{
				// empty method so that pressing Enter won't trigger this button
				return false;
			}
		};
		okButton.field_22763 = selectedCommand != null;
		method_37063(okButton);
		
		// cancel button
		method_37063(class_4185
			.method_46430(class_2561.method_43470("Cancel"),
				b -> WurstClient.MC.method_1507(parent))
			.method_46434(field_22789 / 2 + 2, field_22790 - 65, 149, 18).method_46431());
	}
	
	@Override
	protected void onKeyPress(int keyCode, int scanCode, int int_3)
	{
		if(choosingKey)
		{
			selectedKey =
				class_3675.method_15985(keyCode, scanCode).method_1441();
			okButton.field_22763 = !selectedKey.equals("key.keyboard.unknown");
			
		}else if(keyCode == GLFW.GLFW_KEY_ESCAPE
			|| keyCode == GLFW.GLFW_KEY_BACKSPACE)
			field_22787.method_1507(parent);
	}
	
	@Override
	protected void onMouseClick(double x, double y, int button)
	{
		// back button
		if(button == GLFW.GLFW_MOUSE_BUTTON_4)
		{
			field_22787.method_1507(parent);
			return;
		}
		
		// commands
		if(hoveredCommand != null)
		{
			selectedCommand = hoveredCommand;
			okButton.field_22763 = true;
		}
	}
	
	@Override
	protected void onUpdate()
	{
		// text
		if(choosingKey)
		{
			text = "Now press the key that should trigger this keybind.";
			if(!selectedKey.equals("key.keyboard.unknown"))
			{
				text += "\n\nKey: " + selectedKey.replace("key.keyboard.", "");
				String commands =
					WurstClient.INSTANCE.getKeybinds().getCommands(selectedKey);
				if(commands != null)
				{
					text +=
						"\n\nWARNING: This key is already bound to the following\ncommand(s):";
					commands = commands.replace(";", "\u00a7")
						.replace("\u00a7\u00a7", ";");
					
					for(String cmd : commands.split("\u00a7"))
						text += "\n- " + cmd;
				}
			}
		}else
			text = "Select what this keybind should do.";
		
		// content height
		if(choosingKey)
			setContentHeight(getStringHeight(text));
		else
			setContentHeight(possibleKeybinds.size() * 24 - 10);
	}
	
	@Override
	protected void onRender(class_332 context, int mouseX, int mouseY,
		float partialTicks)
	{
		ClickGui gui = WurstClient.INSTANCE.getGui();
		class_327 tr = field_22787.field_1772;
		int txtColor = gui.getTxtColor();
		
		// title bar
		context.method_25300(tr, "New Keybind", middleX, 32,
			txtColor);
		
		// background
		int bgx1 = middleX - 154;
		int bgx2 = middleX + 154;
		int bgy1 = 60;
		int bgy2 = field_22790 - 43;
		boolean noButtons = Screens.getButtons(this).isEmpty();
		int bgy3 = bgy2 - (noButtons ? 0 : 24);
		
		context.method_44379(bgx1, bgy1, bgx2, bgy3);
		
		// possible keybinds
		if(!choosingKey)
		{
			hoveredCommand = null;
			int yi = bgy1 - 12 + scroll;
			for(PossibleKeybind pkb : possibleKeybinds)
			{
				yi += 24;
				
				// positions
				int x1 = bgx1 + 2;
				int x2 = bgx2 - 2;
				int y1 = yi;
				int y2 = y1 + 20;
				
				// color
				int buttonColor;
				if(mouseX >= x1 && mouseX <= x2 && mouseY >= y1 && mouseY <= y2
					&& mouseY <= bgy2 - 24)
				{
					hoveredCommand = pkb;
					if(pkb == selectedCommand)
						buttonColor = 0x6000FF00;
					else
						buttonColor = 0x60404040;
				}else if(pkb == selectedCommand)
					buttonColor = 0x4000FF00;
				else
					buttonColor = 0x40404040;
				
				// button
				drawBox(context, x1, y1, x2, y2, buttonColor);
				
				// text
				context.method_25303(tr, pkb.getDescription(), x1 + 1,
					y1 + 1, txtColor);
				context.method_25303(tr, pkb.getCommand(), x1 + 1,
					y1 + 1 + tr.field_2000, txtColor);
			}
		}
		
		// text
		int textY = bgy1 + scroll + 2;
		for(String line : text.split("\n"))
		{
			context.method_25303(tr, line, bgx1 + 2, textY, txtColor);
			textY += tr.field_2000;
		}
		
		context.method_44380();
		
		// buttons below scissor box
		for(class_339 button : Screens.getButtons(this))
		{
			// positions
			int x1 = button.method_46426();
			int x2 = x1 + button.method_25368();
			int y1 = button.method_46427();
			int y2 = y1 + 18;
			
			// color
			int buttonColor;
			if(!button.field_22763)
				buttonColor = 0x40000000;
			else if(mouseX >= x1 && mouseX <= x2 && mouseY >= y1
				&& mouseY <= y2)
				buttonColor = 0x40606060;
			else
				buttonColor = 0x40404040;
			
			// button
			drawBox(context, x1, y1, x2, y2, buttonColor);
			
			// text
			context.method_25300(tr,
				button.method_25369().getString(), (x1 + x2) / 2, y1 + 5,
				txtColor);
		}
	}
	
	@Override
	protected void onMouseDrag(double mouseX, double mouseY, int button,
		double double_3, double double_4)
	{
		
	}
	
	@Override
	protected void onMouseRelease(double x, double y, int button)
	{
		
	}
	
	@Override
	public boolean method_25422()
	{
		return false;
	}
}
