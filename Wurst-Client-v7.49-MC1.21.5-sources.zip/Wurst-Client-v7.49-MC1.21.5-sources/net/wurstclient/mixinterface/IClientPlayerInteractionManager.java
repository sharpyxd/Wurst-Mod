/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixinterface;

import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2846;
import net.minecraft.class_3965;

public interface IClientPlayerInteractionManager
{
	public void windowClick_PICKUP(int slot);
	
	public void windowClick_QUICK_MOVE(int slot);
	
	public void windowClick_THROW(int slot);
	
	public void windowClick_SWAP(int from, int to);
	
	public void rightClickItem();
	
	public void rightClickBlock(class_2338 pos, class_2350 side, class_243 hitVec);
	
	public void sendPlayerActionC2SPacket(class_2846.class_2847 action,
		class_2338 blockPos, class_2350 direction);
	
	public void sendPlayerInteractBlockPacket(class_1268 hand,
		class_3965 blockHitResult);
}
