/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.wurstclient.Category;
import net.wurstclient.events.RightClickListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;

public final class ThrowHack extends Hack implements RightClickListener
{
	private final SliderSetting amount = new SliderSetting("Amount",
		"Amount of uses per click.", 16, 2, 1000000, 1, ValueDisplay.INTEGER);
	
	public ThrowHack()
	{
		super("Throw");
		
		setCategory(Category.OTHER);
		addSetting(amount);
	}
	
	@Override
	public String getRenderName()
	{
		return getName() + " [" + amount.getValueString() + "]";
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(RightClickListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(RightClickListener.class, this);
	}
	
	@Override
	public void onRightClick(RightClickEvent event)
	{
		if(MC.field_1752 > 0)
			return;
		
		if(!MC.field_1690.field_1904.method_1434())
			return;
		
		for(int i = 0; i < amount.getValueI(); i++)
		{
			if(MC.field_1765.method_17783() == class_239.class_240.field_1332)
			{
				class_3965 hitResult = (class_3965)MC.field_1765;
				IMC.getInteractionManager().rightClickBlock(
					hitResult.method_17777(), hitResult.method_17780(),
					hitResult.method_17784());
			}
			
			IMC.getInteractionManager().rightClickItem();
		}
	}
}
