/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.awt.Color;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.RenderListener;
import net.wurstclient.events.RightClickListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.ColorSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.util.InteractionSimulator;
import net.wurstclient.util.RenderUtils;

@SearchTags({"air place"})
public final class AirPlaceHack extends Hack
	implements RightClickListener, UpdateListener, RenderListener
{
	private final SliderSetting range =
		new SliderSetting("Range", 5, 1, 6, 0.05, ValueDisplay.DECIMAL);
	
	private final CheckboxSetting guide = new CheckboxSetting("Guide",
		"description.wurst.setting.airplace.guide", true);
	
	private final ColorSetting guideColor = new ColorSetting("Guide color",
		"description.wurst.setting.airplace.guide_color", Color.RED);
	
	private class_2338 renderPos;
	
	public AirPlaceHack()
	{
		super("AirPlace");
		setCategory(Category.BLOCKS);
		addSetting(range);
		addSetting(guide);
		addSetting(guideColor);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(RenderListener.class, this);
		EVENTS.add(RightClickListener.class, this);
		renderPos = null;
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		EVENTS.remove(RightClickListener.class, this);
	}
	
	@Override
	public void onRightClick(RightClickEvent event)
	{
		class_3965 hitResult = getHitResultIfMissed();
		if(hitResult == null)
			return;
		
		MC.field_1752 = 4;
		if(MC.field_1724.method_3144())
			return;
		
		InteractionSimulator.rightClickBlock(hitResult);
		event.cancel();
	}
	
	@Override
	public void onUpdate()
	{
		renderPos = null;
		
		if(!guide.isChecked())
			return;
		
		if(MC.field_1724.method_6047().method_7960()
			&& MC.field_1724.method_6079().method_7960())
			return;
		
		if(MC.field_1724.method_3144())
			return;
		
		class_3965 hitResult = getHitResultIfMissed();
		if(hitResult != null)
			renderPos = hitResult.method_17777();
	}
	
	private class_3965 getHitResultIfMissed()
	{
		class_239 hitResult = MC.field_1724.method_5745(range.getValue(), 0, false);
		if(hitResult.method_17783() != class_239.class_240.field_1333)
			return null;
		
		if(!(hitResult instanceof class_3965 blockHitResult))
			return null;
		
		return blockHitResult;
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		if(renderPos == null)
			return;
		
		class_238 box = new class_238(renderPos);
		
		int quadColor = guideColor.getColorI(0x1A);
		RenderUtils.drawSolidBox(matrixStack, box, quadColor, false);
		
		int lineColor = guideColor.getColorI(0xC0);
		RenderUtils.drawOutlinedBox(matrixStack, box, lineColor, false);
	}
}
