/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.autolibrarian;

import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_2960;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9636;
import net.wurstclient.WurstClient;
import net.wurstclient.WurstTranslator;

public record BookOffer(String id, int level, int price)
	implements Comparable<BookOffer>
{
	public static BookOffer create(class_1887 enchantment)
	{
		class_5455 drm = WurstClient.MC.field_1687.method_30349();
		class_2378<class_1887> registry =
			drm.method_30530(class_7924.field_41265);
		class_2960 id = registry.method_10221(enchantment);
		return new BookOffer("" + id, enchantment.method_8183(), 64);
	}
	
	public Optional<? extends class_6880<class_1887>> getEnchantmentEntry()
	{
		if(WurstClient.MC.field_1687 == null)
			return Optional.empty();
		
		class_5455 drm = WurstClient.MC.field_1687.method_30349();
		class_2378<class_1887> registry =
			drm.method_30530(class_7924.field_41265);
		return registry.method_10223(class_2960.method_60654(id));
	}
	
	public class_1887 getEnchantment()
	{
		return getEnchantmentEntry().map(class_6880::comp_349).orElse(null);
	}
	
	public String getEnchantmentName()
	{
		class_2561 description = getEnchantment().comp_2686();
		if(description.method_10851() instanceof class_2588 tr)
			return WurstClient.INSTANCE.getTranslator()
				.translateMcEnglish(tr.method_11022());
		
		return description.getString();
	}
	
	public String getEnchantmentNameWithLevel()
	{
		WurstTranslator translator = WurstClient.INSTANCE.getTranslator();
		class_1887 enchantment = getEnchantment();
		String name;
		
		if(enchantment.comp_2686()
			.method_10851() instanceof class_2588 tr)
			name = translator.translateMcEnglish(tr.method_11022());
		else
			name = enchantment.comp_2686().getString();
		
		if(enchantment.method_8183() > 1)
			name += " "
				+ translator.translateMcEnglish("enchantment.level." + level);
		
		return name;
	}
	
	public String getFormattedPrice()
	{
		return price + " emerald" + (price == 1 ? "" : "s");
	}
	
	/**
	 * Fully validates the book offer using the dynamic enchantment registry.
	 * Will return false if called while the user is not in a world or server.
	 */
	public boolean isFullyValid()
	{
		return isMostlyValid() && getEnchantmentEntry()
			.map(entry -> entry.method_40220(class_9636.field_51545)
				&& level <= entry.comp_349().method_8183())
			.orElse(false);
	}
	
	/**
	 * Tries to validate the book offer without using dynamic registries, which
	 * aren't loaded until the user enters a world or server.
	 */
	public boolean isMostlyValid()
	{
		return class_2960.method_12829(id) != null && level >= 1 && price >= 1
			&& price <= 64;
	}
	
	@Override
	public int compareTo(BookOffer other)
	{
		int idCompare = id.compareTo(other.id);
		if(idCompare != 0)
			return idCompare;
		
		return Integer.compare(level, other.level);
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if(this == obj)
			return true;
		
		if(obj == null || getClass() != obj.getClass())
			return false;
		
		BookOffer other = (BookOffer)obj;
		return id.equals(other.id) && level == other.level;
	}
	
	@Override
	public int hashCode()
	{
		return Objects.hash(id, level);
	}
}
