/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2211;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2266;
import net.minecraft.class_2282;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_2391;
import net.minecraft.class_2421;
import net.minecraft.class_243;
import net.minecraft.class_2492;
import net.minecraft.class_2523;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_4587;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.RenderListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.hacks.autofarm.AutoFarmRenderer;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.settings.SwingHandSetting.SwingHand;
import net.wurstclient.util.BlockBreaker;
import net.wurstclient.util.BlockBreakingCache;
import net.wurstclient.util.BlockPlacer;
import net.wurstclient.util.BlockPlacer.BlockPlacingParams;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.InventoryUtils;
import net.wurstclient.util.OverlayRenderer;
import net.wurstclient.util.RotationUtils;

@SearchTags({"auto farm", "AutoHarvest", "auto harvest"})
public final class AutoFarmHack extends Hack
	implements UpdateListener, RenderListener
{
	private final SliderSetting range =
		new SliderSetting("Range", 5, 1, 6, 0.05, ValueDisplay.DECIMAL);
	
	private final CheckboxSetting replant =
		new CheckboxSetting("Replant", true);
	
	private final HashMap<class_2248, class_1792> seeds = new HashMap<>();
	{
		seeds.put(class_2246.field_10293, class_1802.field_8317);
		seeds.put(class_2246.field_10609, class_1802.field_8179);
		seeds.put(class_2246.field_10247, class_1802.field_8567);
		seeds.put(class_2246.field_10341, class_1802.field_8309);
		seeds.put(class_2246.field_46286, class_1802.field_46249);
		seeds.put(class_2246.field_46287, class_1802.field_46250);
		seeds.put(class_2246.field_9974, class_1802.field_8790);
		seeds.put(class_2246.field_10302, class_1802.field_8116);
	}
	
	private final HashMap<class_2338, class_1792> plants = new HashMap<>();
	private final BlockBreakingCache cache = new BlockBreakingCache();
	private class_2338 currentlyHarvesting;
	
	private final AutoFarmRenderer renderer = new AutoFarmRenderer();
	private final OverlayRenderer overlay = new OverlayRenderer();
	
	private boolean busy;
	
	public AutoFarmHack()
	{
		super("AutoFarm");
		
		setCategory(Category.BLOCKS);
		addSetting(range);
		addSetting(replant);
	}
	
	@Override
	protected void onEnable()
	{
		plants.clear();
		
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(RenderListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		
		if(currentlyHarvesting != null)
		{
			MC.field_1761.field_3717 = true;
			MC.field_1761.method_2925();
			currentlyHarvesting = null;
		}
		
		cache.reset();
		overlay.resetProgress();
		busy = false;
		
		renderer.reset();
	}
	
	@Override
	public void onUpdate()
	{
		currentlyHarvesting = null;
		class_243 eyesVec = RotationUtils.getEyesPos();
		class_2338 eyesBlock = class_2338.method_49638(eyesVec);
		double rangeSq = range.getValueSq();
		int blockRange = range.getValueCeil();
		
		// get nearby, non-empty blocks
		ArrayList<class_2338> blocks =
			BlockUtils.getAllInBoxStream(eyesBlock, blockRange)
				.filter(pos -> pos.method_19770(eyesVec) <= rangeSq)
				.filter(BlockUtils::canBeClicked)
				.collect(Collectors.toCollection(ArrayList::new));
		
		// check for any new plants and add them to the map
		updatePlants(blocks);
		
		ArrayList<class_2338> blocksToHarvest = new ArrayList<>();
		ArrayList<class_2338> blocksToReplant = new ArrayList<>();
		
		// don't place or break any blocks while Freecam is enabled
		if(!WURST.getHax().freecamHack.isEnabled())
		{
			// check which of the nearby blocks can be harvested
			blocksToHarvest = getBlocksToHarvest(eyesVec, blocks);
			
			// do a new search to find empty blocks that can be replanted
			if(replant.isChecked())
				blocksToReplant =
					getBlocksToReplant(eyesVec, eyesBlock, rangeSq, blockRange);
		}
		
		// first, try to replant
		boolean replanting = replant(blocksToReplant);
		
		// if we can't replant, harvest instead
		if(!replanting)
			harvest(blocksToHarvest.stream());
		
		// update busy state
		busy = replanting || currentlyHarvesting != null;
		
		// update renderer
		renderer.updateVertexBuffers(blocksToHarvest, plants.keySet(),
			blocksToReplant);
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		renderer.render(matrixStack);
		overlay.render(matrixStack, partialTicks, currentlyHarvesting);
	}
	
	/**
	 * Returns true if AutoFarm is currently harvesting or replanting something.
	 */
	public boolean isBusy()
	{
		return busy;
	}
	
	private void updatePlants(List<class_2338> blocks)
	{
		for(class_2338 pos : blocks)
		{
			class_1792 seed = seeds.get(BlockUtils.getBlock(pos));
			if(seed == null)
				continue;
			
			plants.put(pos, seed);
		}
	}
	
	private ArrayList<class_2338> getBlocksToHarvest(class_243 eyesVec,
		ArrayList<class_2338> blocks)
	{
		return blocks.parallelStream().filter(this::shouldBeHarvested)
			.sorted(Comparator
				.comparingDouble(pos -> pos.method_19770(eyesVec)))
			.collect(Collectors.toCollection(ArrayList::new));
	}
	
	private boolean shouldBeHarvested(class_2338 pos)
	{
		class_2248 block = BlockUtils.getBlock(pos);
		class_2680 state = BlockUtils.getState(pos);
		
		if(block instanceof class_2302)
			return ((class_2302)block).method_9825(state);
		
		if(block instanceof class_2421)
			return state.method_11654(class_2421.field_11306) >= 3;
		
		if(block instanceof class_2282)
			return state.method_11654(class_2282.field_10779) >= 2;
		
		if(block == class_2246.field_46282 || block == class_2246.field_46283)
			return true;
		
		if(block instanceof class_2523)
			return BlockUtils.getBlock(pos.method_10074()) instanceof class_2523
				&& !(BlockUtils
					.getBlock(pos.method_10087(2)) instanceof class_2523);
		
		if(block instanceof class_2266)
			return BlockUtils.getBlock(pos.method_10074()) instanceof class_2266
				&& !(BlockUtils.getBlock(pos.method_10087(2)) instanceof class_2266);
		
		if(block instanceof class_2391)
			return BlockUtils.getBlock(pos.method_10074()) instanceof class_2391
				&& !(BlockUtils
					.getBlock(pos.method_10087(2)) instanceof class_2391);
		
		if(block instanceof class_2211)
			return BlockUtils.getBlock(pos.method_10074()) instanceof class_2211
				&& !(BlockUtils.getBlock(pos.method_10087(2)) instanceof class_2211);
		
		return false;
	}
	
	private ArrayList<class_2338> getBlocksToReplant(class_243 eyesVec,
		class_2338 eyesBlock, double rangeSq, int blockRange)
	{
		return BlockUtils.getAllInBoxStream(eyesBlock, blockRange)
			.filter(pos -> pos.method_19770(eyesVec) <= rangeSq)
			.filter(pos -> BlockUtils.getState(pos).method_45474())
			.filter(pos -> plants.containsKey(pos)).filter(this::canBeReplanted)
			.sorted(Comparator
				.comparingDouble(pos -> pos.method_19770(eyesVec)))
			.collect(Collectors.toCollection(ArrayList::new));
	}
	
	private boolean canBeReplanted(class_2338 pos)
	{
		class_1792 item = plants.get(pos);
		
		if(item == class_1802.field_8317 || item == class_1802.field_8179
			|| item == class_1802.field_8567 || item == class_1802.field_8309
			|| item == class_1802.field_46249 || item == class_1802.field_46250)
			return BlockUtils.getBlock(pos.method_10074()) instanceof class_2344;
		
		if(item == class_1802.field_8790)
			return BlockUtils.getBlock(pos.method_10074()) instanceof class_2492;
		
		if(item == class_1802.field_8116)
			return BlockUtils.getState(pos.method_10095()).method_26164(class_3481.field_15474)
				|| BlockUtils.getState(pos.method_10078()).method_26164(class_3481.field_15474)
				|| BlockUtils.getState(pos.method_10072()).method_26164(class_3481.field_15474)
				|| BlockUtils.getState(pos.method_10067()).method_26164(class_3481.field_15474);
		
		return false;
	}
	
	private boolean replant(List<class_2338> blocksToReplant)
	{
		// check cooldown
		if(MC.field_1752 > 0)
			return false;
		
		// check if already holding one of the seeds needed for blocksToReplant
		Optional<class_1792> heldSeed = blocksToReplant.stream().map(plants::get)
			.distinct().filter(item -> MC.field_1724.method_24518(item)).findFirst();
		
		// if so, try to replant the blocks that need that seed
		if(heldSeed.isPresent())
		{
			// get the seed and the hand that is holding it
			class_1792 item = heldSeed.get();
			class_1268 hand = MC.field_1724.method_6047().method_31574(item) ? class_1268.field_5808
				: class_1268.field_5810;
			
			// filter out blocks that need a different seed
			ArrayList<class_2338> blocksToReplantWithHeldSeed =
				blocksToReplant.stream().filter(pos -> plants.get(pos) == item)
					.collect(Collectors.toCollection(ArrayList::new));
			
			for(class_2338 pos : blocksToReplantWithHeldSeed)
			{
				// skip over blocks that we can't reach
				BlockPlacingParams params =
					BlockPlacer.getBlockPlacingParams(pos);
				if(params == null || params.distanceSq() > range.getValueSq())
					continue;
				
				// face block
				WURST.getRotationFaker().faceVectorPacket(params.hitVec());
				
				// place seed
				class_1269 result = MC.field_1761
					.method_2896(MC.field_1724, hand, params.toHitResult());
				
				// swing arm
				// Note: All SwingHand types correspond to SwingSource.CLIENT
				if(result instanceof class_1269.class_9860 success
					&& success.comp_2909() == class_1269.class_9861.field_52427)
					SwingHand.SERVER.swing(hand); // intentional use of SERVER
					
				// reset cooldown
				MC.field_1752 = 4;
				return true;
			}
		}
		
		// otherwise, find a block that we can reach and have seeds for
		for(class_2338 pos : blocksToReplant)
		{
			// skip over blocks that we can't reach
			BlockPlacingParams params = BlockPlacer.getBlockPlacingParams(pos);
			if(params == null || params.distanceSq() > range.getValueSq())
				continue;
			
			// try to select the seed (returns false if we don't have it)
			class_1792 item = plants.get(pos);
			if(InventoryUtils.selectItem(item))
				return true;
		}
		
		// if we couldn't replant anything, return false
		return false;
	}
	
	private void harvest(Stream<class_2338> stream)
	{
		// Break all blocks in creative mode
		if(MC.field_1724.method_31549().field_7477)
		{
			MC.field_1761.method_2925();
			overlay.resetProgress();
			
			ArrayList<class_2338> blocks = cache.filterOutRecentBlocks(stream);
			if(blocks.isEmpty())
				return;
			
			currentlyHarvesting = blocks.get(0);
			BlockBreaker.breakBlocksWithPacketSpam(blocks);
			return;
		}
		
		// Break the first valid block in survival mode
		currentlyHarvesting =
			stream.filter(BlockBreaker::breakOneBlock).findFirst().orElse(null);
		
		if(currentlyHarvesting == null)
		{
			MC.field_1761.method_2925();
			overlay.resetProgress();
			return;
		}
		
		overlay.updateProgress();
	}
}
