/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4969;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.EnumSetting;
import net.wurstclient.settings.FacingSetting;
import net.wurstclient.settings.FacingSetting.Facing;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.settings.SwingHandSetting;
import net.wurstclient.settings.SwingHandSetting.SwingHand;
import net.wurstclient.settings.filterlists.AnchorAuraFilterList;
import net.wurstclient.settings.filterlists.EntityFilterList;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.FakePlayerEntity;
import net.wurstclient.util.InventoryUtils;
import net.wurstclient.util.RotationUtils;

@SearchTags({"anchor aura", "CrystalAura", "crystal aura"})
public final class AnchorAuraHack extends Hack implements UpdateListener
{
	private final SliderSetting range =
		new SliderSetting("Range", "description.wurst.setting.anchoraura.range",
			6, 1, 6, 0.05, ValueDisplay.DECIMAL);
	
	private final CheckboxSetting autoPlace =
		new CheckboxSetting("Auto-place anchors",
			"description.wurst.setting.anchoraura.auto-place_anchors", true);
	
	private final FacingSetting faceBlocks =
		FacingSetting.withPacketSpam("Face anchors",
			"description.wurst.setting.anchoraura.face_anchors", Facing.OFF);
	
	private final CheckboxSetting checkLOS =
		new CheckboxSetting("Check line of sight",
			"description.wurst.setting.anchoraura.check_line_of_sight", false);
	
	private final SwingHandSetting swingHand =
		new SwingHandSetting(this, SwingHand.CLIENT);
	
	private final EnumSetting<TakeItemsFrom> takeItemsFrom =
		new EnumSetting<>("Take items from",
			"description.wurst.setting.anchoraura.take_items_from",
			TakeItemsFrom.values(), TakeItemsFrom.INVENTORY);
	
	private final EntityFilterList entityFilters =
		AnchorAuraFilterList.create();
	
	public AnchorAuraHack()
	{
		super("AnchorAura");
		
		setCategory(Category.COMBAT);
		addSetting(range);
		addSetting(autoPlace);
		addSetting(faceBlocks);
		addSetting(checkLOS);
		addSetting(swingHand);
		addSetting(takeItemsFrom);
		
		entityFilters.forEach(this::addSetting);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(MC.field_1687.method_8597().comp_649())
		{
			ChatUtils.error("Respawn anchors don't explode in this dimension.");
			setEnabled(false);
		}
		
		ArrayList<class_2338> anchors = getNearbyAnchors();
		
		Map<Boolean, ArrayList<class_2338>> anchorsByCharge = anchors.stream()
			.collect(Collectors.partitioningBy(this::isChargedAnchor,
				Collectors.toCollection(ArrayList::new)));
		
		ArrayList<class_2338> chargedAnchors = anchorsByCharge.get(true);
		ArrayList<class_2338> unchargedAnchors = anchorsByCharge.get(false);
		
		if(!chargedAnchors.isEmpty())
		{
			detonate(chargedAnchors);
			return;
		}
		
		int maxInvSlot = takeItemsFrom.getSelected().maxInvSlot;
		
		if(!unchargedAnchors.isEmpty()
			&& InventoryUtils.indexOf(class_1802.field_8801, maxInvSlot) >= 0)
		{
			charge(unchargedAnchors);
			// TODO: option to wait until next tick?
			detonate(unchargedAnchors);
			return;
		}
		
		if(!autoPlace.isChecked()
			|| InventoryUtils.indexOf(class_1802.field_23141, maxInvSlot) == -1)
			return;
		
		ArrayList<class_1297> targets = getNearbyTargets();
		ArrayList<class_2338> newAnchors = placeAnchorsNear(targets);
		
		if(!newAnchors.isEmpty()
			&& InventoryUtils.indexOf(class_1802.field_8801, maxInvSlot) >= 0)
		{
			// TODO: option to wait until next tick?
			charge(newAnchors);
			detonate(newAnchors);
		}
	}
	
	private ArrayList<class_2338> placeAnchorsNear(ArrayList<class_1297> targets)
	{
		ArrayList<class_2338> newAnchors = new ArrayList<>();
		
		boolean shouldSwing = false;
		for(class_1297 target : targets)
		{
			ArrayList<class_2338> freeBlocks = getFreeBlocksNear(target);
			
			for(class_2338 pos : freeBlocks)
				if(placeAnchor(pos))
				{
					shouldSwing = true;
					newAnchors.add(pos);
					
					// TODO optional speed limit(?)
					break;
				}
		}
		
		if(shouldSwing)
			swingHand.swing(class_1268.field_5808);
		
		return newAnchors;
	}
	
	private void detonate(ArrayList<class_2338> chargedAnchors)
	{
		if(isSneaking())
			return;
		
		InventoryUtils.selectItem(stack -> !stack.method_31574(class_1802.field_8801),
			takeItemsFrom.getSelected().maxInvSlot);
		if(MC.field_1724.method_24518(class_1802.field_8801))
			return;
		
		boolean shouldSwing = false;
		
		for(class_2338 pos : chargedAnchors)
			if(rightClickBlock(pos))
				shouldSwing = true;
			
		if(shouldSwing)
			swingHand.swing(class_1268.field_5808);
	}
	
	private void charge(ArrayList<class_2338> unchargedAnchors)
	{
		if(isSneaking())
			return;
		
		InventoryUtils.selectItem(class_1802.field_8801,
			takeItemsFrom.getSelected().maxInvSlot);
		if(!MC.field_1724.method_24518(class_1802.field_8801))
			return;
		
		boolean shouldSwing = false;
		
		for(class_2338 pos : unchargedAnchors)
			if(rightClickBlock(pos))
				shouldSwing = true;
			
		if(shouldSwing)
			swingHand.swing(class_1268.field_5808);
	}
	
	private boolean rightClickBlock(class_2338 pos)
	{
		class_243 eyesPos = RotationUtils.getEyesPos();
		class_243 posVec = class_243.method_24953(pos);
		double distanceSqPosVec = eyesPos.method_1025(posVec);
		
		for(class_2350 side : class_2350.values())
		{
			class_243 hitVec = posVec.method_1019(class_243.method_24954(side.method_62675()).method_1021(0.5));
			double distanceSqHitVec = eyesPos.method_1025(hitVec);
			
			// check if hitVec is within range (6 blocks)
			if(distanceSqHitVec > 36)
				continue;
			
			// check if side is facing towards player
			if(distanceSqHitVec >= distanceSqPosVec)
				continue;
			
			if(checkLOS.isChecked()
				&& !BlockUtils.hasLineOfSight(eyesPos, hitVec))
				continue;
			
			faceBlocks.getSelected().face(hitVec);
			
			// place block
			IMC.getInteractionManager().rightClickBlock(pos, side, hitVec);
			
			return true;
		}
		
		return false;
	}
	
	private boolean placeAnchor(class_2338 pos)
	{
		class_243 eyesPos = RotationUtils.getEyesPos();
		double rangeSq = range.getValueSq();
		class_243 posVec = class_243.method_24953(pos);
		double distanceSqPosVec = eyesPos.method_1025(posVec);
		
		for(class_2350 side : class_2350.values())
		{
			class_2338 neighbor = pos.method_10093(side);
			
			// check if neighbor can be right clicked
			if(!isClickableNeighbor(neighbor))
				continue;
			
			class_243 dirVec = class_243.method_24954(side.method_62675());
			class_243 hitVec = posVec.method_1019(dirVec.method_1021(0.5));
			
			// check if hitVec is within range
			if(eyesPos.method_1025(hitVec) > rangeSq)
				continue;
			
			// check if side is visible (facing away from player)
			if(distanceSqPosVec > eyesPos.method_1025(posVec.method_1019(dirVec)))
				continue;
			
			if(checkLOS.isChecked()
				&& !BlockUtils.hasLineOfSight(eyesPos, hitVec))
				continue;
			
			InventoryUtils.selectItem(class_1802.field_23141,
				takeItemsFrom.getSelected().maxInvSlot);
			if(!MC.field_1724.method_24518(class_1802.field_23141))
				return false;
			
			faceBlocks.getSelected().face(hitVec);
			
			// place block
			IMC.getInteractionManager().rightClickBlock(neighbor,
				side.method_10153(), hitVec);
			
			return true;
		}
		
		return false;
	}
	
	private ArrayList<class_2338> getNearbyAnchors()
	{
		class_243 eyesVec = RotationUtils.getEyesPos().method_1023(0.5, 0.5, 0.5);
		class_2338 center = class_2338.method_49638(RotationUtils.getEyesPos());
		int rangeI = range.getValueCeil();
		double rangeSq = class_3532.method_33723(range.getValue() + 0.5);
		
		Comparator<class_2338> furthestFromPlayer =
			Comparator.<class_2338> comparingDouble(
				pos -> eyesVec.method_1025(class_243.method_24954(pos))).reversed();
		
		return BlockUtils.getAllInBoxStream(center, rangeI)
			.filter(pos -> eyesVec.method_1025(class_243.method_24954(pos)) <= rangeSq)
			.filter(pos -> BlockUtils.getBlock(pos) == class_2246.field_23152)
			.sorted(furthestFromPlayer)
			.collect(Collectors.toCollection(ArrayList::new));
	}
	
	private ArrayList<class_1297> getNearbyTargets()
	{
		double rangeSq = range.getValueSq();
		
		Comparator<class_1297> furthestFromPlayer = Comparator
			.<class_1297> comparingDouble(e -> MC.field_1724.method_5858(e))
			.reversed();
		
		Stream<class_1297> stream =
			StreamSupport.stream(MC.field_1687.method_18112().spliterator(), false)
				.filter(e -> !e.method_31481())
				.filter(e -> e instanceof class_1309
					&& ((class_1309)e).method_6032() > 0)
				.filter(e -> e != MC.field_1724)
				.filter(e -> !(e instanceof FakePlayerEntity))
				.filter(
					e -> !WURST.getFriends().contains(e.method_5477().getString()))
				.filter(e -> MC.field_1724.method_5858(e) <= rangeSq);
		
		stream = entityFilters.applyTo(stream);
		
		return stream.sorted(furthestFromPlayer)
			.collect(Collectors.toCollection(ArrayList::new));
	}
	
	private ArrayList<class_2338> getFreeBlocksNear(class_1297 target)
	{
		class_243 eyesVec = RotationUtils.getEyesPos().method_1023(0.5, 0.5, 0.5);
		double rangeSq = class_3532.method_33723(range.getValue() + 0.5);
		
		class_2338 center = target.method_24515();
		int rangeI = 2;
		
		class_238 targetBB = target.method_5829();
		class_243 targetEyesVec =
			target.method_19538().method_1031(0, target.method_18381(target.method_18376()), 0);
		
		Comparator<class_2338> closestToTarget =
			Comparator.<class_2338> comparingDouble(
				pos -> targetEyesVec.method_1025(class_243.method_24953(pos)));
		
		return BlockUtils.getAllInBoxStream(center, rangeI)
			.filter(pos -> eyesVec.method_1025(class_243.method_24954(pos)) <= rangeSq)
			.filter(this::isReplaceable).filter(this::hasClickableNeighbor)
			.filter(pos -> !targetBB.method_994(new class_238(pos)))
			.sorted(closestToTarget)
			.collect(Collectors.toCollection(ArrayList::new));
	}
	
	private boolean isReplaceable(class_2338 pos)
	{
		return BlockUtils.getState(pos).method_45474();
	}
	
	private boolean hasClickableNeighbor(class_2338 pos)
	{
		return isClickableNeighbor(pos.method_10084()) || isClickableNeighbor(pos.method_10074())
			|| isClickableNeighbor(pos.method_10095())
			|| isClickableNeighbor(pos.method_10078())
			|| isClickableNeighbor(pos.method_10072())
			|| isClickableNeighbor(pos.method_10067());
	}
	
	private boolean isClickableNeighbor(class_2338 pos)
	{
		return BlockUtils.canBeClicked(pos)
			&& !BlockUtils.getState(pos).method_45474();
	}
	
	private boolean isChargedAnchor(class_2338 pos)
	{
		return BlockUtils.getState(pos).method_28500(class_4969.field_23153)
			.orElse(0) > 0;
	}
	
	private boolean isSneaking()
	{
		return MC.field_1724.method_5715() || WURST.getHax().sneakHack.isEnabled();
	}
	
	private enum TakeItemsFrom
	{
		HOTBAR("Hotbar", 9),
		
		INVENTORY("Inventory", 36);
		
		private final String name;
		private final int maxInvSlot;
		
		private TakeItemsFrom(String name, int maxInvSlot)
		{
			this.name = name;
			this.maxInvSlot = maxInvSlot;
		}
		
		@Override
		public String toString()
		{
			return name;
		}
	}
}
