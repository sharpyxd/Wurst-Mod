/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.awt.Color;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2818;
import net.minecraft.class_2874;
import net.minecraft.class_3610;
import net.minecraft.class_4587;
import net.wurstclient.Category;
import net.wurstclient.events.RenderListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.hacks.newchunks.NewChunksChunkRenderer;
import net.wurstclient.hacks.newchunks.NewChunksReasonsRenderer;
import net.wurstclient.hacks.newchunks.NewChunksRenderer;
import net.wurstclient.hacks.newchunks.NewChunksShowSetting;
import net.wurstclient.hacks.newchunks.NewChunksShowSetting.Show;
import net.wurstclient.hacks.newchunks.NewChunksStyleSetting;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.ColorSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.RegionPos;
import net.wurstclient.util.RenderUtils;
import net.wurstclient.util.chunk.ChunkUtils;

public final class NewChunksHack extends Hack
	implements UpdateListener, RenderListener
{
	private final NewChunksStyleSetting style = new NewChunksStyleSetting();
	
	private final NewChunksShowSetting show = new NewChunksShowSetting();
	
	private final CheckboxSetting showReasons = new CheckboxSetting(
		"Show reasons",
		"Highlights the block that caused each chunk to be marked as new/old.",
		false);
	
	private final CheckboxSetting showCounter =
		new CheckboxSetting("Show counter",
			"Shows the number of new/old chunks found so far.", false);
	
	private final SliderSetting altitude =
		new SliderSetting("Altitude", 0, -64, 320, 1, ValueDisplay.INTEGER);
	
	private final SliderSetting drawDistance =
		new SliderSetting("Draw distance", 32, 8, 64, 1, ValueDisplay.INTEGER);
	
	private final SliderSetting opacity = new SliderSetting("Opacity", 0.75,
		0.1, 1, 0.01, ValueDisplay.PERCENTAGE);
	
	private final ColorSetting newChunksColor =
		new ColorSetting("New chunks color", Color.RED);
	
	private final ColorSetting oldChunksColor =
		new ColorSetting("Old chunks color", Color.BLUE);
	
	private final CheckboxSetting logChunks = new CheckboxSetting("Log chunks",
		"Writes to the log file when a new/old chunk is found.", false);
	
	private final Set<class_1923> newChunks =
		Collections.synchronizedSet(new HashSet<>());
	private final Set<class_1923> oldChunks =
		Collections.synchronizedSet(new HashSet<>());
	private final Set<class_1923> dontCheckAgain =
		Collections.synchronizedSet(new HashSet<>());
	
	private final Set<class_2338> newChunkReasons =
		Collections.synchronizedSet(new HashSet<>());
	private final Set<class_2338> oldChunkReasons =
		Collections.synchronizedSet(new HashSet<>());
	
	private final NewChunksRenderer renderer = new NewChunksRenderer(altitude,
		opacity, newChunksColor, oldChunksColor);
	private final NewChunksReasonsRenderer reasonsRenderer =
		new NewChunksReasonsRenderer(drawDistance);
	
	private RegionPos lastRegion;
	private class_2874 lastDimension;
	
	public NewChunksHack()
	{
		super("NewChunks");
		setCategory(Category.RENDER);
		addSetting(style);
		addSetting(show);
		addSetting(showReasons);
		addSetting(showCounter);
		addSetting(altitude);
		addSetting(drawDistance);
		addSetting(opacity);
		addSetting(newChunksColor);
		addSetting(oldChunksColor);
		addSetting(logChunks);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(RenderListener.class, this);
		reset();
	}
	
	private void reset()
	{
		oldChunks.clear();
		newChunks.clear();
		dontCheckAgain.clear();
		oldChunkReasons.clear();
		newChunkReasons.clear();
		lastRegion = null;
		lastDimension = MC.field_1687.method_8597();
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(RenderListener.class, this);
		renderer.closeBuffers();
	}
	
	@Override
	public String getRenderName()
	{
		if(!showCounter.isChecked())
			return getName();
		
		return String.format("%s [%d/%d]", getName(), newChunks.size(),
			oldChunks.size());
	}
	
	@Override
	public void onUpdate()
	{
		renderer.closeBuffers();
		
		Show showSetting = show.getSelected();
		int dd = drawDistance.getValueI();
		NewChunksChunkRenderer chunkRenderer =
			style.getSelected().getChunkRenderer();
		
		if(showSetting.includesNew())
		{
			renderer.updateBuffer(0, chunkRenderer.getLayer(),
				buffer -> chunkRenderer.buildBuffer(buffer, newChunks, dd));
			
			if(showReasons.isChecked())
				renderer.updateBuffer(1, reasonsRenderer.getLayer(),
					buffer -> reasonsRenderer.buildBuffer(buffer,
						List.copyOf(newChunkReasons)));
		}
		
		if(showSetting.includesOld())
		{
			renderer.updateBuffer(2, chunkRenderer.getLayer(),
				buffer -> chunkRenderer.buildBuffer(buffer, oldChunks, dd));
			
			if(showReasons.isChecked())
				renderer.updateBuffer(3, reasonsRenderer.getLayer(),
					buffer -> reasonsRenderer.buildBuffer(buffer,
						List.copyOf(oldChunkReasons)));
		}
	}
	
	public void afterLoadChunk(int x, int z)
	{
		if(!isEnabled())
			return;
		
		class_2818 chunk = MC.field_1687.method_8497(x, z);
		new Thread(() -> checkLoadedChunk(chunk), "NewChunks " + chunk.method_12004())
			.start();
	}
	
	private void checkLoadedChunk(class_2818 chunk)
	{
		class_1923 chunkPos = chunk.method_12004();
		if(newChunks.contains(chunkPos) || oldChunks.contains(chunkPos)
			|| dontCheckAgain.contains(chunkPos))
			return;
		
		int minX = chunkPos.method_8326();
		int minY = chunk.method_31607();
		int minZ = chunkPos.method_8328();
		int maxX = chunkPos.method_8327();
		int maxY = ChunkUtils.getHighestNonEmptySectionYOffset(chunk) + 16;
		int maxZ = chunkPos.method_8329();
		
		for(int x = minX; x <= maxX; x++)
			for(int y = minY; y <= maxY; y++)
				for(int z = minZ; z <= maxZ; z++)
				{
					class_2338 pos = new class_2338(x, y, z);
					class_3610 fluidState = chunk.method_8316(pos);
					
					if(fluidState.method_15769() || fluidState.method_15771())
						continue;
						
					// Liquid always generates still, the flowing happens later
					// through block updates. Therefore any chunk that contains
					// flowing liquids from the start should be an old chunk.
					oldChunks.add(chunkPos);
					oldChunkReasons.add(pos);
					if(logChunks.isChecked())
						System.out.println("old chunk at " + chunkPos);
					return;
				}
				
		// If the whole loop ran through without finding anything, make sure it
		// never runs again on that chunk, as that would be a huge waste of CPU
		// time.
		dontCheckAgain.add(chunkPos);
	}
	
	public void afterUpdateBlock(class_2338 pos)
	{
		if(!isEnabled())
			return;
		
		// Liquid starts flowing -> probably a new chunk
		class_3610 fluidState = BlockUtils.getState(pos).method_26227();
		if(fluidState.method_15769() || fluidState.method_15771())
			return;
		
		class_1923 chunkPos = new class_1923(pos);
		if(newChunks.contains(chunkPos) || oldChunks.contains(chunkPos))
			return;
		
		newChunks.add(chunkPos);
		newChunkReasons.add(pos);
		if(logChunks.isChecked())
			System.out.println("new chunk at " + chunkPos);
	}
	
	@Override
	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		if(MC.field_1687.method_8597() != lastDimension)
			reset();
		
		RegionPos region = RenderUtils.getCameraRegion();
		if(!region.equals(lastRegion))
		{
			onUpdate();
			lastRegion = region;
		}
		
		renderer.render(matrixStack, partialTicks);
	}
}
