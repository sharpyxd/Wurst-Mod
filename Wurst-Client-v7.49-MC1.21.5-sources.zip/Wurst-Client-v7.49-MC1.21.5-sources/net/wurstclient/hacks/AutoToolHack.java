/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.Optional;
import java.util.OptionalInt;
import java.util.stream.IntStream;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3489;
import net.minecraft.class_5455;
import net.minecraft.class_6880.class_6883;
import net.minecraft.class_746;
import net.minecraft.class_7924;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.WurstClient;
import net.wurstclient.events.BlockBreakingProgressListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.mixinterface.IClientPlayerInteractionManager;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.InventoryUtils;

@SearchTags({"auto tool", "AutoSwitch", "auto switch"})
public final class AutoToolHack extends Hack
	implements BlockBreakingProgressListener, UpdateListener
{
	private final CheckboxSetting useSwords = new CheckboxSetting("Use swords",
		"Uses swords to break leaves, cobwebs, etc.", false);
	
	private final CheckboxSetting useHands = new CheckboxSetting("Use hands",
		"Uses an empty hand or a non-damageable item when no applicable tool is"
			+ " found.",
		true);
	
	private final SliderSetting repairMode = new SliderSetting("Repair mode",
		"Prevents tools from being used when their durability reaches the given"
			+ " threshold, so you can repair them before they break.\n"
			+ "Can be adjusted from 0 (off) to 100 remaining uses.",
		0, 0, 100, 1, ValueDisplay.INTEGER.withLabel(0, "off"));
	
	private final CheckboxSetting switchBack = new CheckboxSetting(
		"Switch back", "After using a tool, automatically switches back to the"
			+ " previously selected slot.",
		false);
	
	private int prevSelectedSlot;
	
	public AutoToolHack()
	{
		super("AutoTool");
		
		setCategory(Category.BLOCKS);
		addSetting(useSwords);
		addSetting(useHands);
		addSetting(repairMode);
		addSetting(switchBack);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(BlockBreakingProgressListener.class, this);
		EVENTS.add(UpdateListener.class, this);
		prevSelectedSlot = -1;
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(BlockBreakingProgressListener.class, this);
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onBlockBreakingProgress(BlockBreakingProgressEvent event)
	{
		class_2338 pos = event.getBlockPos();
		if(!BlockUtils.canBeClicked(pos))
			return;
		
		if(prevSelectedSlot == -1)
			prevSelectedSlot = MC.field_1724.method_31548().method_67532();
		
		equipBestTool(pos, useSwords.isChecked(), useHands.isChecked(),
			repairMode.getValueI());
	}
	
	@Override
	public void onUpdate()
	{
		if(prevSelectedSlot == -1 || MC.field_1761.method_2923())
			return;
		
		class_239 hitResult = MC.field_1765;
		if(hitResult != null && hitResult.method_17783() == class_239.class_240.field_1332)
			return;
		
		if(switchBack.isChecked())
			MC.field_1724.method_31548().method_61496(prevSelectedSlot);
		
		prevSelectedSlot = -1;
	}
	
	public void equipIfEnabled(class_2338 pos)
	{
		if(!isEnabled())
			return;
		
		equipBestTool(pos, useSwords.isChecked(), useHands.isChecked(),
			repairMode.getValueI());
	}
	
	public void equipBestTool(class_2338 pos, boolean useSwords, boolean useHands,
		int repairMode)
	{
		class_746 player = MC.field_1724;
		if(player.method_31549().field_7477)
			return;
		
		class_1799 heldItem = player.method_6047();
		boolean heldItemDamageable = isDamageable(heldItem);
		if(heldItemDamageable && isTooDamaged(heldItem, repairMode))
			putAwayDamagedTool(repairMode);
		
		class_2680 state = BlockUtils.getState(pos);
		int bestSlot = getBestSlot(state, useSwords, repairMode);
		if(bestSlot == -1)
		{
			if(useHands && heldItemDamageable && isWrongTool(heldItem, state))
				selectFallbackSlot();
			
			return;
		}
		
		player.method_31548().method_61496(bestSlot);
	}
	
	private int getBestSlot(class_2680 state, boolean useSwords, int repairMode)
	{
		class_746 player = MC.field_1724;
		class_1661 inventory = player.method_31548();
		class_1799 heldItem = MC.field_1724.method_6047();
		
		float bestSpeed = getMiningSpeed(heldItem, state);
		if(isTooDamaged(heldItem, repairMode))
			bestSpeed = 1;
		int bestSlot = -1;
		
		for(int slot = 0; slot < 9; slot++)
		{
			if(slot == inventory.method_67532())
				continue;
			
			class_1799 stack = inventory.method_5438(slot);
			
			float speed = getMiningSpeed(stack, state);
			if(speed <= bestSpeed)
				continue;
			
			if(!useSwords && stack.method_31573(class_3489.field_42611))
				continue;
			
			if(isTooDamaged(stack, repairMode))
				continue;
			
			bestSpeed = speed;
			bestSlot = slot;
		}
		
		return bestSlot;
	}
	
	private float getMiningSpeed(class_1799 stack, class_2680 state)
	{
		float speed = stack.method_7924(state);
		
		if(speed > 1)
		{
			class_5455 drm =
				WurstClient.MC.field_1687.method_30349();
			class_2378<class_1887> registry =
				drm.method_30530(class_7924.field_41265);
			
			Optional<class_6883<class_1887>> efficiency =
				registry.method_46746(class_1893.field_9131);
			int effLvl = efficiency
				.map(entry -> class_1890.method_8225(entry, stack))
				.orElse(0);
			
			if(effLvl > 0 && !stack.method_7960())
				speed += effLvl * effLvl + 1;
		}
		
		return speed;
	}
	
	private boolean isDamageable(class_1799 stack)
	{
		return !stack.method_7960() && stack.method_7963();
	}
	
	private boolean isTooDamaged(class_1799 stack, int repairMode)
	{
		return stack.method_7936() - stack.method_7919() <= repairMode;
	}
	
	private void putAwayDamagedTool(int repairMode)
	{
		class_1661 inv = MC.field_1724.method_31548();
		int selectedSlot = inv.method_67532();
		IClientPlayerInteractionManager im = IMC.getInteractionManager();
		
		// If there's an empty slot in the main inventory,
		// shift-click the damaged item out of the hotbar
		OptionalInt emptySlot = IntStream.range(9, 36)
			.filter(i -> !inv.method_5438(i).method_7960()).findFirst();
		if(emptySlot.isPresent())
		{
			im.windowClick_QUICK_MOVE(
				InventoryUtils.toNetworkSlot(selectedSlot));
			return;
		}
		
		// Failing that, swap with a non-damageable item
		OptionalInt nonDamageableSlot = IntStream.range(9, 36)
			.filter(i -> !isDamageable(inv.method_5438(i))).findFirst();
		if(nonDamageableSlot.isPresent())
		{
			im.windowClick_SWAP(nonDamageableSlot.getAsInt(), selectedSlot);
			return;
		}
		
		// Failing that, swap with a less damaged item
		OptionalInt notTooDamagedSlot = IntStream.range(9, 36)
			.filter(i -> !isTooDamaged(inv.method_5438(i), repairMode))
			.findFirst();
		if(notTooDamagedSlot.isPresent())
		{
			im.windowClick_SWAP(notTooDamagedSlot.getAsInt(), selectedSlot);
			return;
		}
		
		// Failing all of the above (whole inventory full of damaged tools),
		// just swap with the top-left slot
		im.windowClick_SWAP(0, selectedSlot);
	}
	
	private boolean isWrongTool(class_1799 heldItem, class_2680 state)
	{
		return getMiningSpeed(heldItem, state) <= 1;
	}
	
	private void selectFallbackSlot()
	{
		int fallbackSlot = getFallbackSlot();
		class_1661 inventory = MC.field_1724.method_31548();
		
		if(fallbackSlot == -1)
		{
			int prevSlot = inventory.method_67532();
			if(prevSlot == 8)
				inventory.method_61496(0);
			else
				inventory.method_61496(prevSlot + 1);
			
			return;
		}
		
		inventory.method_61496(fallbackSlot);
	}
	
	private int getFallbackSlot()
	{
		class_1661 inventory = MC.field_1724.method_31548();
		
		for(int slot = 0; slot < 9; slot++)
		{
			if(slot == inventory.method_67532())
				continue;
			
			class_1799 stack = inventory.method_5438(slot);
			
			if(!isDamageable(stack))
				return slot;
		}
		
		return -1;
	}
}
