/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_746;
import net.wurstclient.Category;
import net.wurstclient.events.AirStrafingSpeedListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.util.BlockUtils;

public final class GlideHack extends Hack
	implements UpdateListener, AirStrafingSpeedListener
{
	private final SliderSetting fallSpeed = new SliderSetting("Fall speed",
		0.125, 0.005, 0.25, 0.005, ValueDisplay.DECIMAL);
	
	private final SliderSetting moveSpeed =
		new SliderSetting("Move speed", "Horizontal movement factor.", 1.2, 1,
			5, 0.05, ValueDisplay.PERCENTAGE);
	
	private final SliderSetting minHeight = new SliderSetting("Min height",
		"Won't glide when you are too close to the ground.", 0, 0, 2, 0.01,
		ValueDisplay.DECIMAL.withLabel(0, "disabled"));
	
	private final CheckboxSetting pauseOnSneak =
		new CheckboxSetting("Pause when sneaking", true);
	
	public GlideHack()
	{
		super("Glide");
		setCategory(Category.MOVEMENT);
		addSetting(fallSpeed);
		addSetting(moveSpeed);
		addSetting(minHeight);
		addSetting(pauseOnSneak);
	}
	
	@Override
	public String getRenderName()
	{
		class_746 player = MC.field_1724;
		if(player == null)
			return getName();
		
		if(pauseOnSneak.isChecked() && player.method_5715())
			return getName() + " (paused)";
		
		return getName();
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(AirStrafingSpeedListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(AirStrafingSpeedListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		class_746 player = MC.field_1724;
		
		if(pauseOnSneak.isChecked() && player.method_5715())
			return;
		
		class_243 v = player.method_18798();
		
		if(player.method_24828() || player.method_5799() || player.method_5771()
			|| player.method_6101() || v.field_1351 >= 0)
			return;
		
		if(minHeight.getValue() > 0)
		{
			class_238 box = player.method_5829();
			box = box.method_991(box.method_989(0, -minHeight.getValue(), 0));
			if(!MC.field_1687.method_18026(box))
				return;
			
			class_2338 min = class_2338.method_49637(box.field_1323, box.field_1322, box.field_1321);
			class_2338 max = class_2338.method_49637(box.field_1320, box.field_1325, box.field_1324);
			Stream<class_2338> stream = StreamSupport
				.stream(BlockUtils.getAllInBox(min, max).spliterator(), true);
			
			// manual collision check, since liquids don't have bounding boxes
			if(stream.map(BlockUtils::getBlock)
				.anyMatch(class_2404.class::isInstance))
				return;
		}
		
		player.method_18800(v.field_1352, Math.max(v.field_1351, -fallSpeed.getValue()), v.field_1350);
	}
	
	@Override
	public void onGetAirStrafingSpeed(AirStrafingSpeedEvent event)
	{
		event.setSpeed(event.getDefaultSpeed() * moveSpeed.getValueF());
	}
}
