/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_1297;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_2828.class_2829;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.PlayerAttacksEntityListener;
import net.wurstclient.hack.Hack;

@SearchTags({"mace dmg", "MaceDamage", "mace damage"})
public final class MaceDmgHack extends Hack
	implements PlayerAttacksEntityListener
{
	public MaceDmgHack()
	{
		super("MaceDMG");
		setCategory(Category.COMBAT);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(PlayerAttacksEntityListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(PlayerAttacksEntityListener.class, this);
	}
	
	@Override
	public void onPlayerAttacksEntity(class_1297 target)
	{
		if(MC.field_1765 == null
			|| MC.field_1765.method_17783() != class_239.class_240.field_1331)
			return;
		
		if(!MC.field_1724.method_6047().method_31574(class_1802.field_49814))
			return;
			
		// See ServerPlayNetworkHandler.onPlayerMove()
		// for why it's using these numbers.
		// Also, let me know if you find a way to bypass that check in 1.21.
		for(int i = 0; i < 4; i++)
			sendFakeY(0);
		sendFakeY(Math.sqrt(500));
		sendFakeY(0);
	}
	
	private void sendFakeY(double offset)
	{
		MC.field_1724.field_3944.method_52787(
			new class_2829(MC.field_1724.method_23317(), MC.field_1724.method_23318() + offset,
				MC.field_1724.method_23321(), false, MC.field_1724.field_5976));
	}
}
