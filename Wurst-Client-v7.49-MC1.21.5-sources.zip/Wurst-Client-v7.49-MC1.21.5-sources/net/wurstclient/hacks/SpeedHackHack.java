/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.class_243;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;

@SearchTags({"speed hack"})
public final class SpeedHackHack extends Hack implements UpdateListener
{
	public SpeedHackHack()
	{
		super("SpeedHack");
		setCategory(Category.MOVEMENT);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		// return if sneaking or not walking
		if(MC.field_1724.method_5715()
			|| MC.field_1724.field_6250 == 0 && MC.field_1724.field_6212 == 0)
			return;
		
		// activate sprint if walking forward
		if(MC.field_1724.field_6250 > 0 && !MC.field_1724.field_5976)
			MC.field_1724.method_5728(true);
		
		// activate mini jump if on ground
		if(!MC.field_1724.method_24828())
			return;
		
		class_243 v = MC.field_1724.method_18798();
		MC.field_1724.method_18800(v.field_1352 * 1.8, v.field_1351 + 0.1, v.field_1350 * 1.8);
		
		v = MC.field_1724.method_18798();
		double currentSpeed = Math.sqrt(Math.pow(v.field_1352, 2) + Math.pow(v.field_1350, 2));
		
		// limit speed to highest value that works on NoCheat+ version
		// 3.13.0-BETA-sMD5NET-b878
		// UPDATE: Patched in NoCheat+ version 3.13.2-SNAPSHOT-sMD5NET-b888
		double maxSpeed = 0.66F;
		
		if(currentSpeed > maxSpeed)
			MC.field_1724.method_18800(v.field_1352 / currentSpeed * maxSpeed, v.field_1351,
				v.field_1350 / currentSpeed * maxSpeed);
	}
}
