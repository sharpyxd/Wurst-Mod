/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_465;
import net.minecraft.class_7923;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.mixinterface.IClientPlayerInteractionManager;
import net.wurstclient.settings.ItemListSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;
import net.wurstclient.util.InventoryUtils;

@SearchTags({"AutoRestock", "auto-restock", "auto restock"})
public final class RestockHack extends Hack implements UpdateListener
{
	public static final int OFFHAND_ID = class_1661.field_30639;
	public static final int OFFHAND_PKT_ID = 45;
	
	private static final List<Integer> SEARCH_SLOTS =
		Stream.concat(IntStream.range(0, 36).boxed(), Stream.of(OFFHAND_ID))
			.collect(Collectors.toCollection(ArrayList::new));
	
	private ItemListSetting items = new ItemListSetting("Items",
		"Item(s) to be restocked.", "minecraft:minecart");
	
	private final SliderSetting restockSlot = new SliderSetting("Slot",
		"To which slot should we restock.", 0, -1, 9, 1,
		ValueDisplay.INTEGER.withLabel(9, "offhand").withLabel(-1, "current"));
	
	private final SliderSetting restockAmount = new SliderSetting(
		"Minimum amount",
		"Minimum amount of items in hand before a new round of restocking is triggered.",
		1, 1, 64, 1, ValueDisplay.INTEGER);
	
	private final SliderSetting repairMode = new SliderSetting(
		"Tools repair mode",
		"Swaps out tools when their durability reaches the given threshold, so"
			+ " you can repair them before they break.\n"
			+ "Can be adjusted from 0 (off) to 100 remaining uses.",
		0, 0, 100, 1, ValueDisplay.INTEGER.withLabel(0, "off"));
	
	public RestockHack()
	{
		super("Restock");
		setCategory(Category.ITEMS);
		addSetting(items);
		addSetting(restockSlot);
		addSetting(restockAmount);
		addSetting(repairMode);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		// Don't mess with the inventory while it's open.
		if(MC.field_1755 instanceof class_465)
			return;
		
		class_1661 inv = MC.field_1724.method_31548();
		IClientPlayerInteractionManager im = IMC.getInteractionManager();
		
		int hotbarSlot = restockSlot.getValueI();
		if(hotbarSlot == -1)
			hotbarSlot = inv.method_67532();
		else if(hotbarSlot == 9)
			hotbarSlot = OFFHAND_ID;
		
		for(String itemName : items.getItemNames())
		{
			class_1799 hotbarStack = inv.method_5438(hotbarSlot);
			
			boolean wrongItem =
				hotbarStack.method_7960() || !itemEqual(itemName, hotbarStack);
			if(!wrongItem && hotbarStack.method_7947() >= Math
				.min(restockAmount.getValueI(), hotbarStack.method_7914()))
				return;
			
			List<Integer> searchResult =
				searchSlotsWithItem(itemName, hotbarSlot);
			for(int itemIndex : searchResult)
			{
				int pickupIndex = InventoryUtils.toNetworkSlot(itemIndex);
				
				im.windowClick_PICKUP(pickupIndex);
				im.windowClick_PICKUP(InventoryUtils.toNetworkSlot(hotbarSlot));
				if(!MC.field_1724.field_7498.method_34255().method_7960())
					im.windowClick_PICKUP(pickupIndex);
				
				if(hotbarStack.method_7947() >= hotbarStack.method_7914())
					break;
			}
			
			if(wrongItem && searchResult.isEmpty())
				continue;
			
			break;
		}
		
		class_1799 restockStack = inv.method_5438(hotbarSlot);
		if(repairMode.getValueI() > 0 && restockStack.method_7963()
			&& isTooDamaged(restockStack))
			for(int i : SEARCH_SLOTS)
			{
				if(i == hotbarSlot || i == OFFHAND_ID)
					continue;
				
				class_1799 stack = inv.method_5438(i);
				if(stack.method_7960() || !stack.method_7963())
				{
					IMC.getInteractionManager().windowClick_SWAP(i,
						InventoryUtils.toNetworkSlot(hotbarSlot));
					break;
				}
			}
	}
	
	private boolean isTooDamaged(class_1799 stack)
	{
		return stack.method_7936() - stack.method_7919() <= repairMode
			.getValueI();
	}
	
	private List<Integer> searchSlotsWithItem(String itemName, int slotToSkip)
	{
		List<Integer> slots = new ArrayList<>();
		
		for(int i : SEARCH_SLOTS)
		{
			if(i == slotToSkip)
				continue;
			
			class_1799 stack = MC.field_1724.method_31548().method_5438(i);
			if(stack.method_7960())
				continue;
			
			if(itemEqual(itemName, stack))
				slots.add(i);
		}
		
		return slots;
	}
	
	private boolean itemEqual(String itemName, class_1799 stack)
	{
		if(repairMode.getValueI() > 0 && stack.method_7963()
			&& isTooDamaged(stack))
			return false;
		
		return class_7923.field_41178.method_10221(stack.method_7909()).toString()
			.equals(itemName);
	}
}
