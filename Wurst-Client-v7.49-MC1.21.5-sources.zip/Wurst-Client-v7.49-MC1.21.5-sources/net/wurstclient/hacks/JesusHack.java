/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.ArrayList;
import java.util.stream.Collectors;
import net.minecraft.class_2189;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_746;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.PacketOutputListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.util.BlockUtils;

@SearchTags({"WaterWalking", "water walking"})
public final class JesusHack extends Hack
	implements UpdateListener, PacketOutputListener
{
	private final CheckboxSetting bypass =
		new CheckboxSetting("NoCheat+ bypass",
			"Bypasses NoCheat+ but slows down your movement.", false);
	
	private int tickTimer = 10;
	private int packetTimer = 0;
	
	public JesusHack()
	{
		super("Jesus");
		setCategory(Category.MOVEMENT);
		addSetting(bypass);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(PacketOutputListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(PacketOutputListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		// check if sneaking
		if(MC.field_1690.field_1832.method_1434())
			return;
		
		class_746 player = MC.field_1724;
		
		// move up in liquid
		if(player.method_5799() || player.method_5771())
		{
			class_243 velocity = player.method_18798();
			player.method_18800(velocity.field_1352, 0.11, velocity.field_1350);
			tickTimer = 0;
			return;
		}
		
		// simulate jumping out of water
		class_243 velocity = player.method_18798();
		if(tickTimer == 0)
			player.method_18800(velocity.field_1352, 0.30, velocity.field_1350);
		else if(tickTimer == 1)
			player.method_18800(velocity.field_1352, 0, velocity.field_1350);
		
		// update timer
		tickTimer++;
	}
	
	@Override
	public void onSentPacket(PacketOutputEvent event)
	{
		// check packet type
		if(!(event.getPacket() instanceof class_2828))
			return;
		
		class_2828 packet = (class_2828)event.getPacket();
		
		// check if packet contains a position
		if(!(packet instanceof class_2828.class_2829
			|| packet instanceof class_2828.class_2830))
			return;
		
		// check inWater
		if(MC.field_1724.method_5799())
			return;
		
		// check fall distance
		if(MC.field_1724.field_6017 > 3F)
			return;
		
		if(!isOverLiquid())
			return;
		
		// if not actually moving, cancel packet
		if(MC.field_1724.field_3913 == null)
		{
			event.cancel();
			return;
		}
		
		// wait for timer
		packetTimer++;
		if(packetTimer < 4)
			return;
		
		// cancel old packet
		event.cancel();
		
		// get position
		double x = packet.method_12269(0);
		double y = packet.method_12268(0);
		double z = packet.method_12274(0);
		
		// offset y
		if(bypass.isChecked() && MC.field_1724.field_6012 % 2 == 0)
			y -= 0.05;
		else
			y += 0.05;
		
		// create new packet
		class_2596<?> newPacket;
		if(packet instanceof class_2828.class_2829)
			newPacket = new class_2828.class_2829(x, y, z,
				true, MC.field_1724.field_5976);
		else
			newPacket = new class_2828.class_2830(x, y, z, packet.method_12271(0),
				packet.method_12270(0), true, MC.field_1724.field_5976);
		
		// send new packet
		MC.field_1724.field_3944.method_48296().method_10743(newPacket);
	}
	
	public boolean isOverLiquid()
	{
		boolean foundLiquid = false;
		boolean foundSolid = false;
		class_238 box = MC.field_1724.method_5829().method_989(0, -0.5, 0);
		
		// check collision boxes below player
		ArrayList<class_2248> blockCollisions = BlockUtils.getBlockCollisions(box)
			.map(bb -> BlockUtils.getBlock(class_2338.method_49638(bb.method_1005())))
			.collect(Collectors.toCollection(ArrayList::new));
		
		for(class_2248 block : blockCollisions)
			if(block instanceof class_2404)
				foundLiquid = true;
			else if(!(block instanceof class_2189))
				foundSolid = true;
			
		return foundLiquid && !foundSolid;
	}
	
	public boolean shouldBeSolid()
	{
		return isEnabled() && MC.field_1724 != null && MC.field_1724.field_6017 <= 3
			&& !MC.field_1690.field_1832.method_1434() && !MC.field_1724.method_5799()
			&& !MC.field_1724.method_5771();
	}
}
