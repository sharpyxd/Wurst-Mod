/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.Comparator;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.PacketOutputListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.DontSaveState;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.filterlists.EntityFilterList;
import net.wurstclient.settings.filterlists.RemoteViewFilterList;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.FakePlayerEntity;

@SearchTags({"remote view"})
@DontSaveState
public final class RemoteViewHack extends Hack
	implements UpdateListener, PacketOutputListener
{
	private final EntityFilterList entityFilters =
		RemoteViewFilterList.create();
	
	private class_1297 entity = null;
	private boolean wasInvisible;
	
	private FakePlayerEntity fakePlayer;
	
	public RemoteViewHack()
	{
		super("RemoteView");
		setCategory(Category.RENDER);
		entityFilters.forEach(this::addSetting);
	}
	
	@Override
	protected void onEnable()
	{
		// find entity if not already set
		if(entity == null)
		{
			Stream<class_1297> stream = StreamSupport
				.stream(MC.field_1687.method_18112().spliterator(), true)
				.filter(class_1309.class::isInstance)
				.filter(
					e -> !e.method_31481() && ((class_1309)e).method_6032() > 0)
				.filter(e -> e != MC.field_1724)
				.filter(e -> !(e instanceof FakePlayerEntity));
			
			stream = entityFilters.applyTo(stream);
			
			entity = stream
				.min(Comparator
					.comparingDouble(e -> MC.field_1724.method_5858(e)))
				.orElse(null);
			
			// check if entity was found
			if(entity == null)
			{
				ChatUtils.error("Could not find a valid entity.");
				setEnabled(false);
				return;
			}
		}
		
		// save old data
		wasInvisible = entity.method_5767();
		
		// enable NoClip
		MC.field_1724.field_5960 = true;
		
		// spawn fake player
		fakePlayer = new FakePlayerEntity();
		
		// success message
		ChatUtils.message("Now viewing " + entity.method_5477().getString() + ".");
		
		// add listener
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(PacketOutputListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		// remove listener
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(PacketOutputListener.class, this);
		
		// reset entity
		if(entity != null)
		{
			ChatUtils.message(
				"No longer viewing " + entity.method_5477().getString() + ".");
			entity.method_5648(wasInvisible);
			entity = null;
		}
		
		// disable NoClip
		MC.field_1724.field_5960 = false;
		
		// remove fake player
		if(fakePlayer != null)
		{
			fakePlayer.resetPlayerPosition();
			fakePlayer.despawn();
		}
	}
	
	public void onToggledByCommand(String viewName)
	{
		// set entity
		if(!isEnabled() && viewName != null && !viewName.isEmpty())
		{
			entity = StreamSupport
				.stream(MC.field_1687.method_18112().spliterator(), false)
				.filter(class_1309.class::isInstance)
				.filter(
					e -> !e.method_31481() && ((class_1309)e).method_6032() > 0)
				.filter(e -> e != MC.field_1724)
				.filter(e -> !(e instanceof FakePlayerEntity))
				.filter(e -> viewName.equalsIgnoreCase(e.method_5477().getString()))
				.min(Comparator
					.comparingDouble(e -> MC.field_1724.method_5858(e)))
				.orElse(null);
			
			if(entity == null)
			{
				ChatUtils
					.error("Entity \"" + viewName + "\" could not be found.");
				return;
			}
		}
		
		// toggle RemoteView
		setEnabled(!isEnabled());
	}
	
	@Override
	public void onUpdate()
	{
		// validate entity
		if(entity.method_31481() || ((class_1309)entity).method_6032() <= 0)
		{
			setEnabled(false);
			return;
		}
		
		// update position, rotation, etc.
		MC.field_1724.method_5719(entity);
		MC.field_1724.method_23327(entity.method_23317(),
			entity.method_23318() - MC.field_1724.method_18381(MC.field_1724.method_18376())
				+ entity.method_18381(entity.method_18376()),
			entity.method_23321());
		MC.field_1724.method_22862();
		MC.field_1724.method_18799(class_243.field_1353);
		
		// set entity invisible
		entity.method_5648(true);
	}
	
	@Override
	public void onSentPacket(PacketOutputEvent event)
	{
		if(event.getPacket() instanceof class_2828)
			event.cancel();
	}
}
