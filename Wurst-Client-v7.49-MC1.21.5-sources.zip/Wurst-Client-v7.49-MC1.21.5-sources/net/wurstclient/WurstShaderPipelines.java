/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import net.minecraft.class_10799;
import net.minecraft.class_290;

public enum WurstShaderPipelines
{
	;
	
	/**
	 * Similar to the DEBUG_LINE_STIP ShaderPipeline, but as a non-srip
	 * version with support for transparency.
	 */
	public static final RenderPipeline ONE_PIXEL_LINES = class_10799
		.method_67887(RenderPipeline.builder(class_10799.field_56849)
			.withLocation("pipeline/wurst_1px_lines")
			.withVertexShader("core/position_color")
			.withFragmentShader("core/position_color")
			.withBlend(BlendFunction.TRANSLUCENT).withCull(false)
			.withVertexFormat(class_290.field_1576,
				class_5596.field_29344)
			.build());
	
	/**
	 * Similar to the DEBUG_LINE_STIP ShaderPipeline, but with support for
	 * transparency.
	 */
	public static final RenderPipeline ONE_PIXEL_LINE_STRIP = class_10799
		.method_67887(RenderPipeline.builder(class_10799.field_56849)
			.withLocation("pipeline/wurst_1px_line_strip")
			.withVertexShader("core/position_color")
			.withFragmentShader("core/position_color")
			.withBlend(BlendFunction.TRANSLUCENT).withCull(false)
			.withVertexFormat(class_290.field_1576,
				class_5596.field_29345)
			.build());
	
	/**
	 * Similar to the LINES ShaderPipeline, but with no depth test.
	 */
	public static final RenderPipeline ESP_LINES = class_10799.method_67887(
		RenderPipeline.builder(class_10799.field_56859)
			.withLocation("pipeline/wurst_esp_lines")
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).build());
	
	/**
	 * Similar to the LINE_STRIP ShaderPipeline, but with no depth test.
	 */
	public static final RenderPipeline ESP_LINE_STRIP =
		class_10799.method_67887(RenderPipeline
			.builder(class_10799.field_56859)
			.withLocation("pipeline/wurst_esp_line_strip")
			.withVertexFormat(class_290.field_29337,
				class_5596.field_27378)
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).build());
	
	/**
	 * Similar to the DEBUG_QUADS ShaderPipeline, but with culling enabled.
	 */
	public static final RenderPipeline QUADS = class_10799
		.method_67887(RenderPipeline.builder(class_10799.field_56860)
			.withLocation("pipeline/wurst_quads")
			.withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
			.build());
	
	/**
	 * Similar to the DEBUG_QUADS ShaderPipeline, but with culling enabled
	 * and no depth test.
	 */
	public static final RenderPipeline ESP_QUADS = class_10799
		.method_67887(RenderPipeline.builder(class_10799.field_56860)
			.withLocation("pipeline/wurst_esp_quads")
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).build());
	
	/**
	 * Similar to the DEBUG_QUADS ShaderPipeline, but with no depth test.
	 */
	public static final RenderPipeline ESP_QUADS_NO_CULLING = class_10799
		.method_67887(RenderPipeline.builder(class_10799.field_56860)
			.withLocation("pipeline/wurst_esp_quads").withCull(false)
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).build());
}
