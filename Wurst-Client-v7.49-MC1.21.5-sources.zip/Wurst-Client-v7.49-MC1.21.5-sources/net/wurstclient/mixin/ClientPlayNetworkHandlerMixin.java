/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_2602;
import net.minecraft.class_2626;
import net.minecraft.class_2637;
import net.minecraft.class_2678;
import net.minecraft.class_310;
import net.minecraft.class_370;
import net.minecraft.class_5250;
import net.minecraft.class_634;
import net.minecraft.class_6603;
import net.minecraft.class_7633;
import net.minecraft.class_8673;
import net.minecraft.class_8675;
import net.wurstclient.WurstClient;
import net.wurstclient.util.ChatUtils;

@Mixin(class_634.class)
public abstract class ClientPlayNetworkHandlerMixin
	extends class_8673
	implements class_7633, class_2602
{
	private ClientPlayNetworkHandlerMixin(WurstClient wurst,
		class_310 client, class_2535 connection,
		class_8675 connectionState)
	{
		super(client, connection, connectionState);
	}
	
	@Inject(at = @At("TAIL"),
		method = "onGameJoin(Lnet/minecraft/network/packet/s2c/play/GameJoinS2CPacket;)V")
	public void onOnGameJoin(class_2678 packet, CallbackInfo ci)
	{
		WurstClient wurst = WurstClient.INSTANCE;
		if(!wurst.isEnabled())
			return;
		
		// Remove Mojang's dishonest warning toast on safe servers
		if(!packet.comp_2200())
		{
			field_45588.method_1566().field_2240.removeIf(toast -> toast
				.method_1987() == class_370.class_9037.field_47589);
			return;
		}
		
		// Add an honest warning toast on unsafe servers
		class_5250 title = class_2561.method_43470(ChatUtils.WURST_PREFIX
			+ wurst.translate("toast.wurst.nochatreports.unsafe_server.title"));
		class_5250 message = class_2561.method_43470(
			wurst.translate("toast.wurst.nochatreports.unsafe_server.message"));
		
		class_370 systemToast = class_370.method_29047(field_45588,
			class_370.class_9037.field_47589, title, message);
		field_45588.method_1566().method_1999(systemToast);
	}
	
	@Inject(at = @At("TAIL"),
		method = "loadChunk(IILnet/minecraft/network/packet/s2c/play/ChunkData;)V")
	private void onLoadChunk(int x, int z, class_6603 chunkData, CallbackInfo ci)
	{
		WurstClient.INSTANCE.getHax().newChunksHack.afterLoadChunk(x, z);
	}
	
	@Inject(at = @At("TAIL"),
		method = "onBlockUpdate(Lnet/minecraft/network/packet/s2c/play/BlockUpdateS2CPacket;)V")
	private void onOnBlockUpdate(class_2626 packet, CallbackInfo ci)
	{
		WurstClient.INSTANCE.getHax().newChunksHack
			.afterUpdateBlock(packet.method_11309());
	}
	
	@Inject(at = @At("TAIL"),
		method = "onChunkDeltaUpdate(Lnet/minecraft/network/packet/s2c/play/ChunkDeltaUpdateS2CPacket;)V")
	private void onOnChunkDeltaUpdate(class_2637 packet,
		CallbackInfo ci)
	{
		packet.method_30621(
			(pos, state) -> WurstClient.INSTANCE.getHax().newChunksHack
				.afterUpdateBlock(pos));
	}
}
