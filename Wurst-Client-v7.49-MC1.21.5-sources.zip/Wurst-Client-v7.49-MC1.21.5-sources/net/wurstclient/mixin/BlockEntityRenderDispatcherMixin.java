/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_2586;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_824;
import net.wurstclient.event.EventManager;
import net.wurstclient.events.RenderBlockEntityListener.RenderBlockEntityEvent;

@Mixin(class_824.class)
public class BlockEntityRenderDispatcherMixin
{
	@Inject(at = @At("HEAD"),
		method = "render(Lnet/minecraft/block/entity/BlockEntity;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;)V",
		cancellable = true)
	private <E extends class_2586> void onRender(E blockEntity,
		float tickDelta, class_4587 matrices,
		class_4597 vertexConsumers, CallbackInfo ci)
	{
		RenderBlockEntityEvent event = new RenderBlockEntityEvent(blockEntity);
		EventManager.fire(event);
		
		if(event.isCancelled())
			ci.cancel();
	}
}
