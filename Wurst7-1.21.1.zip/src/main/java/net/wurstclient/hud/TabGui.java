/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hud;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.lwjgl.glfw.GLFW;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.wurstclient.Category;
import net.wurstclient.Feature;
import net.wurstclient.WurstClient;
import net.wurstclient.clickgui.ClickGui;
import net.wurstclient.events.KeyPressListener;
import net.wurstclient.hacks.TooManyHaxHack;
import net.wurstclient.other_features.TabGuiOtf;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.RenderUtils;

public final class TabGui implements KeyPressListener
{
	private static final WurstClient WURST = WurstClient.INSTANCE;
	private static final MinecraftClient MC = WurstClient.MC;
	
	private final ArrayList<Tab> tabs = new ArrayList<>();
	private final TabGuiOtf tabGuiOtf =
		WurstClient.INSTANCE.getOtfs().tabGuiOtf;
	
	private int width;
	private int height;
	private int selected;
	private boolean tabOpened;
	
	public TabGui()
	{
		WURST.getEventManager().add(KeyPressListener.class, this);
		
		LinkedHashMap<Category, Tab> tabMap = new LinkedHashMap<>();
		for(Category category : Category.values())
			tabMap.put(category, new Tab(category.getName()));
		
		ArrayList<Feature> features = new ArrayList<>();
		features.addAll(WURST.getHax().getAllHax());
		features.addAll(WURST.getCmds().getAllCmds());
		features.addAll(WURST.getOtfs().getAllOtfs());
		
		for(Feature feature : features)
			if(feature.getCategory() != null)
				tabMap.get(feature.getCategory()).add(feature);
			
		tabs.addAll(tabMap.values());
		tabs.forEach(Tab::updateSize);
		updateSize();
	}
	
	private void updateSize()
	{
		width = 64;
		for(Tab tab : tabs)
		{
			int tabWidth = MC.textRenderer.getWidth(tab.name) + 10;
			if(tabWidth > width)
				width = tabWidth;
		}
		height = tabs.size() * 10;
	}
	
	@Override
	public void onKeyPress(KeyPressEvent event)
	{
		if(event.getAction() != GLFW.GLFW_PRESS)
			return;
		
		if(tabGuiOtf.isHidden())
			return;
		
		if(tabOpened)
			switch(event.getKeyCode())
			{
				case GLFW.GLFW_KEY_LEFT:
				tabOpened = false;
				break;
				
				default:
				tabs.get(selected).onKeyPress(event.getKeyCode());
				break;
			}
		else
			switch(event.getKeyCode())
			{
				case GLFW.GLFW_KEY_DOWN:
				if(selected < tabs.size() - 1)
					selected++;
				else
					selected = 0;
				break;
				
				case GLFW.GLFW_KEY_UP:
				if(selected > 0)
					selected--;
				else
					selected = tabs.size() - 1;
				break;
				
				case GLFW.GLFW_KEY_RIGHT:
				tabOpened = true;
				break;
			}
	}
	
	public void render(DrawContext context, float partialTicks)
	{
		if(tabGuiOtf.isHidden())
			return;
		
		MatrixStack matrixStack = context.getMatrices();
		matrixStack.push();
		matrixStack.translate(2, 23, 100);
		
		drawBox(context, 0, 0, width, height);
		context.enableScissor(2, 23, 2 + width, 23 + height);
		
		int textY = 1;
		int txtColor = WURST.getGui().getTxtColor();
		TextRenderer tr = MC.textRenderer;
		for(int i = 0; i < tabs.size(); i++)
		{
			String tabName = tabs.get(i).name;
			boolean isSelected = (i == selected);
			
			// Modern selection background
			if(isSelected)
			{
				int selBg1 =
					RenderUtils.toIntColor(WURST.getGui().getAcColor(), 0.3f);
				int selBg2 =
					RenderUtils.toIntColor(WURST.getGui().getAcColor(), 0.1f);
				context.fillGradient(1, textY - 1, width - 1, textY + 8, selBg1,
					selBg2);
				tabName = (tabOpened ? "◀ " : "▶ ") + tabName;
			}
			
			// Enhanced text with shadow
			if(isSelected)
			{
				context.drawText(tr, tabName, 3, textY + 1, 0x80000000, false);
				context.drawText(tr, tabName, 2, textY, 0xFFFFFFFF, false);
			}else
			{
				context.drawText(tr, tabName, 3, textY + 1, 0x40000000, false);
				context.drawText(tr, tabName, 2, textY, txtColor, false);
			}
			textY += 10;
		}
		
		context.disableScissor();
		
		if(tabOpened)
		{
			Tab tab = tabs.get(selected);
			
			matrixStack.push();
			matrixStack.translate(width + 2, 0, 0);
			
			drawBox(context, 0, 0, tab.width, tab.height);
			context.enableScissor(width + 4, 23, width + 4 + tab.width,
				23 + tab.height);
			
			int tabTextY = 1;
			for(int i = 0; i < tab.features.size(); i++)
			{
				Feature feature = tab.features.get(i);
				Feature tabFeature = tab.features.get(i);
				String fName = tabFeature.getName();
				boolean isSelected = (i == tab.selected);
				boolean isEnabled = tabFeature.isEnabled();
				
				// Modern selection background
				if(isSelected)
				{
					int selBg1 = RenderUtils
						.toIntColor(WURST.getGui().getAcColor(), 0.4f);
					int selBg2 = RenderUtils
						.toIntColor(WURST.getGui().getAcColor(), 0.2f);
					context.fillGradient(1, tabTextY - 1, tab.width - 1,
						tabTextY + 8, selBg1, selBg2);
					fName = "▶ " + fName;
				}
				
				// Color coding for enabled features
				int textColor = txtColor;
				if(isEnabled)
					textColor = RenderUtils
						.toIntColor(new float[]{0.4f, 1.0f, 0.4f}, 1.0f);
				
				// Enhanced text rendering
				if(isSelected || isEnabled)
				{
					context.drawText(tr, fName, 3, tabTextY + 1, 0x80000000,
						false);
					context.drawText(tr, fName, 2, tabTextY, textColor, false);
				}else
				{
					context.drawText(tr, fName, 3, tabTextY + 1, 0x40000000,
						false);
					context.drawText(tr, fName, 2, tabTextY, textColor, false);
				}
				tabTextY += 10;
			}
			
			context.disableScissor();
			matrixStack.pop();
		}
		
		matrixStack.pop();
	}
	
	private void drawBox(DrawContext context, int x1, int y1, int x2, int y2)
	{
		ClickGui gui = WURST.getGui();
		
		// Modern gradient background
		float[] modernBg = {0.08f, 0.08f, 0.12f};
		int bgColor1 =
			RenderUtils.toIntColor(modernBg, Math.max(gui.getOpacity(), 0.9f));
		int bgColor2 = RenderUtils.toIntColor(new float[]{modernBg[0] * 0.7f,
			modernBg[1] * 0.7f, modernBg[2] * 0.7f}, gui.getOpacity());
		
		// Drop shadow
		context.fill(x1 + 1, y1 + 1, x2 + 1, y2 + 1, 0x60000000);
		
		// Gradient background
		context.fillGradient(x1, y1, x2, y2, bgColor1, bgColor2);
		
		// Modern border with glow
		int borderColor = RenderUtils.toIntColor(gui.getAcColor(), 0.8f);
		RenderUtils.drawBorder2D(context, x1, y1, x2, y2, borderColor);
		
		// Top glow line
		context.fill(x1, y1, x2, y1 + 1,
			RenderUtils.toIntColor(gui.getAcColor(), 0.6f));
	}
	
	private static final class Tab
	{
		private final String name;
		private final ArrayList<Feature> features = new ArrayList<>();
		
		private int width;
		private int height;
		private int selected;
		
		public Tab(String name)
		{
			this.name = name;
		}
		
		public void updateSize()
		{
			width = 64;
			for(Feature feature : features)
			{
				int fWidth = MC.textRenderer.getWidth(feature.getName()) + 10;
				if(fWidth > width)
					width = fWidth;
			}
			height = features.size() * 10;
		}
		
		public void onKeyPress(int keyCode)
		{
			switch(keyCode)
			{
				case GLFW.GLFW_KEY_DOWN:
				if(selected < features.size() - 1)
					selected++;
				else
					selected = 0;
				break;
				
				case GLFW.GLFW_KEY_UP:
				if(selected > 0)
					selected--;
				else
					selected = features.size() - 1;
				break;
				
				case GLFW.GLFW_KEY_ENTER:
				onEnter();
				break;
			}
		}
		
		private void onEnter()
		{
			Feature feature = features.get(selected);
			
			TooManyHaxHack tooManyHax = WURST.getHax().tooManyHaxHack;
			if(tooManyHax.isEnabled() && tooManyHax.isBlocked(feature))
			{
				ChatUtils
					.error(feature.getName() + " is blocked by TooManyHax.");
				return;
			}
			
			feature.doPrimaryAction();
		}
		
		public void add(Feature feature)
		{
			features.add(feature);
		}
	}
}
