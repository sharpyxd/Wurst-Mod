/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hud;

import com.mojang.blaze3d.systems.RenderSystem;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import net.wurstclient.WurstClient;
import net.wurstclient.other_features.WurstLogoOtf;
import net.wurstclient.util.RenderUtils;

public final class WurstLogo
{
	private static final WurstClient WURST = WurstClient.INSTANCE;
	private static final Identifier LOGO_TEXTURE =
		Identifier.of("wurst", "wurst_128.png");
	
	public void render(DrawContext context)
	{
		WurstLogoOtf otf = WURST.getOtfs().wurstLogoOtf;
		if(!otf.isVisible())
			return;
		
		String version = getVersionString();
		TextRenderer tr = WurstClient.MC.textRenderer;
		
		// Modern gradient background
		int bgWidth = tr.getWidth(version) + 76;
		int bgColor1, bgColor2;
		if(WURST.getHax().rainbowUiHack.isEnabled())
		{
			float[] acColor = WURST.getGui().getAcColor();
			bgColor1 = RenderUtils.toIntColor(acColor, 0.7F);
			bgColor2 = RenderUtils.toIntColor(new float[]{acColor[0] * 0.6f,
				acColor[1] * 0.6f, acColor[2] * 0.6f}, 0.5F);
		}else
		{
			bgColor1 = otf.getBackgroundColor();
			bgColor2 = (otf.getBackgroundColor() & 0x00FFFFFF) | 0x80000000;
		}
		
		// Gradient background with shadow
		context.fill(1, 7, bgWidth + 1, 18, 0x40000000); // Shadow
		context.fillGradient(0, 6, bgWidth, 17, bgColor1, bgColor2);
		
		// Top glow line
		int glowColor = WURST.getHax().rainbowUiHack.isEnabled()
			? RenderUtils.toIntColor(WURST.getGui().getAcColor(), 0.9F)
			: (otf.getTextColor() & 0x00FFFFFF) | 0x80000000;
		context.fill(0, 6, bgWidth, 7, glowColor);
		
		// Enhanced version string with shadow
		context.drawText(tr, version, 75, 9, 0x80000000, false); // Shadow
		context.drawText(tr, version, 74, 8, otf.getTextColor(), false);
		
		// Enhanced Wurst logo with glow effect
		RenderSystem.enableBlend();
		
		// Logo glow effect
		if(WURST.getHax().rainbowUiHack.isEnabled())
		{
			RenderSystem.setShaderColor(WURST.getGui().getAcColor()[0],
				WURST.getGui().getAcColor()[1], WURST.getGui().getAcColor()[2],
				0.3f);
			context.drawTexture(LOGO_TEXTURE, -1, 2, 0, 0, 74, 20, 72, 18);
			RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
		}
		
		// Main logo
		context.drawTexture(LOGO_TEXTURE, 0, 3, 0, 0, 72, 18, 72, 18);
		RenderSystem.disableBlend();
	}
	
	private String getVersionString()
	{
		String version = "v" + WurstClient.VERSION;
		version += " MC" + WurstClient.MC_VERSION;
		
		if(WURST.getUpdater().isOutdated())
			version += " (outdated)";
		
		return version;
	}
}
