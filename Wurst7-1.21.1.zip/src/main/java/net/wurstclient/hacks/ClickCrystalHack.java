/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.util.math.BlockPos;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.PacketOutputListener;
import net.wurstclient.events.PacketOutputListener.PacketOutputEvent;
import net.wurstclient.hack.Hack;
import net.wurstclient.util.BlockUtils;

@SearchTags({"click crystal", "crystal click", "left click crystal"})
public final class ClickCrystalHack extends Hack implements PacketOutputListener
{
	public ClickCrystalHack()
	{
		super("ClickCrystal");
		setCategory(Category.COMBAT);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(PacketOutputListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(PacketOutputListener.class, this);
	}
	
	@Override
	public void onSentPacket(PacketOutputEvent event)
	{
		if(!(event.getPacket() instanceof PlayerActionC2SPacket packet))
			return;
		
		if(packet
			.getAction() != PlayerActionC2SPacket.Action.START_DESTROY_BLOCK)
			return;
		
		BlockPos pos = packet.getPos();
		if(!canCrystalOn(pos))
			return;
		
		if(MC.player.isHolding(Items.END_CRYSTAL))
		{
			event.cancel();
			IMC.getInteractionManager().rightClickBlock(pos,
				packet.getDirection(),
				net.minecraft.util.math.Vec3d.ofCenter(pos));
		}
	}
	
	private boolean canCrystalOn(BlockPos pos)
	{
		return BlockUtils.getBlock(pos)
			.equals(net.minecraft.block.Blocks.OBSIDIAN)
			|| BlockUtils.getBlock(pos)
				.equals(net.minecraft.block.Blocks.BEDROCK);
	}
}
