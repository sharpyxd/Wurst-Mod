/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.item.AxeItem;
import net.minecraft.item.TridentItem;
import net.minecraft.item.MaceItem;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.component.DataComponentTypes;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.LeftClickListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.util.ItemUtils;

@SearchTags({"auto sword hit", "sword swap", "auto sword", "hit swap"})
public final class AutoSwordHitHack extends Hack
	implements LeftClickListener, UpdateListener
{
	private final CheckboxSetting onlyPlayers = new CheckboxSetting(
		"Only Players", "Only swap to sword when hitting players.", true);
	
	private final CheckboxSetting skipFriends = new CheckboxSetting(
		"Skip Friends", "Don't swap when hitting friends.", true);
	
	private final SliderSetting swapBackDelay =
		new SliderSetting("Swap Back Delay",
			"Ticks to wait before swapping back to original item.", 3, 1, 20, 1,
			SliderSetting.ValueDisplay.INTEGER.withSuffix(" ticks"));
	
	private int originalSlot = -1;
	private boolean shouldSwapBack = false;
	private int swapBackTimer = 0;
	private boolean wasEatingOrShielding = false;
	
	public AutoSwordHitHack()
	{
		super("AutoSwordHit");
		setCategory(Category.COMBAT);
		addSetting(onlyPlayers);
		addSetting(skipFriends);
		addSetting(swapBackDelay);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(LeftClickListener.class, this);
		EVENTS.add(UpdateListener.class, this);
		resetState();
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(LeftClickListener.class, this);
		EVENTS.remove(UpdateListener.class, this);
		
		if(shouldSwapBack && originalSlot != -1 && MC.player != null)
		{
			MC.player.getInventory().selectedSlot = originalSlot;
			resetState();
		}
	}
	
	@Override
	public void onUpdate()
	{
		if(MC.player == null)
			return;
		
		boolean currentlyEatingOrShielding = isEatingOrShielding();
		
		// If we stopped eating/shielding and had swapped, continue the swap
		// back timer
		if(wasEatingOrShielding && !currentlyEatingOrShielding
			&& shouldSwapBack)
		{
			swapBackTimer = swapBackDelay.getValueI();
		}
		
		// Handle swap back timer (only when not eating/shielding)
		if(shouldSwapBack && swapBackTimer > 0 && !currentlyEatingOrShielding)
		{
			swapBackTimer--;
			if(swapBackTimer <= 0)
			{
				MC.player.getInventory().selectedSlot = originalSlot;
				resetState();
			}
		}
		
		wasEatingOrShielding = currentlyEatingOrShielding;
	}
	
	@Override
	public void onLeftClick(LeftClickEvent event)
	{
		if(MC.player == null || MC.crosshairTarget == null)
			return;
		
		// Don't swap if eating or using shield
		if(isEatingOrShielding())
			return;
		
		// Check if hitting an entity
		if(MC.crosshairTarget
			.getType() != net.minecraft.util.hit.HitResult.Type.ENTITY)
			return;
		
		net.minecraft.util.hit.EntityHitResult entityHit =
			(net.minecraft.util.hit.EntityHitResult)MC.crosshairTarget;
		Entity target = entityHit.getEntity();
		
		// Only players check
		if(onlyPlayers.isChecked() && !(target instanceof PlayerEntity))
			return;
		
		// Skip friends check
		if(skipFriends.isChecked() && target instanceof PlayerEntity)
		{
			PlayerEntity player = (PlayerEntity)target;
			if(WURST.getFriends().isFriend(player))
				return;
		}
		
		// Find best sword
		int swordSlot = findBestSword();
		if(swordSlot == -1
			|| swordSlot == MC.player.getInventory().selectedSlot)
			return;
		
		// Store original slot and swap to sword
		originalSlot = MC.player.getInventory().selectedSlot;
		MC.player.getInventory().selectedSlot = swordSlot;
		
		// Set timer to swap back after hit
		shouldSwapBack = true;
		swapBackTimer = swapBackDelay.getValueI();
	}
	
	private boolean isEatingOrShielding()
	{
		if(MC.player.isUsingItem())
		{
			ItemStack activeItem = MC.player.getActiveItem();
			
			// Check if eating (food items)
			if(activeItem.contains(DataComponentTypes.FOOD))
				return true;
			
			// Check if using shield
			if(activeItem.getItem() == Items.SHIELD)
				return true;
			
			// Check if drinking potions
			if(activeItem.getItem().toString().contains("potion"))
				return true;
		}
		
		// Check offhand shield
		if(MC.player.getOffHandStack().getItem() == Items.SHIELD
			&& MC.player.isBlocking())
			return true;
		
		return false;
	}
	
	private int findBestSword()
	{
		int bestSlot = -1;
		float bestDamage = -1;
		
		for(int i = 0; i < 9; i++)
		{
			ItemStack stack = MC.player.getInventory().getStack(i);
			if(stack.isEmpty())
				continue;
			
			// Check for combat weapons (swords, axes, tridents, maces)
			if(!(stack.getItem() instanceof SwordItem
				|| stack.getItem() instanceof AxeItem
				|| stack.getItem() instanceof TridentItem
				|| stack.getItem() instanceof MaceItem))
				continue;
			
			float damage = getWeaponDamage(stack);
			if(damage > bestDamage)
			{
				bestDamage = damage;
				bestSlot = i;
			}
		}
		
		return bestSlot;
	}
	
	private float getWeaponDamage(ItemStack weapon)
	{
		return (float)ItemUtils.getAttribute(weapon.getItem(),
			EntityAttributes.GENERIC_ATTACK_DAMAGE).orElse(0.0);
	}
	
	private void resetState()
	{
		originalSlot = -1;
		shouldSwapBack = false;
		swapBackTimer = 0;
		wasEatingOrShielding = false;
	}
}
