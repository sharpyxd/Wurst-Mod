/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.util.BlockPlacer;

@SearchTags({"cobweb placer", "web placer", "trap", "auto cobweb"})
public final class CobwebPlacerHack extends Hack implements UpdateListener
{
	private final SliderSetting range =
		new SliderSetting("Range", "Maximum range for placing cobwebs.", 4.5, 1,
			6, 0.05, SliderSetting.ValueDisplay.DECIMAL);
	
	private final SliderSetting delay =
		new SliderSetting("Delay", "Delay between cobweb placements in ticks.",
			8, 3, 25, 1, SliderSetting.ValueDisplay.INTEGER);
	
	private final SliderSetting randomDelay = new SliderSetting("Random delay",
		"Random delay variation to avoid detection.", 5, 0, 15, 1,
		SliderSetting.ValueDisplay.INTEGER);
	
	private final CheckboxSetting rotations = new CheckboxSetting("Rotations",
		"Rotate towards placement position.", true);
	
	private final CheckboxSetting checkLOS = new CheckboxSetting("Check LOS",
		"Only place when line of sight is available.", true);
	
	private final SliderSetting maxCPS = new SliderSetting("Max CPS",
		"Maximum clicks per second to avoid detection.", 8, 3, 15, 1,
		SliderSetting.ValueDisplay.INTEGER);
	
	private int timer;
	private long lastPlacement;
	private int placementCount;
	private long sessionStart;
	
	public CobwebPlacerHack()
	{
		super("CobwebPlacer");
		setCategory(Category.BLOCKS);
		
		addSetting(range);
		addSetting(delay);
		addSetting(randomDelay);
		addSetting(rotations);
		addSetting(checkLOS);
		addSetting(maxCPS);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
		timer = 0;
		lastPlacement = 0;
		placementCount = 0;
		sessionStart = System.currentTimeMillis();
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(timer > 0)
		{
			timer--;
			return;
		}
		
		// Anti-cheat bypass: Check CPS limit
		long currentTime = System.currentTimeMillis();
		if(currentTime - sessionStart < 1000)
		{
			if(placementCount >= maxCPS.getValueI())
				return;
		}else
		{
			placementCount = 0;
			sessionStart = currentTime;
		}
		
		// Check if player is holding a cobweb
		if(!isHoldingCobweb())
			return;
		
		// Anti-cheat bypass: Add minimum time between placements
		if(currentTime - lastPlacement < 150)
			return;
		
		// Find enemy players to trap
		for(PlayerEntity player : MC.world.getPlayers())
		{
			if(player == MC.player)
				continue;
			
			// Skip friends
			if(WURST.getFriends().isFriend(player))
				continue;
			
			if(MC.player.distanceTo(player) > range.getValue())
				continue;
			
			// Try to place cobweb at player's position
			BlockPos playerPos = BlockPos.ofFloored(player.getPos());
			
			if(canPlaceCobweb(playerPos))
			{
				if(placeCobweb(playerPos))
				{
					setRandomTimer();
					return;
				}
			}
			
			// Also try to place cobweb above player
			BlockPos abovePos = playerPos.up();
			if(canPlaceCobweb(abovePos))
			{
				if(placeCobweb(abovePos))
				{
					setRandomTimer();
					return;
				}
			}
		}
	}
	
	private boolean isHoldingCobweb()
	{
		ItemStack heldItem = MC.player.getMainHandStack();
		return heldItem.getItem() == Items.COBWEB;
	}
	
	private boolean canPlaceCobweb(BlockPos pos)
	{
		// Check if position is replaceable and within reach
		if(!MC.world.getBlockState(pos).isReplaceable())
			return false;
		
		double distance = MC.player.squaredDistanceTo(Vec3d.ofCenter(pos));
		if(distance > range.getValue() * range.getValue())
			return false;
		
		// Anti-cheat bypass: Check line of sight if enabled
		if(checkLOS.isChecked())
		{
			Vec3d eyePos = MC.player.getEyePos();
			Vec3d targetPos = Vec3d.ofCenter(pos);
			if(MC.world
				.raycast(
					new net.minecraft.world.RaycastContext(eyePos, targetPos,
						net.minecraft.world.RaycastContext.ShapeType.COLLIDER,
						net.minecraft.world.RaycastContext.FluidHandling.NONE,
						MC.player))
				.getType() != net.minecraft.util.hit.HitResult.Type.MISS)
				return false;
		}
		
		return true;
	}
	
	private boolean placeCobweb(BlockPos pos)
	{
		// Anti-cheat bypass: Rotate towards target if enabled
		if(rotations.isChecked())
		{
			Vec3d targetVec = Vec3d.ofCenter(pos);
			WURST.getRotationFaker().faceVectorClient(targetVec);
			
			// Add small delay after rotation to seem more human
			try
			{
				Thread.sleep(50 + (int)(Math.random() * 50));
			}catch(InterruptedException e)
			{
				// Ignore
			}
		}
		
		// Place the cobweb (player is already holding cobweb)
		boolean success = BlockPlacer.placeOneBlock(pos);
		
		if(success)
		{
			lastPlacement = System.currentTimeMillis();
			placementCount++;
		}
		
		return success;
	}
	
	private void setRandomTimer()
	{
		int baseDelay = delay.getValueI();
		int randomVariation = randomDelay.getValueI();
		int finalDelay = baseDelay + (int)(Math.random() * randomVariation);
		timer = finalDelay;
	}
}
