/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.LeftClickListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;

@SearchTags({"mace auto swap", "auto mace", "density swap", "breach swap"})
public final class MaceAutoSwapHack extends Hack
	implements LeftClickListener, UpdateListener
{
	private final CheckboxSetting onlyPlayers = new CheckboxSetting(
		"Only Players", "Only swap when hitting players.", true);
	
	private final SliderSetting heightThreshold = new SliderSetting(
		"Height Threshold", "Blocks above ground to use density mace.", 2.5, 1,
		10, 0.5, SliderSetting.ValueDisplay.DECIMAL);
	
	private final CheckboxSetting instantSwap = new CheckboxSetting(
		"Instant Swap", "Instantly swap maces without delay.", true);
	
	private final CheckboxSetting autoSwapBack = new CheckboxSetting(
		"Auto Swap Back", "Automatically swap back to original item.", true);
	
	private final SliderSetting swapBackDelay = new SliderSetting(
		"Swap Back Delay", "Ticks to wait before swapping back (0 = instant).",
		1, 0, 20, 1, SliderSetting.ValueDisplay.INTEGER);
	
	private int originalSlot = -1;
	private boolean shouldSwapBack = false;
	private int swapBackTimer = 0;
	
	public MaceAutoSwapHack()
	{
		super("MaceSwap");
		setCategory(Category.COMBAT);
		addSetting(onlyPlayers);
		addSetting(heightThreshold);
		addSetting(instantSwap);
		addSetting(autoSwapBack);
		addSetting(swapBackDelay);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(LeftClickListener.class, this);
		EVENTS.add(UpdateListener.class, this);
		resetState();
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(LeftClickListener.class, this);
		EVENTS.remove(UpdateListener.class, this);
		
		if(shouldSwapBack && originalSlot != -1 && MC.player != null)
		{
			MC.player.getInventory().selectedSlot = originalSlot;
			resetState();
		}
	}
	
	@Override
	public void onUpdate()
	{
		if(MC.player == null)
			return;
		
		// Handle swap back timer
		if(shouldSwapBack && autoSwapBack.isChecked())
		{
			if(swapBackDelay.getValueI() == 0)
			{
				// Instant swap back
				MC.player.getInventory().selectedSlot = originalSlot;
				resetState();
			}else if(swapBackTimer > 0)
			{
				swapBackTimer--;
				if(swapBackTimer <= 0)
				{
					MC.player.getInventory().selectedSlot = originalSlot;
					resetState();
				}
			}
		}
		
		// Auto-swap for aim assist and trigger bot
		if(MC.crosshairTarget != null
			&& MC.crosshairTarget.getType() == HitResult.Type.ENTITY)
		{
			EntityHitResult entityHit = (EntityHitResult)MC.crosshairTarget;
			Entity target = entityHit.getEntity();
			
			if(shouldSwapForTarget(target))
			{
				int maceSlot = findBestMace(target);
				if(maceSlot != -1
					&& maceSlot != MC.player.getInventory().selectedSlot)
				{
					if(!shouldSwapBack)
						originalSlot = MC.player.getInventory().selectedSlot;
					
					MC.player.getInventory().selectedSlot = maceSlot;
					shouldSwapBack = true;
					swapBackTimer = swapBackDelay.getValueI();
				}
			}
		}
	}
	
	@Override
	public void onLeftClick(LeftClickEvent event)
	{
		if(MC.player == null || MC.crosshairTarget == null)
			return;
		
		if(MC.crosshairTarget.getType() != HitResult.Type.ENTITY)
			return;
		
		EntityHitResult entityHit = (EntityHitResult)MC.crosshairTarget;
		Entity target = entityHit.getEntity();
		
		if(!shouldSwapForTarget(target))
			return;
		
		int maceSlot = findBestMace(target);
		if(maceSlot == -1 || maceSlot == MC.player.getInventory().selectedSlot)
			return;
		
		if(!shouldSwapBack)
			originalSlot = MC.player.getInventory().selectedSlot;
		
		MC.player.getInventory().selectedSlot = maceSlot;
		shouldSwapBack = true;
		swapBackTimer = swapBackDelay.getValueI();
		
		// Instant swap back if delay is 0
		if(autoSwapBack.isChecked() && swapBackDelay.getValueI() == 0)
		{
			// Schedule swap back for next tick
			swapBackTimer = 1;
		}
	}
	
	public void setSlot(Entity target)
	{
		if(!isEnabled() || MC.player == null)
			return;
		
		if(!shouldSwapForTarget(target))
			return;
		
		int maceSlot = findBestMace(target);
		if(maceSlot == -1 || maceSlot == MC.player.getInventory().selectedSlot)
			return;
		
		if(!shouldSwapBack)
			originalSlot = MC.player.getInventory().selectedSlot;
		
		MC.player.getInventory().selectedSlot = maceSlot;
		shouldSwapBack = true;
		swapBackTimer = swapBackDelay.getValueI();
	}
	
	private boolean shouldSwapForTarget(Entity target)
	{
		if(!(target instanceof LivingEntity))
			return false;
		
		if(onlyPlayers.isChecked() && !(target instanceof PlayerEntity))
			return false;
		
		return true;
	}
	
	private int findBestMace(Entity target)
	{
		int densitySlot = -1;
		int breachSlot = -1;
		int regularSlot = -1;
		
		for(int i = 0; i < 9; i++)
		{
			ItemStack stack = MC.player.getInventory().getStack(i);
			if(stack.getItem() != Items.MACE)
				continue;
			
			if(hasDensityEnchantment(stack))
				densitySlot = i;
			else if(hasBreachEnchantment(stack))
				breachSlot = i;
			else if(regularSlot == -1)
				regularSlot = i;
		}
		
		// Always prioritize breach mace for maximum damage
		if(breachSlot != -1)
			return breachSlot;
		
		// Use density only when very high up
		if(densitySlot != -1 && isPlayerHigh())
			return densitySlot;
		
		// Fallback to any mace
		return regularSlot;
	}
	
	private boolean isPlayerHigh()
	{
		return !MC.player.isOnGround()
			&& (MC.player.fallDistance >= heightThreshold.getValue()
				|| MC.player.getVelocity().y < -0.3);
	}
	
	private void resetState()
	{
		originalSlot = -1;
		shouldSwapBack = false;
		swapBackTimer = 0;
	}
	
	private boolean hasDensityEnchantment(ItemStack stack)
	{
		return stack.getEnchantments().getEnchantments().stream()
			.anyMatch(enchantment -> enchantment.equals(Enchantments.DENSITY));
	}
	
	private boolean hasBreachEnchantment(ItemStack stack)
	{
		return stack.getEnchantments().getEnchantments().stream()
			.anyMatch(enchantment -> enchantment.equals(Enchantments.BREACH));
	}
}
