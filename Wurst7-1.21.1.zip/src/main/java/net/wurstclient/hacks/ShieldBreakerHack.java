/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import java.util.Comparator;
import java.util.stream.StreamSupport;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;

@SearchTags({"shield breaker", "axe swap", "shield disable", "auto axe"})
public final class ShieldBreakerHack extends Hack implements UpdateListener
{
	private final SliderSetting range =
		new SliderSetting("Range", "Maximum range to detect shield users.", 4.5,
			1, 6, 0.1, SliderSetting.ValueDisplay.DECIMAL);
	
	private final CheckboxSetting autoAttack = new CheckboxSetting(
		"Auto Attack", "Automatically attack shield users.", true);
	
	private final CheckboxSetting humanize = new CheckboxSetting("Humanize",
		"Add random delays to bypass anti-cheat.", true);
	
	private final SliderSetting attackDelay =
		new SliderSetting("Attack Delay", "Delay between attacks in ticks.", 3,
			1, 10, 1, SliderSetting.ValueDisplay.INTEGER);
	
	private final CheckboxSetting instantSwap = new CheckboxSetting(
		"Instant Swap", "Instantly swap to axe without delays.", true);
	
	private final CheckboxSetting predictMovement =
		new CheckboxSetting("Predict Movement",
			"Predict player movement for faster targeting.", true);
	
	private final CheckboxSetting hudIndicator = new CheckboxSetting(
		"HUD Indicator", "Show when about to trigger.", true);
	
	private int originalSlot = -1;
	private boolean shouldSwapBack = false;
	private int swapBackTimer = 0;
	private int attackTimer = 0;
	private PlayerEntity lastTarget = null;
	private long lastAttackTime = 0;
	
	public ShieldBreakerHack()
	{
		super("ShieldBreaker");
		setCategory(Category.COMBAT);
		addSetting(range);
		addSetting(autoAttack);
		addSetting(humanize);
		addSetting(attackDelay);
		addSetting(instantSwap);
		addSetting(predictMovement);
		addSetting(hudIndicator);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
		resetState();
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		
		if(shouldSwapBack && originalSlot != -1 && MC.player != null)
		{
			MC.player.getInventory().selectedSlot = originalSlot;
			resetState();
		}
	}
	
	@Override
	public void onUpdate()
	{
		if(MC.player == null || MC.world == null)
			return;
		
		// Handle swap back timer
		if(shouldSwapBack && swapBackTimer > 0)
		{
			swapBackTimer--;
			if(swapBackTimer <= 0)
			{
				MC.player.getInventory().selectedSlot = originalSlot;
				resetState();
			}
		}
		
		// Handle attack cooldown (bypass for instant mode)
		if(attackTimer > 0 && !instantSwap.isChecked())
		{
			attackTimer--;
			return;
		}else if(attackTimer > 0)
		{
			attackTimer--;
		}
		
		// Find target
		PlayerEntity target = findShieldTarget();
		if(target == null || !isLookingAtTarget(target))
		{
			lastTarget = null;
			return;
		}
		
		// Anti-cheat bypass: Don't spam same target
		if(target == lastTarget
			&& System.currentTimeMillis() - lastAttackTime < 500)
			return;
		
		// Only swap to axe if target is using shield
		if(!isUsingShield(target))
			return;
		
		int axeSlot = findBestAxe();
		if(axeSlot == -1)
			return;
		
		// Perform the shield break sequence
		executeShieldBreak(target, axeSlot);
	}
	
	private PlayerEntity findShieldTarget()
	{
		return StreamSupport.stream(MC.world.getEntities().spliterator(), false)
			.filter(entity -> entity instanceof PlayerEntity)
			.map(entity -> (PlayerEntity)entity).filter(this::isValidTarget)
			.filter(this::isUsingShield).filter(this::isInLineOfSight)
			.min(Comparator
				.comparingDouble(player -> MC.player.distanceTo(player)))
			.orElse(null);
	}
	
	private boolean isValidTarget(PlayerEntity player)
	{
		if(player == MC.player)
			return false;
		
		// Skip friends
		if(WURST.getFriends().isFriend(player))
			return false;
		
		if(player.isDead() || player.getHealth() <= 0)
			return false;
		
		double distance = MC.player.distanceTo(player);
		if(predictMovement.isChecked())
		{
			// Predict where player will be
			Vec3d velocity = player.getVelocity();
			Vec3d predictedPos = player.getPos().add(velocity.multiply(2));
			double predictedDistance =
				MC.player.getPos().distanceTo(predictedPos);
			return Math.min(distance, predictedDistance) <= range.getValue();
		}
		
		return distance <= range.getValue();
	}
	
	private boolean isUsingShield(PlayerEntity player)
	{
		// Check if player is actively blocking with shield
		return player.isBlocking()
			&& (player.getActiveItem().getItem() == Items.SHIELD
				|| player.getOffHandStack().getItem() == Items.SHIELD);
	}
	
	private boolean isLookingAtTarget(PlayerEntity target)
	{
		return MC.crosshairTarget != null
			&& MC.crosshairTarget.getType() == HitResult.Type.ENTITY
			&& ((EntityHitResult)MC.crosshairTarget).getEntity() == target;
	}
	
	private boolean isInLineOfSight(PlayerEntity target)
	{
		Vec3d start = MC.player.getEyePos();
		Vec3d end = target.getEyePos();
		
		RaycastContext context =
			new RaycastContext(start, end, RaycastContext.ShapeType.COLLIDER,
				RaycastContext.FluidHandling.NONE, MC.player);
		
		HitResult result = MC.world.raycast(context);
		return result.getType() == HitResult.Type.MISS
			|| (result instanceof EntityHitResult
				&& ((EntityHitResult)result).getEntity() == target);
	}
	
	private int findBestAxe()
	{
		int bestSlot = -1;
		int bestTier = -1;
		
		for(int i = 0; i < 9; i++)
		{
			ItemStack stack = MC.player.getInventory().getStack(i);
			if(!(stack.getItem() instanceof AxeItem))
				continue;
			
			int tier = getAxeTier(stack);
			if(tier > bestTier)
			{
				bestTier = tier;
				bestSlot = i;
			}
		}
		
		return bestSlot;
	}
	
	private int getAxeTier(ItemStack axe)
	{
		if(axe.getItem() == Items.NETHERITE_AXE)
			return 4;
		if(axe.getItem() == Items.DIAMOND_AXE)
			return 3;
		if(axe.getItem() == Items.IRON_AXE)
			return 2;
		if(axe.getItem() == Items.STONE_AXE)
			return 1;
		if(axe.getItem() == Items.WOODEN_AXE)
			return 0;
		return -1;
	}
	
	private void executeShieldBreak(PlayerEntity target, int axeSlot)
	{
		// Store original slot if not already stored
		if(!shouldSwapBack)
		{
			originalSlot = MC.player.getInventory().selectedSlot;
		}
		
		// Instant axe swap
		MC.player.getInventory().selectedSlot = axeSlot;
		
		// Minimal delay for instant mode
		if(!instantSwap.isChecked() && humanize.isChecked())
		{
			try
			{
				Thread.sleep(5 + (int)(Math.random() * 10));
			}catch(InterruptedException e)
			{
				// Ignore
			}
		}
		
		// Fast attack sequence
		if(autoAttack.isChecked())
		{
			// Quick rotation with movement prediction
			Vec3d targetPos = predictMovement.isChecked()
				? target.getPos().add(target.getVelocity().multiply(1.5))
				: target.getEyePos();
			
			if(instantSwap.isChecked())
			{
				// Instant packet rotation
				WURST.getRotationFaker().faceVectorPacket(targetPos);
			}else
			{
				WURST.getRotationFaker().faceVectorClient(targetPos);
			}
			
			// Immediate attack
			MC.interactionManager.attackEntity(MC.player, target);
			MC.player.swingHand(Hand.MAIN_HAND);
		}
		
		// Fast swap back
		shouldSwapBack = true;
		swapBackTimer = instantSwap.isChecked() ? 1
			: (humanize.isChecked() ? 2 + (int)(Math.random() * 2) : 2);
		
		// Reduced cooldown for instant mode
		attackTimer = instantSwap.isChecked() ? 1 : (attackDelay.getValueI()
			+ (humanize.isChecked() ? (int)(Math.random() * 3) : 0));
		
		// Update tracking
		lastTarget = target;
		lastAttackTime = System.currentTimeMillis();
	}
	
	private void resetState()
	{
		originalSlot = -1;
		shouldSwapBack = false;
		swapBackTimer = 0;
		attackTimer = 0;
	}
	
	public boolean isAboutToTrigger()
	{
		if(!isEnabled() || !hudIndicator.isChecked())
			return false;
		
		return findShieldTarget() != null && findBestAxe() != -1;
	}
	
	@Override
	public String getRenderName()
	{
		if(hudIndicator.isChecked() && isAboutToTrigger())
			return getName() + " [READY]";
		
		return getName();
	}
}
