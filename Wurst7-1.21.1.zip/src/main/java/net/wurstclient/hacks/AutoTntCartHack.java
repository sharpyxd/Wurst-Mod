/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.StopUsingItemListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.SliderSetting;

import java.util.Random;

@SearchTags({"auto tnt cart", "tnt minecart", "instant tnt", "bow tnt"})
public final class AutoTntCartHack extends Hack
	implements StopUsingItemListener, UpdateListener
{
	private final CheckboxSetting onlyFlame = new CheckboxSetting(
		"Only Flame Bow", "Only activate when using a flame bow.", true);
	
	private final SliderSetting delay = new SliderSetting("Delay",
		"Delay in ticks before placing (0 = instant).", 2, 0, 20, 1,
		SliderSetting.ValueDisplay.INTEGER);
	
	private final CheckboxSetting switchBack = new CheckboxSetting(
		"Switch Back", "Switch back to bow after placing.", true);
	
	private final SliderSetting randomDelay = new SliderSetting("Random Delay",
		"Random delay range in ms (±value).", 50, 0, 200, 10,
		SliderSetting.ValueDisplay.INTEGER.withSuffix("ms"));
	
	private final CheckboxSetting checkPlayers = new CheckboxSetting(
		"Check Players", "Only activate when no players nearby.", false);
	
	private final CheckboxSetting spreadTicks = new CheckboxSetting(
		"Spread Ticks", "Spread actions over multiple ticks.", true);
	
	private final Random random = new Random();
	private boolean shouldPlace = false;
	private int placeTimer = 0;
	private int originalSlot = -1;
	private BlockPos targetPos;
	private int sequenceStep = 0;
	private int stepTimer = 0;
	
	public AutoTntCartHack()
	{
		super("AutoTntCart");
		setCategory(Category.BLOCKS);
		addSetting(onlyFlame);
		addSetting(delay);
		addSetting(switchBack);
		addSetting(randomDelay);
		addSetting(checkPlayers);
		addSetting(spreadTicks);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(StopUsingItemListener.class, this);
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(StopUsingItemListener.class, this);
		EVENTS.remove(UpdateListener.class, this);
		shouldPlace = false;
		placeTimer = 0;
		sequenceStep = 0;
		stepTimer = 0;
	}
	
	@Override
	public void onStopUsingItem()
	{
		if(MC.player == null || MC.world == null)
			return;
		
		ItemStack heldItem = MC.player.getMainHandStack();
		if(!(heldItem.getItem() instanceof BowItem))
			return;
		
		if(onlyFlame.isChecked() && !hasFlameEnchantment(heldItem))
			return;
		
		if(MC.crosshairTarget == null
			|| MC.crosshairTarget.getType() != HitResult.Type.BLOCK)
			return;
		
		BlockHitResult blockHit = (BlockHitResult)MC.crosshairTarget;
		targetPos = blockHit.getBlockPos().offset(blockHit.getSide());
		
		if(!canPlaceAt(targetPos))
			return;
		
		if(checkPlayers.isChecked() && hasNearbyPlayers())
			return;
		
		originalSlot = MC.player.getInventory().selectedSlot;
		shouldPlace = true;
		placeTimer = delay.getValueI() + getRandomDelay();
		sequenceStep = 0;
	}
	
	@Override
	public void onUpdate()
	{
		if(!shouldPlace)
			return;
		
		if(placeTimer > 0)
		{
			placeTimer--;
			return;
		}
		
		if(spreadTicks.isChecked())
			placeSequenceSpread();
		else
			placeSequence();
		
		if(!spreadTicks.isChecked() || sequenceStep >= 3)
			shouldPlace = false;
	}
	
	private void placeSequence()
	{
		int railSlot = findItem(Items.RAIL);
		int cartSlot = findItem(Items.TNT_MINECART);
		
		if(railSlot == -1 || cartSlot == -1)
			return;
		
		// Place rail with human-like delay
		MC.player.getInventory().selectedSlot = railSlot;
		addHumanDelay(20, 50);
		// Place rail block
		IMC.getInteractionManager().rightClickBlock(targetPos, Direction.UP,
			net.minecraft.util.math.Vec3d.ofCenter(targetPos));
		
		// Delay between actions
		addHumanDelay(30, 80);
		
		// Place TNT cart
		MC.player.getInventory().selectedSlot = cartSlot;
		addHumanDelay(15, 40);
		MC.interactionManager.interactBlock(MC.player, Hand.MAIN_HAND,
			new BlockHitResult(getRandomizedPos(targetPos), Direction.UP,
				targetPos, false));
		
		// Switch back with delay
		if(switchBack.isChecked() && originalSlot != -1)
		{
			addHumanDelay(10, 30);
			MC.player.getInventory().selectedSlot = originalSlot;
		}
	}
	
	private void placeSequenceSpread()
	{
		int railSlot = findItem(Items.RAIL);
		int cartSlot = findItem(Items.TNT_MINECART);
		
		if(railSlot == -1 || cartSlot == -1)
			return;
		
		if(stepTimer > 0)
		{
			stepTimer--;
			return;
		}
		
		switch(sequenceStep)
		{
			case 0: // Switch to rail
			MC.player.getInventory().selectedSlot = railSlot;
			stepTimer = 1 + random.nextInt(2);
			sequenceStep++;
			break;
			
			case 1: // Place rail
			// Place rail block
			IMC.getInteractionManager().rightClickBlock(targetPos, Direction.UP,
				net.minecraft.util.math.Vec3d.ofCenter(targetPos));
			stepTimer = 2 + random.nextInt(2);
			sequenceStep++;
			break;
			
			case 2: // Switch to cart and place
			MC.player.getInventory().selectedSlot = cartSlot;
			MC.interactionManager.interactBlock(MC.player, Hand.MAIN_HAND,
				new BlockHitResult(getRandomizedPos(targetPos), Direction.UP,
					targetPos, false));
			
			if(switchBack.isChecked() && originalSlot != -1)
			{
				stepTimer = 1;
				sequenceStep++;
			}else
				sequenceStep = 3;
			break;
			
			case 3: // Switch back
			MC.player.getInventory().selectedSlot = originalSlot;
			sequenceStep++;
			break;
		}
	}
	
	private boolean canPlaceAt(BlockPos pos)
	{
		return MC.world.getBlockState(pos).isReplaceable() && MC.world
			.getBlockState(pos.down()).isSolidBlock(MC.world, pos.down());
	}
	
	private int findItem(net.minecraft.item.Item item)
	{
		for(int i = 0; i < 9; i++)
		{
			ItemStack stack = MC.player.getInventory().getStack(i);
			if(stack.getItem() == item)
				return i;
		}
		return -1;
	}
	
	private boolean hasFlameEnchantment(ItemStack stack)
	{
		return stack.getEnchantments().getEnchantments().stream()
			.anyMatch(enchantment -> enchantment.toString().contains("flame"));
	}
	
	private void addHumanDelay(int minMs, int maxMs)
	{
		try
		{
			int delay = minMs + random.nextInt(maxMs - minMs + 1);
			Thread.sleep(delay);
		}catch(InterruptedException e)
		{
			Thread.currentThread().interrupt();
		}
	}
	
	private int getRandomDelay()
	{
		if(randomDelay.getValue() <= 0)
			return 0;
		return random.nextInt((int)(randomDelay.getValue() * 2))
			- (int)randomDelay.getValue();
	}
	
	private net.minecraft.util.math.Vec3d getRandomizedPos(BlockPos pos)
	{
		double x = pos.getX() + 0.3 + random.nextDouble() * 0.4;
		double y = pos.getY() + 0.5;
		double z = pos.getZ() + 0.3 + random.nextDouble() * 0.4;
		return new net.minecraft.util.math.Vec3d(x, y, z);
	}
	
	private boolean hasNearbyPlayers()
	{
		return MC.world.getPlayers().stream()
			.anyMatch(player -> player != MC.player
				&& MC.player.squaredDistanceTo(player) < 64); // 8 block radius
	}
}
