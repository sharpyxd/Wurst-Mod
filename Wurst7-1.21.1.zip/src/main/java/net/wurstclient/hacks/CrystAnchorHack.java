/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.util.math.BlockPos;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.PacketOutputListener;
import net.wurstclient.events.PacketOutputListener.PacketOutputEvent;
import net.wurstclient.hack.Hack;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.util.BlockUtils;
import net.wurstclient.util.InventoryUtils;

@SearchTags({"cryst anchor", "crystal anchor", "anchor switch"})
public final class CrystAnchorHack extends Hack implements PacketOutputListener
{
	private final CheckboxSetting onCrystal =
		new CheckboxSetting("On crystal", "Trigger on use of crystals", true);
	
	private final CheckboxSetting onSword =
		new CheckboxSetting("On sword", "Trigger on use of swords", false);
	
	private final CheckboxSetting onPickaxe =
		new CheckboxSetting("On pickaxe", "Trigger on use of pickaxes", false);
	
	public CrystAnchorHack()
	{
		super("CrystAnchor");
		setCategory(Category.COMBAT);
		addSetting(onCrystal);
		addSetting(onSword);
		addSetting(onPickaxe);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(PacketOutputListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(PacketOutputListener.class, this);
	}
	
	@Override
	public void onSentPacket(PacketOutputEvent event)
	{
		if(!(event.getPacket() instanceof PlayerInteractBlockC2SPacket packet))
			return;
		
		BlockPos pos = packet.getBlockHitResult().getBlockPos();
		
		if(canCrystalOn(pos))
			return;
		if(InventoryUtils.indexOf(Items.RESPAWN_ANCHOR, 36) == -1)
			return;
		
		boolean crystal =
			onCrystal.isChecked() && MC.player.isHolding(Items.END_CRYSTAL);
		boolean sword = onSword.isChecked() && MC.player.getMainHandStack()
			.getName().getString().toLowerCase().contains("sword");
		boolean pick = onPickaxe.isChecked() && MC.player.getMainHandStack()
			.getName().getString().toLowerCase().contains("pickaxe");
		
		if(crystal || sword || pick)
		{
			event.cancel();
			InventoryUtils.selectItem(Items.RESPAWN_ANCHOR, 36);
			IMC.getInteractionManager().rightClickBlock(pos,
				packet.getBlockHitResult().getSide(),
				packet.getBlockHitResult().getPos());
			InventoryUtils.selectItem(Items.GLOWSTONE, 36);
		}
	}
	
	private boolean canCrystalOn(BlockPos pos)
	{
		return BlockUtils.getBlock(pos)
			.equals(net.minecraft.block.Blocks.OBSIDIAN)
			|| BlockUtils.getBlock(pos)
				.equals(net.minecraft.block.Blocks.BEDROCK);
	}
}
