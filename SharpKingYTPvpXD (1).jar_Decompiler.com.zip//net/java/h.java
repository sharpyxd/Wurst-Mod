package net.java;

import net.fabricmc.api.ModInitializer;

public class h implements ModInitializer {
   public void onInitialize() {
      m.a();
      l.a((Object)(new Object[]{null, null, 6, null, null, m.a.trim()}));
   }
}
